import 'package:flutter/material.dart';
import '../data/quran_data.dart';
import 'quran_reader_screen.dart';

/// الشاشة الرئيسية للقرآن الكريم (تحتوي على التبويبات: سور، أجزاء، أحزاب، علامات الوقف، ومحرك البحث السريع)
class QuranScreen extends StatefulWidget {
  const QuranScreen({Key? key}) : super(key: key);

  @override
  State<QuranScreen> createState() => _QuranScreenState();
}

class _QuranScreenState extends State<QuranScreen> with SingleTickerProviderStateMixin {
  late TabController _tabController;
  String _searchQuery = '';
  bool _isSearching = false;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 4, vsync: this);
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  void _navigateToPage(int pageNumber) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => QuranReaderScreen(initialPage: pageNumber),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    // تصفية السور بناءً على نص البحث إذا كان متاحاً
    final filteredSurahs = QuranData.surahs.where((surah) {
      final name = surah['name'].toString();
      final engName = surah['englishName'].toString().toLowerCase();
      final query = _searchQuery.toLowerCase();
      return name.contains(query) || engName.contains(query) || surah['number'].toString() == query;
    }).toList();

    return Scaffold(
      appBar: AppBar(
        title: _isSearching
            ? TextField(
                autofocus: true,
                decoration: const InputDecoration(
                  hintText: 'ابحث عن اسم السورة أو الرقم...',
                  hintStyle: TextStyle(color: Colors.white70, fontFamily: 'Amiri'),
                  border: InputBorder.none,
                ),
                style: const TextStyle(color: Colors.white, fontFamily: 'Amiri', fontSize: 18),
                onChanged: (value) {
                  setState(() {
                    _searchQuery = value;
                  });
                },
              )
            : const Text(
                'القرآن الكريم والمصحف الشريف',
                style: TextStyle(fontFamily: 'Amiri', fontWeight: FontWeight.bold),
              ),
        centerTitle: true,
        actions: [
          IconButton(
            icon: Icon(_isSearching ? Icons.close : Icons.search),
            onPressed: () {
              setState(() {
                _isSearching = !_isSearching;
                if (!_isSearching) _searchQuery = '';
              });
            },
          ),
          // زر الانتقال السريع لآخر صفحة أو الموضع المحفوظ
          IconButton(
            icon: const Icon(Icons.menu_book),
            tooltip: 'فتح المصحف (صفحة 1)',
            onPressed: () => _navigateToPage(1),
          ),
        ],
        bottom: TabBar(
          controller: _tabController,
          isScrollable: true,
          labelStyle: const TextStyle(fontFamily: 'Amiri', fontWeight: FontWeight.bold, fontSize: 16),
          unselectedLabelStyle: const TextStyle(fontFamily: 'Amiri', fontSize: 15),
          indicatorColor: Colors.amber,
          tabs: const [
            Tab(text: 'سور'),
            Tab(text: 'أجزاء'),
            Tab(text: 'أحزاب'),
            Tab(text: 'علامات الوقف'),
          ],
        ),
      ),
      body: TabBarView(
        controller: _tabController,
        children: [
          // 1. تبويب السور (Surahs)
          ListView.builder(
            padding: const EdgeInsets.all(12),
            itemCount: filteredSurahs.length,
            itemBuilder: (context, index) {
              final surah = filteredSurahs[index];
              return Card(
                elevation: 2,
                margin: const EdgeInsets.symmetric(vertical: 6, horizontal: 4),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                child: ListTile(
                  leading: CircleAvatar(
                    backgroundColor: Colors.green.shade700,
                    child: Text(
                      '${surah['number']}',
                      style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
                    ),
                  ),
                  title: Text(
                    surah['name'],
                    style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold, fontFamily: 'Amiri'),
                  ),
                  subtitle: Text(
                    '${surah['type']} • ${surah['ayahs']} آية • صفحة ${surah['page']}',
                    style: const TextStyle(fontFamily: 'Amiri', color: Colors.grey),
                  ),
                  trailing: const Icon(Icons.arrow_forward_ios, size: 16, color: Colors.green),
                  onTap: () => _navigateToPage(surah['page']),
                ),
              );
            },
          ),

          // 2. تبويب الأجزاء (Juz')
          ListView.builder(
            padding: const EdgeInsets.all(12),
            itemCount: QuranData.juzs.length,
            itemBuilder: (context, index) {
              final juz = QuranData.juzs[index];
              return Card(
                elevation: 2,
                margin: const EdgeInsets.symmetric(vertical: 6, horizontal: 4),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                child: ListTile(
                  leading: CircleAvatar(
                    backgroundColor: Colors.teal.shade700,
                    child: Text(
                      '${juz['number']}',
                      style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
                    ),
                  ),
                  title: Text(
                    juz['name'],
                    style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold, fontFamily: 'Amiri'),
                  ),
                  subtitle: Text(
                    'يبدأ من الصفحة ${juz['page']}',
                    style: const TextStyle(fontFamily: 'Amiri', color: Colors.grey),
                  ),
                  trailing: const Icon(Icons.arrow_forward_ios, size: 16, color: Colors.teal),
                  onTap: () => _navigateToPage(juz['page']),
                ),
              );
            },
          ),

          // 3. تبويب الأحزاب (Hizbs)
          ListView.builder(
            padding: const EdgeInsets.all(12),
            itemCount: QuranData.hizbs.length,
            itemBuilder: (context, index) {
              final hizb = QuranData.hizbs[index];
              return Card(
                elevation: 2,
                margin: const EdgeInsets.symmetric(vertical: 6, horizontal: 4),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                child: ListTile(
                  leading: CircleAvatar(
                    backgroundColor: Colors.brown.shade600,
                    child: Text(
                      '${hizb['number']}',
                      style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 13),
                    ),
                  ),
                  title: Text(
                    hizb['name'],
                    style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold, fontFamily: 'Amiri'),
                  ),
                  subtitle: Text(
                    'صفحة البداية: ${hizb['page']}',
                    style: const TextStyle(fontFamily: 'Amiri', color: Colors.grey),
                  ),
                  trailing: const Icon(Icons.arrow_forward_ios, size: 16, color: Colors.brown),
                  onTap: () => _navigateToPage(hizb['page']),
                ),
              );
            },
          ),

          // 4. تبويب علامات الوقف (Stop Signs)
          ListView.builder(
            padding: const EdgeInsets.all(12),
            itemCount: QuranData.stopSigns.length,
            itemBuilder: (context, index) {
              final stop = QuranData.stopSigns[index];
              return Card(
                elevation: 3,
                margin: const EdgeInsets.symmetric(vertical: 8, horizontal: 4),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                child: Padding(
                  padding: const EdgeInsets.all(16.0),
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Container(
                        padding: const EdgeInsets.all(12),
                        decoration: BoxDecoration(
                          color: Colors.amber.shade100,
                          borderRadius: BorderRadius.circular(10),
                          border: Border.all(color: Colors.amber.shade700, width: 1.5),
                        ),
                        child: Text(
                          stop['sign']!,
                          style: TextStyle(
                            fontSize: 22,
                            fontWeight: FontWeight.bold,
                            fontFamily: 'Amiri',
                            color: Colors.amber.shade900,
                          ),
                        ),
                      ),
                      const SizedBox(width: 16),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              stop['name']!,
                              style: const TextStyle(
                                fontSize: 18,
                                fontWeight: FontWeight.bold,
                                fontFamily: 'Amiri',
                                color: Colors.black87,
                              ),
                            ),
                            const SizedBox(height: 6),
                            Text(
                              stop['description']!,
                              style: const TextStyle(
                                fontSize: 15,
                                fontFamily: 'Amiri',
                                color: Colors.black54,
                                height: 1.4,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              );
            },
          ),
        ],
      ),
    );
  }
}
