import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:cached_network_image/cached_network_image.dart';
import '../data/quran_data.dart';

/// شاشة عارض صفحات القرآن الكريم بملء الشاشة مع دعم التمرير الأفقي الانتقالي السلس
class QuranReaderScreen extends StatefulWidget {
  final int initialPage; // رقم الصفحة الأولية (من 1 إلى 604)

  const QuranReaderScreen({Key? key, required this.initialPage}) : super(key: key);

  @override
  State<QuranReaderScreen> createState() => _QuranReaderScreenState();
}

class _QuranReaderScreenState extends State<QuranReaderScreen> {
  late PageController _pageController;
  late int _currentPage;
  bool _isUiVisible = false; // التحكم بإظهار أو إخفاء شريط الأدوات العلوي والسفلي لتوفير وضع ملء الشاشة الحقيقي

  @override
  void initState() {
    super.initState();
    _currentPage = widget.initialPage;
    // PageController يتوقع فهرس من 0 إلى 603، بينما الصفحات من 1 إلى 604
    _pageController = PageController(initialPage: _currentPage - 1);
    
    // إخفاء شريط الحالة (Status Bar) والـ Navigation Bar لتجربة بصرية نقية بالكامل
    SystemChrome.setEnabledSystemUIMode(SystemUiMode.immersiveSticky);
  }

  @override
  void dispose() {
    _pageController.dispose();
    // إعادة إظهار عناصر النظام عند الخروج من شاشة القراءة
    SystemChrome.setEnabledSystemUIMode(SystemUiMode.edgeToEdge);
    super.dispose();
  }

  void _toggleUiVisibility() {
    setState(() {
      _isUiVisible = !_isUiVisible;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: GestureDetector(
        onTap: _toggleUiVisibility, // النقر على الشاشة لإظهار أو إخفاء عناصر التحكم
        child: Stack(
          children: [
            // عارض صفحات المصحف الشريف بالتمرير الأفقي (Pageview)
            // ملاحظة هامة حسب المطلوب: التمرير يمين يقلب للصفحة التالية، والتمرير يسار للصفحة السابقة (أو العكس حسب اتجاه القراءة بالعربية)
            PageView.builder(
              controller: _pageController,
              reverse: true, // قلب اتجاه PageView ليتناسب مع القراءة العربية (التمرير يميناً للصفحة التالية ويساراً للسابقة)
              itemCount: 604,
              onPageChanged: (index) {
                setState(() {
                  _currentPage = index + 1;
                });
              },
              itemBuilder: (context, index) {
                final pageNumber = index + 1;
                final imageUrl = QuranData.getPageImageUrl(pageNumber);

                return InteractiveViewer(
                  minScale: 1.0,
                  maxScale: 4.0,
                  child: Center(
                    child: CachedNetworkImage(
                      imageUrl: imageUrl,
                      fit: BoxFit.contain,
                      placeholder: (context, url) => const Center(
                        child: CircularProgressIndicator(
                          color: Colors.amber,
                        ),
                      ),
                      errorWidget: (context, url, error) {
                        // في حال عدم توفر اتصال بالإنترنت أو تعذر جلب الصورة، نعرض واجهة بديلة بتصميم فاخر لرقم الصفحة واسمها
                        return Container(
                          color: const Color(0xFFFDFBF7),
                          padding: const EdgeInsets.all(24),
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              const Icon(Icons.menu_book, size: 80, color: Color(0xFF8D6E63)),
                              const SizedBox(height: 16),
                              Text(
                                'صفحة رقم ($pageNumber)',
                                style: const TextStyle(
                                  fontSize: 26,
                                  fontWeight: FontWeight.bold,
                                  fontFamily: 'Amiri',
                                  color: Color(0xFF3E2723),
                                ),
                              ),
                              const SizedBox(height: 8),
                              const Text(
                                'مصحف الملك فهد / صور صفحات القرآن الكريم\n(جاري العرض أو التحميل من مخزن QuranHub)',
                                textAlign: TextAlign.center,
                                style: TextStyle(
                                  fontSize: 16,
                                  color: Colors.grey,
                                  fontFamily: 'Amiri',
                                ),
                              ),
                            ],
                          ),
                        );
                      },
                    ),
                  ),
                );
              },
            ),

            // شريط المعلومات العلوي (يظهر عند النقر على الشاشة بوضع ملء الشاشة)
            if (_isUiVisible)
              Positioned(
                top: 0,
                left: 0,
                right: 0,
                child: Container(
                  color: Colors.black.withOpacity(0.75),
                  padding: EdgeInsets.only(
                    top: MediaQuery.of(context).padding.top + 8,
                    bottom: 12,
                    left: 16,
                    right: 16,
                  ),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      IconButton(
                        icon: const Icon(Icons.arrow_forward, color: Colors.white),
                        onPressed: () {
                          Navigator.pop(context);
                        },
                      ),
                      Text(
                        'الصفحة $_currentPage من 604',
                        style: const TextStyle(
                          color: Colors.white,
                          fontSize: 18,
                          fontFamily: 'Amiri',
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      IconButton(
                        icon: const Icon(Icons.bookmark_border, color: Colors.white),
                        onPressed: () {
                          ScaffoldMessenger.of(context).showSnackBar(
                            const SnackBar(content: Text('تم حفظ العلامة المرجعية بنجاح')),
                          );
                        },
                      ),
                    ],
                  ),
                ),
              ),

            // شريط التنقل السفلي رقم الصفحة السريعة (يظهر عند النقر على الشاشة)
            if (_isUiVisible)
              Positioned(
                bottom: 0,
                left: 0,
                right: 0,
                child: Container(
                  color: Colors.black.withOpacity(0.75),
                  padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 24),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      const Text(
                        'اسحب يميناً أو يساراً للتنقل بين الصفحات',
                        style: TextStyle(color: Colors.white70, fontSize: 14, fontFamily: 'Amiri'),
                      ),
                    ],
                  ),
                ),
              ),
          ],
        ),
      ),
    );
  }
}
