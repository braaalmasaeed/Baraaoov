import 'dart:async';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart' as intl;
import 'package:hijri/hijri_calendar.dart';
import '../data/muezzins_data.dart';
import '../services/prayer_calculator.dart';
import '../services/storage_service.dart';
import '../services/background_prayer_service.dart';
import 'settings_screen.dart';

class HomeScreen extends StatefulWidget {
  final VoidCallback onThemeChanged;
  const HomeScreen({super.key, required this.onThemeChanged});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

// رسم شكل المحراب (Islamic Arch Clipper)
class MihrabClipper extends CustomClipper<Path> {
  @override
  Path getClip(Size size) {
    final path = Path();
    final w = size.width;
    final h = size.height;

    path.moveTo(0, h);
    path.lineTo(0, h * 0.25);
    path.quadraticBezierTo(w * 0.5, -h * 0.1, w, h * 0.25);
    path.lineTo(w, h);
    path.close();
    return path;
  }

  @override
  bool shouldReclip(CustomClipper<Path> oldClipper) => false;
}

class _HomeScreenState extends State<HomeScreen> {
  final double _latitude = 21.3891;
  final double _longitude = 39.8579;
  
  PrayerTimesResult? _prayerTimes;
  Map<String, AlertType> _alertSettings = {};
  String _locationName = 'مكة المكرمة';
  
  Timer? _timer;
  Duration _timeRemaining = Duration.zero;
  String _nextPrayerName = 'الفجر';
  DateTime _currentTime = DateTime.now();
  
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    _loadData();
    BackgroundPrayerService.startService(context);
    _timer = Timer.periodic(const Duration(seconds: 1), (_) {
      setState(() {
        _currentTime = DateTime.now();
      });
      _updateCountdown();
    });
  }

  @override
  void dispose() {
    _timer?.cancel();
    BackgroundPrayerService.stopService();
    super.dispose();
  }

  Future<void> _loadData() async {
    try {
      final loc = await StorageService.getUserLocation() ?? 'مكة المكرمة';
      final alerts = await StorageService.getAlertSettings();
      
      final coords = PrayerCalculator.getCoordinatesForLocation(loc);
      final lat = coords['lat'] ?? 21.3891;
      final lng = coords['lng'] ?? 39.8579;

      final now = DateTime.now();
      final times = PrayerCalculator.calculate(
        date: now,
        latitude: lat,
        longitude: lng,
      );

      if (mounted) {
        setState(() {
          _locationName = loc;
          _alertSettings = alerts;
          _prayerTimes = times;
          _isLoading = false;
        });
      }

      _updateCountdown();
    } catch (e) {
      if (mounted) {
        setState(() {
          _isLoading = false;
          // تعيين قيم افتراضية لمنع الشاشة الفارغة عند حدوث خطأ
          _prayerTimes = PrayerCalculator.calculate(
            date: DateTime.now(),
            latitude: 21.3891,
            longitude: 39.8579,
          );
        });
      }
    }
  }

  void _updateCountdown() {
    if (_prayerTimes == null) return;

    final now = DateTime.now();
    final prayers = {
      'الفجر': _prayerTimes!.fajr,
      'الشروق': _prayerTimes!.sunrise,
      'الظهر': _prayerTimes!.dhuhr,
      'العصر': _prayerTimes!.asr,
      'المغرب': _prayerTimes!.maghrib,
      'العشاء': _prayerTimes!.isha,
    };

    String nextName = 'الفجر';
    DateTime nextTime = _prayerTimes!.fajr;

    bool found = false;
    for (var entry in prayers.entries) {
      if (entry.value.isAfter(now)) {
        nextName = entry.key;
        nextTime = entry.value;
        found = true;
        break;
      }
    }

    if (!found) {
      nextName = 'الفجر';
      final tomorrow = now.add(const Duration(days: 1));
      final coords = PrayerCalculator.getCoordinatesForLocation(_locationName);
      final tomorrowTimes = PrayerCalculator.calculate(
        date: tomorrow,
        latitude: coords['lat']!,
        longitude: coords['lng']!,
      );
      nextTime = tomorrowTimes.fajr;
    }

    final diff = nextTime.difference(now);

    setState(() {
      _nextPrayerName = nextName;
      _timeRemaining = diff;
    });
  }

  List<Color> _getDynamicBackgroundColors() {
    try {
      final hour = DateTime.now().hour;
      if (hour >= 4 && hour < 7) {
        return [const Color(0xFF2B5876), const Color(0xFF4E4376)];
      } else if (hour >= 7 && hour < 17) {
        return [const Color(0xFF2980B9), const Color(0xFF6DD5FA)];
      } else if (hour >= 17 && hour < 19) {
        return [const Color(0xFF8E44AD), const Color(0xFFE67E22)];
      } else {
        return [const Color(0xFF0F2027), const Color(0xFF203A43), const Color(0xFF2C5364)];
      }
    } catch (_) {
      return [const Color(0xFF0F2027), const Color(0xFF203A43)];
    }
  }

  Future<void> _cyclePrayerSound(String prayerName) async {
    final currentType = _alertSettings[prayerName] ?? AlertType.fullAdhan;
    AlertType nextType;
    switch (currentType) {
      case AlertType.silent:
        nextType = AlertType.fullAdhan;
        break;
      case AlertType.fullAdhan:
        nextType = AlertType.takbeerOnly;
        break;
      case AlertType.takbeerOnly:
        nextType = AlertType.vibrate;
        break;
      case AlertType.vibrate:
        nextType = AlertType.silent;
        break;
    }

    setState(() {
      _alertSettings[prayerName] = nextType;
    });

    await StorageService.saveAlertSettings(_alertSettings);

    String typeNameAr = '';
    switch (nextType) {
      case AlertType.fullAdhan:
        typeNameAr = 'أذان كامل';
        break;
      case AlertType.takbeerOnly:
        typeNameAr = 'تكبير فقط';
        break;
      case AlertType.vibrate:
        typeNameAr = 'اهتزاز';
        break;
      case AlertType.silent:
        typeNameAr = 'صامت';
        break;
    }

    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('تم تحديث تنبيه $prayerName إلى: $typeNameAr'),
          duration: const Duration(seconds: 1),
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    if (_isLoading || _prayerTimes == null) {
      return const Scaffold(
        backgroundColor: Color(0xFF0F2027),
        body: Center(child: CircularProgressIndicator(color: Colors.amber)),
      );
    }

    final bgColors = _getDynamicBackgroundColors();
    final hours = _timeRemaining.inHours;
    final minutes = _timeRemaining.inMinutes.remainder(60);
    final seconds = _timeRemaining.inSeconds.remainder(60);

    final liveClockFormatted = '${_currentTime.hour.toString().padLeft(2, '0')}:${_currentTime.minute.toString().padLeft(2, '0')}:${_currentTime.second.toString().padLeft(2, '0')}';

    final gregorianDateFormatted = intl.DateFormat('EEEE، d MMMM yyyy', 'ar').format(_currentTime);
    
    // Hijri calendar formatting using hijri package
    HijriCalendar.setLocal('ar');
    final hijriNow = HijriCalendar.fromDate(_currentTime);
    final hijriDateFormatted = '${hijriNow.hDay} ${hijriNow.longMonthName} ${hijriNow.hYear} هـ';

    return Scaffold(
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: bgColors,
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
          ),
        ),
        child: SafeArea(
          child: Column(
            children: [
              // 1 & 2. شريط العلوى بدون زر إعدادات ومؤشر موقع قابل للنقر
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.end,
                  children: [
                    InkWell(
                      onTap: () async {
                        await Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (context) => SettingsScreen(onThemeChanged: widget.onThemeChanged),
                          ),
                        );
                        _loadData();
                      },
                      borderRadius: BorderRadius.circular(20),
                      child: Container(
                        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                        decoration: BoxDecoration(
                          color: Colors.white.withOpacity(0.15),
                          borderRadius: BorderRadius.circular(20),
                          border: Border.all(color: Colors.amber.withOpacity(0.5)),
                        ),
                        child: Row(
                          children: [
                            const Icon(Icons.location_on, color: Colors.amber, size: 18),
                            const SizedBox(width: 6),
                            Text(
                              _locationName,
                              style: const TextStyle(color: Colors.white, fontSize: 15, fontWeight: FontWeight.bold),
                            ),
                            const SizedBox(width: 4),
                            const Icon(Icons.arrow_forward_ios, color: Colors.white70, size: 12),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              ),

              // 4, 5, 6, 7, 8. شكل المحراب يضم التاريخ الهجري، الساعة الحية، والتاريخ الميلادي مع العد التنازلي بدقة
              Expanded(
                child: ListView(
                  padding: const EdgeInsets.symmetric(horizontal: 20),
                  children: [
                    const SizedBox(height: 5),
                    ClipPath(
                      clipper: MihrabClipper(),
                      child: Container(
                        width: double.infinity,
                        padding: const EdgeInsets.fromLTRB(20, 25, 20, 20),
                        decoration: BoxDecoration(
                          gradient: LinearGradient(
                            colors: [
                              Colors.black.withOpacity(0.4),
                              Colors.amber.withOpacity(0.15),
                            ],
                            begin: Alignment.topCenter,
                            end: Alignment.bottomCenter,
                          ),
                          border: Border.all(color: Colors.amber.withOpacity(0.5), width: 1.5),
                        ),
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Text(
                              hijriDateFormatted,
                              style: TextStyle(color: Colors.amber.shade200, fontSize: 13, fontWeight: FontWeight.w600),
                            ),
                            const SizedBox(height: 12),

                            Text(
                              liveClockFormatted,
                              style: const TextStyle(
                                color: Colors.white,
                                fontSize: 44,
                                fontWeight: FontWeight.bold,
                                letterSpacing: 2,
                                fontFeatures: [FontFeature.tabularFigures()],
                              ),
                            ),
                            const SizedBox(height: 8),

                            Text(
                              'الوقت المتبقي حتى صلاة $_nextPrayerName: ${hours.toString().padLeft(2, '0')}:${minutes.toString().padLeft(2, '0')}:${seconds.toString().padLeft(2, '0')}',
                              style: TextStyle(color: Colors.amber, fontSize: 14, fontWeight: FontWeight.bold),
                            ),
                            const SizedBox(height: 12),

                            Text(
                              gregorianDateFormatted,
                              style: TextStyle(color: Colors.white70, fontSize: 12),
                            ),
                          ],
                        ),
                      ),
                    ),

                    const SizedBox(height: 20),

                    // 9. وضع الصلاة القادمة (أقرب صلاة قادمة) في صندوق مستقل ومميز
                    _buildNextPrayerStandaloneBox(),

                    const SizedBox(height: 12),

                    // باقي الصلوات مع تفعيل أيقونة الصوت وتجاهل الصلاة القادمة إذا أردنا عرضها منفصلة، أو عرض الكل مع تمييز القادمة
                    _buildPrayerRow('الفجر', _prayerTimes!.fajr, _nextPrayerName == 'الفجر'),
                    _buildPrayerRow('الشروق', _prayerTimes!.sunrise, _nextPrayerName == 'الشروق'),
                    _buildPrayerRow('الظهر', _prayerTimes!.dhuhr, _nextPrayerName == 'الظهر'),
                    _buildPrayerRow('العصر', _prayerTimes!.asr, _nextPrayerName == 'العصر'),
                    _buildPrayerRow('المغرب', _prayerTimes!.maghrib, _nextPrayerName == 'المغرب'),
                    _buildPrayerRow('العشاء', _prayerTimes!.isha, _nextPrayerName == 'العشاء'),
                    const SizedBox(height: 30),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  // صندوق مستقل للصلاة القادمة (أقرب صلاة قادمة) لتتميز بأنها القادمة
  Widget _buildNextPrayerStandaloneBox() {
    DateTime? nextTime;
    switch (_nextPrayerName) {
      case 'الفجر': nextTime = _prayerTimes!.fajr; break;
      case 'الشروق': nextTime = _prayerTimes!.sunrise; break;
      case 'الظهر': nextTime = _prayerTimes!.dhuhr; break;
      case 'العصر': nextTime = _prayerTimes!.asr; break;
      case 'المغرب': nextTime = _prayerTimes!.maghrib; break;
      case 'العشاء': nextTime = _prayerTimes!.isha; break;
      default: nextTime = _prayerTimes!.fajr;
    }

    final timeFormatted = '${nextTime.hour.toString().padLeft(2, '0')}:${nextTime.minute.toString().padLeft(2, '0')}';
    final alertType = _alertSettings[_nextPrayerName] ?? AlertType.fullAdhan;

    IconData alertIcon;
    switch (alertType) {
      case AlertType.fullAdhan: alertIcon = Icons.volume_up; break;
      case AlertType.takbeerOnly: alertIcon = Icons.notifications_active; break;
      case AlertType.vibrate: alertIcon = Icons.vibration; break;
      case AlertType.silent: alertIcon = Icons.notifications_off; break;
    }

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 14),
      decoration: BoxDecoration(
        color: Colors.amber.withOpacity(0.25),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: Colors.amber,
          width: 2,
        ),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.3),
            blurRadius: 10,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Row(
            children: [
              InkWell(
                onTap: () => _cyclePrayerSound(_nextPrayerName),
                borderRadius: BorderRadius.circular(20),
                child: Padding(
                  padding: const EdgeInsets.all(4.0),
                  child: Icon(alertIcon, color: Colors.amber, size: 24),
                ),
              ),
              const SizedBox(width: 14),
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    'الصلاة القادمة',
                    style: TextStyle(color: Colors.amberAccent, fontSize: 12, fontWeight: FontWeight.bold),
                  ),
                  const SizedBox(height: 2),
                  Text(
                    _nextPrayerName,
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ],
              ),
            ],
          ),
          Column(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              Text(
                timeFormatted,
                style: const TextStyle(
                  color: Colors.amber,
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                ),
              ),
              const SizedBox(height: 2),
              Text(
                '${_timeRemaining.inHours.toString().padLeft(2, '0')}:${(_timeRemaining.inMinutes.remainder(60)).toString().padLeft(2, '0')}:${(_timeRemaining.inSeconds.remainder(60)).toString().padLeft(2, '0')}',
                style: const TextStyle(color: Colors.white70, fontSize: 11),
              ),
            ],
          ),
        ],
      ),
    );
  }

  // صف الصلوات العادية مع تفعيل أيقونة الصوت
  Widget _buildPrayerRow(String name, DateTime time, bool isNext) {
    final timeFormatted = '${time.hour.toString().padLeft(2, '0')}:${time.minute.toString().padLeft(2, '0')}';
    final alertType = _alertSettings[name] ?? AlertType.fullAdhan;

    IconData alertIcon;
    switch (alertType) {
      case AlertType.fullAdhan:
        alertIcon = Icons.volume_up;
        break;
      case AlertType.takbeerOnly:
        alertIcon = Icons.notifications_active;
        break;
      case AlertType.vibrate:
        alertIcon = Icons.vibration;
        break;
      case AlertType.silent:
        alertIcon = Icons.notifications_off;
        break;
    }

    return Container(
      margin: const EdgeInsets.symmetric(vertical: 5),
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 11),
      decoration: BoxDecoration(
        color: isNext ? Colors.amber.withOpacity(0.15) : Colors.white.withOpacity(0.06),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: isNext ? Colors.amber.withOpacity(0.6) : Colors.transparent,
          width: 1.5,
        ),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Row(
            children: [
              InkWell(
                onTap: () => _cyclePrayerSound(name),
                borderRadius: BorderRadius.circular(20),
                child: Padding(
                  padding: const EdgeInsets.all(4.0),
                  child: Icon(alertIcon, color: isNext ? Colors.amber : Colors.white70, size: 20),
                ),
              ),
              const SizedBox(width: 12),
              Text(
                name,
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 16,
                  fontWeight: isNext ? FontWeight.bold : FontWeight.normal,
                ),
              ),
            ],
          ),
          Text(
            timeFormatted,
            style: TextStyle(
              color: isNext ? Colors.amber : Colors.white,
              fontSize: 16,
              fontWeight: isNext ? FontWeight.bold : FontWeight.normal,
            ),
          ),
        ],
      ),
    );
  }
}
