import 'package:flutter/material.dart';
import '../data/azkar_data.dart';
import 'azkar_detail_screen.dart';

class AzkarScreen extends StatefulWidget {
  const AzkarScreen({Key? key}) : super(key: key);

  @override
  State<AzkarScreen> createState() => _AzkarScreenState();
}

class _AzkarScreenState extends State<AzkarScreen> {
  double _fontSize = 18.0;

  final List<Map<String, dynamic>> _categoryMeta = [
    {
      'key': 'morning',
      'title': 'أذكار الصباح',
      'subtitle': '19 ذكراً • التحصن والبركة',
      'icon': Icons.wb_sunny,
      'color': Colors.amber.shade700,
    },
    {
      'key': 'evening',
      'title': 'أذكار المساء',
      'subtitle': '19 ذكراً • الحفظ والاطمئنان',
      'icon': Icons.nightlight_round,
      'color': Colors.indigo.shade700,
    },
    {
      'key': 'prayer',
      'title': 'أذكار الصلاة',
      'subtitle': '9 أذكار • التسبيح والتعقيب',
      'icon': Icons.mosque,
      'color': Colors.green.shade700,
    },
    {
      'key': 'sleep',
      'title': 'أذكار النوم',
      'subtitle': '9 أذكار • الطمأنينة والوقاية',
      'icon': Icons.bed,
      'color': Colors.purple.shade700,
    },
    {
      'key': 'wake_up',
      'title': 'أذكار الاستيقاظ',
      'subtitle': '4 أذكار • الشكر والإحياء',
      'icon': Icons.alarm,
      'color': Colors.teal.shade700,
    },
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'حصن المسلم - الأذكار',
          style: TextStyle(fontFamily: 'Amiri', fontWeight: FontWeight.bold),
        ),
        centerTitle: true,
        actions: [
          PopupMenuButton<String>(
            icon: const Icon(Icons.text_format),
            onSelected: (value) {
              setState(() {
                if (value == 'increase' && _fontSize < 28.0) {
                  _fontSize += 2.0;
                } else if (value == 'decrease' && _fontSize > 12.0) {
                  _fontSize -= 2.0;
                }
              });
            },
            itemBuilder: (context) => [
              const PopupMenuItem(
                value: 'increase',
                child: Row(
                  children: [
                    Icon(Icons.zoom_in, color: Colors.black54),
                    SizedBox(width: 8),
                    Text('تكبير الخط'),
                  ],
                ),
              ),
              const PopupMenuItem(
                value: 'decrease',
                child: Row(
                  children: [
                    Icon(Icons.zoom_out, color: Colors.black54),
                    SizedBox(width: 8),
                    Text('تصغير الخط'),
                  ],
                ),
              ),
            ],
          ),
        ],
      ),
      body: ListView.builder(
        padding: const EdgeInsets.all(16),
        itemCount: _categoryMeta.length,
        itemBuilder: (context, index) {
          final meta = _categoryMeta[index];
          final categoryObj = AzkarData.categories.firstWhere(
            (c) => c.key == meta['key'],
            orElse: () => AzkarData.categories.first,
          );

          return Card(
            elevation: 4,
            margin: const EdgeInsets.symmetric(vertical: 8),
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
            child: InkWell(
              borderRadius: BorderRadius.circular(15),
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => AzkarDetailScreen(initialCategory: categoryObj),
                  ),
                );
              },
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Row(
                  children: [
                    CircleAvatar(
                      radius: 28,
                      backgroundColor: meta['color'],
                      child: Icon(meta['icon'], color: Colors.white, size: 28),
                    ),
                    const SizedBox(width: 16),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            meta['title'],
                            style: TextStyle(
                              fontSize: _fontSize + 2,
                              fontWeight: FontWeight.bold,
                              fontFamily: 'Amiri',
                              color: Colors.green.shade900,
                            ),
                          ),
                          const SizedBox(height: 4),
                          Text(
                            meta['subtitle'],
                            style: TextStyle(
                              fontSize: _fontSize - 2,
                              color: Colors.grey.shade600,
                              fontFamily: 'Amiri',
                            ),
                          ),
                        ],
                      ),
                    ),
                    const Icon(Icons.arrow_forward_ios, color: Colors.grey, size: 18),
                  ],
                ),
              ),
            ),
          );
        },
      ),
    );
  }
}
