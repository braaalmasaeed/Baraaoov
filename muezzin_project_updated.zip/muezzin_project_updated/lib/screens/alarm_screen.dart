import 'package:flutter/material.dart';

/// شاشة التنبيه الكاملة عند دخول وقت الصلاة
/// تعرض صورة مسجد جميلة مع زر إغلاق صغير (X) في أعلى يمين الصورة لإيقاف الأذان وإغلاق النافذة
class AlarmScreen extends StatelessWidget {
  final String prayerName;
  final String muezzinName;
  final VoidCallback onStop;

  const AlarmScreen({
    Key? key,
    required this.prayerName,
    required this.muezzinName,
    required this.onStop,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: Stack(
        fit: StackFit.expand,
        children: [
          // 1. خلفية تعبيرية لصورة مسجد جميلة وعالية الجودة
          ShaderMask(
            shaderCallback: (rect) {
              return LinearGradient(
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
                colors: [Colors.black.withOpacity(0.3), Colors.black.withOpacity(0.8)],
              ).createShader(rect);
            },
            blendMode: BlendMode.darken,
            child: Container(
              decoration: const BoxDecoration(
                color: Color(0xFF1B2A1E),
              ),
              child: Center(
                child: Icon(
                  Icons.mosque,
                  size: 140,
                  color: Colors.amber.shade200,
                ),
              ),
            ),
          ),

          // 2. المحتوى والمعلومات في المنتصف
          SafeArea(
            child: Padding(
              padding: const EdgeInsets.all(24.0),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  const Text(
                    'حين المنادى للصلاة',
                    style: TextStyle(
                      color: Colors.white70,
                      fontSize: 20,
                      fontFamily: 'Amiri',
                    ),
                  ),
                  const SizedBox(height: 12),
                  Text(
                    'حان الآن وقت صلاة $prayerName',
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      color: Colors.amber.shade300,
                      fontSize: 32,
                      fontWeight: FontWeight.bold,
                      fontFamily: 'Amiri',
                    ),
                  ),
                  const SizedBox(height: 8),
                  Text(
                    'المؤذن: $muezzinName',
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 18,
                    ),
                  ),
                  const SizedBox(height: 60),
                  // نبضات أو أيقونة تشير إلى عمل الأذان
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
                    decoration: BoxDecoration(
                      color: Colors.green.shade800.withOpacity(0.8),
                      borderRadius: BorderRadius.circular(30),
                      border: Border.all(color: Colors.amber.shade300, width: 1.5),
                    ),
                    child: const Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Icon(Icons.volume_up, color: Colors.white),
                        SizedBox(width: 10),
                        Text(
                          'جري أذان الصلاة...',
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: 16,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),

          // 3. زر إغلاق صغير (X) في أعلى يمين الصورة لإيقاف الأذان وإغلاق النافذة
          Positioned(
            top: 40,
            right: 20,
            child: Material(
              color: Colors.transparent,
              child: InkWell(
                onTap: onStop,
                borderRadius: BorderRadius.circular(25),
                child: Container(
                  padding: const EdgeInsets.all(10),
                  decoration: BoxDecoration(
                    color: Colors.black.withOpacity(0.5),
                    shape: BoxShape.circle,
                    border: Border.all(color: Colors.white30, width: 1),
                  ),
                  child: const Icon(
                    Icons.close,
                    color: Colors.white,
                    size: 24,
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
