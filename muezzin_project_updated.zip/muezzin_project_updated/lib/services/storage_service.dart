import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';

enum AlertType {
  fullAdhan,
  takbeerOnly,
  silent,
  vibrate,
}

class StorageService {
  static const _secureStorage = FlutterSecureStorage();
  static const String _keySecureToken = 'secure_app_auth_token';
  
  static const String _keyPrayerAlerts = 'prayer_alerts_map';
  static const String _keySelectedMuezzin = 'selected_muezzin_id';
  static const String _keyUserLocation = 'user_location_name';
  static const String _keyIs24Hour = 'is_24_hour_format';
  static const String _keyIsDarkMode = 'is_dark_mode_enabled';
  static const String _keyMonthlyCacheDate = 'monthly_cache_date';
  static const String _keyCachedPrayerTimes = 'cached_prayer_times_map';
  static const String _keyAdhanBgMode = 'adhan_bg_mode'; // 'manual' or 'sequential'
  static const String _keySelectedBgIndex = 'selected_bg_index';
  static const String _keySequentialBgIndex = 'sequential_bg_index';

  static Future<void> saveMonthlyCache({required String locationName, required Map<String, String> prayerTimes}) async {
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setString(_keyUserLocation, locationName);
      await prefs.setString(_keyMonthlyCacheDate, DateTime.now().toIso8601String());
      await prefs.setString(_keyCachedPrayerTimes, jsonEncode(prayerTimes));
    } catch (_) {}
  }

  static Future<bool> isMonthlyCacheValid() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final dateStr = prefs.getString(_keyMonthlyCacheDate);
      if (dateStr == null) return false;
      final cachedDate = DateTime.parse(dateStr);
      final difference = DateTime.now().difference(cachedDate).inDays;
      return difference < 30; // 30 days cache
    } catch (_) {
      return false;
    }
  }

  static Future<void> saveAdhanBgMode(String mode) async {
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setString(_keyAdhanBgMode, mode);
    } catch (_) {}
  }

  static Future<String> getAdhanBgMode() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      return prefs.getString(_keyAdhanBgMode) ?? 'sequential'; // default sequential
    } catch (_) {
      return 'sequential';
    }
  }

  static Future<void> saveSelectedBgIndex(int index) async {
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setInt(_keySelectedBgIndex, index);
    } catch (_) {}
  }

  static Future<int> getSelectedBgIndex() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      return prefs.getInt(_keySelectedBgIndex) ?? 0;
    } catch (_) {
      return 0;
    }
  }

  static Future<int> getNextSequentialBgIndex() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      int current = prefs.getInt(_keySequentialBgIndex) ?? 0;
      int next = (current + 1) % 10; // 10 background images (0 to 9)
      await prefs.setInt(_keySequentialBgIndex, next);
      return current;
    } catch (_) {
      return 0;
    }
  }

  static Future<void> saveAlertSettings(Map<String, AlertType> settings) async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final Map<String, String> data = settings.map((key, value) => MapEntry(key, value.name));
      await prefs.setString(_keyPrayerAlerts, jsonEncode(data));
    } catch (_) {}
  }

  static Future<Map<String, AlertType>> getAlertSettings() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final String? jsonString = prefs.getString(_keyPrayerAlerts);
      if (jsonString == null) {
        return {
          'الفجر': AlertType.fullAdhan,
          'الشروق': AlertType.silent,
          'الظهر': AlertType.fullAdhan,
          'العصر': AlertType.fullAdhan,
          'المغرب': AlertType.fullAdhan,
          'العشاء': AlertType.fullAdhan,
        };
      }
      final Map<String, dynamic> decoded = jsonDecode(jsonString);
      return decoded.map((key, value) {
        AlertType type = AlertType.fullAdhan;
        for (var t in AlertType.values) {
          if (t.name == value) {
            type = t;
            break;
          }
        }
        return MapEntry(key, type);
      });
    } catch (_) {
      return {
        'الفجر': AlertType.fullAdhan,
        'الشروق': AlertType.silent,
        'الظهر': AlertType.fullAdhan,
        'العصر': AlertType.fullAdhan,
        'المغرب': AlertType.fullAdhan,
        'العشاء': AlertType.fullAdhan,
      };
    }
  }

  static Future<void> saveSelectedMuezzin(String muezzinId) async {
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setString(_keySelectedMuezzin, muezzinId);
    } catch (_) {}
  }

  static Future<String> getSelectedMuezzin() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      return prefs.getString(_keySelectedMuezzin) ?? 'm1';
    } catch (_) {
      return 'm1';
    }
  }

  static Future<void> saveUserLocation(String locationName) async {
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setString(_keyUserLocation, locationName);
    } catch (_) {}
  }

  static Future<String> getUserLocation() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      return prefs.getString(_keyUserLocation) ?? 'مكة المكرمة';
    } catch (_) {
      return 'مكة المكرمة';
    }
  }

  static Future<void> saveIs24Hour(bool is24) async {
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setBool(_keyIs24Hour, is24);
    } catch (_) {}
  }

  static Future<bool> getIs24Hour() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      return prefs.getBool(_keyIs24Hour) ?? true;
    } catch (_) {
      return true;
    }
  }

  static Future<void> saveIsDarkMode(bool isDark) async {
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setBool(_keyIsDarkMode, isDark);
    } catch (_) {}
  }

  static Future<bool> getIsDarkMode() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      return prefs.getBool(_keyIsDarkMode) ?? true;
    } catch (_) {
      return true;
    }
  }

  // دوال التخزين الآمن باستخدام flutter_secure_storage (Tool #01)
  static Future<void> saveSecureToken(String token) async {
    try {
      await _secureStorage.write(key: _keySecureToken, value: token);
    } catch (_) {}
  }

  static Future<String?> getSecureToken() async {
    try {
      return await _secureStorage.read(key: _keySecureToken);
    } catch (_) {
      return null;
    }
  }

  static Future<void> clearSecureStorage() async {
    try {
      await _secureStorage.deleteAll();
    } catch (_) {}
  }
}
