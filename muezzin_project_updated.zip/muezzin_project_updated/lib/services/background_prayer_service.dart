import 'dart:async';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:timezone/data/latest_all.dart' as tz;
import 'package:timezone/timezone.dart' as tz;
import '../data/muezzins_data.dart';
import '../services/storage_service.dart';
import '../services/prayer_calculator.dart';
import '../screens/alarm_screen.dart';

/// خدمة تفعيل التشغيل في الخلفية وإدارة الإشعارات المحلية والأذان والصوت محلياً (Offline First)
class BackgroundPrayerService {
  static final FlutterLocalNotificationsPlugin _notificationsPlugin = FlutterLocalNotificationsPlugin();
  static Timer? _checkTimer;
  static bool _isInitialized = false;
  static bool _isAlarmActive = false;

  /// تهيئة نظام الإشعارات المحلية والتوقيت الزمني
  static Future<void> initialize() async {
    if (_isInitialized) return;
    try {
      tz.initializeTimeZones();
      const AndroidInitializationSettings initializationSettingsAndroid =
          AndroidInitializationSettings('@mipmap/ic_launcher');

      const InitializationSettings initializationSettings = InitializationSettings(
        android: initializationSettingsAndroid,
      );

      await _notificationsPlugin.initialize(
        initializationSettings,
        onDidReceiveNotificationResponse: (details) {
          if (kDebugMode) {
            debugPrint('تم النقر على الإشعار: ${details.payload}');
          }
        },
      );
      _isInitialized = true;
    } catch (_) {}
  }

  /// جدولـة الإشعارات المحلية لجميع الصلوات وأذكار الصباح والمساء بدقة
  static Future<void> schedulePrayerNotifications() async {
    try {
      await initialize();
      
      final loc = await StorageService.getUserLocation();
      final coords = PrayerCalculator.getCoordinatesForLocation(loc);
      final now = DateTime.now();
      
      final times = PrayerCalculator.calculate(
        date: now,
        latitude: coords['lat']!,
        longitude: coords['lng']!,
      );

      final settings = await StorageService.getAlertSettings();
      final prayerMap = times.toMap();

      int idCounter = 100;
      for (var entry in prayerMap.entries) {
        final prayerName = entry.key;
        final prayerTime = entry.value;
        final alertType = settings[prayerName] ?? AlertType.fullAdhan;

        // تجاهل الصامت
        if (alertType == AlertType.silent) continue;

        if (prayerTime.isAfter(now)) {
          await _scheduleSingleNotification(
            id: idCounter++,
            title: 'حان الآن وقت صلاة $prayerName',
            body: 'اضغط لفتح التطبيق وسماع الأذان',
            scheduledTime: prayerTime,
          );
        }
      }
    } catch (_) {}
  }

  static Future<void> _scheduleSingleNotification({
    required int id,
    required String title,
    required String body,
    required DateTime scheduledTime,
  }) async {
    try {
      final tzTime = tz.TZDateTime.from(scheduledTime, tz.local);
      const AndroidNotificationDetails androidDetails = AndroidNotificationDetails(
        'muezzin_prayer_channel',
        'مواقيت الصلاة والأذان',
        channelDescription: 'إشعارات مواقيت الصلاة وأوقات الأذان والتنبيهات',
        importance: Importance.max,
        priority: Priority.high,
        sound: RawResourceAndroidNotificationSound('adhan_sound'),
        playSound: true,
        fullScreenIntent: true,
      );

      const NotificationDetails details = NotificationDetails(android: androidDetails);

      // ملاحظة: استخدام schedule مع التقويم الزمني
      await _notificationsPlugin.zonedSchedule(
        id,
        title,
        body,
        tzTime,
        details,
        androidScheduleMode: AndroidScheduleMode.exactAllowWhileIdle,
        uiLocalNotificationDateInterpretation: UILocalNotificationDateInterpretation.absoluteTime,
      );
    } catch (_) {}
  }

  /// بدء خدمة المراقبة في الخلفية
  static void startService(BuildContext context) {
    schedulePrayerNotifications();
    _checkTimer?.cancel();
    _checkTimer = Timer.periodic(const Duration(minutes: 1), (timer) {
      _checkPrayerTime(context);
    });
  }

  /// إيقاف الخدمة
  static void stopService() {
    _checkTimer?.cancel();
    _checkTimer = null;
  }

  /// فحص هل حان وقت الصلاة ومطابقته مع إعدادات المستخدم
  static Future<void> _checkPrayerTime(BuildContext context) async {
    if (_isAlarmActive) return;

    try {
      final now = DateTime.now();
      final loc = await StorageService.getUserLocation();
      final coords = PrayerCalculator.getCoordinatesForLocation(loc);
      final times = PrayerCalculator.calculate(
        date: now,
        latitude: coords['lat']!,
        longitude: coords['lng']!,
      );

      final prayerMap = times.toMap();
      final settings = await StorageService.getAlertSettings();

      for (var entry in prayerMap.entries) {
        final prayerName = entry.key;
        final prayerTime = entry.value;
        final alertType = settings[prayerName] ?? AlertType.fullAdhan;

        // مطابقة الدقيقة الحالية مع وقت الصلاة بالضبط
        if (now.hour == prayerTime.hour && now.minute == prayerTime.minute) {
          if (alertType != AlertType.silent) {
            await triggerAlarm(context, prayerName);
            break;
          }
        }
      }
    } catch (_) {}
  }

  /// تفعيل شاشة التنبيه وتشغيل صوت المؤذن المختار فوراً
  static Future<void> triggerAlarm(BuildContext context, String prayerName) async {
    if (_isAlarmActive) return;
    _isAlarmActive = true;

    try {
      final muezzinId = await StorageService.getSelectedMuezzin();
      final muezzin = MuezzinsData.muezzins.firstWhere(
        (m) => m.id == muezzinId,
        orElse: () => MuezzinsData.muezzins.first,
      );

      if (kDebugMode) {
        debugPrint('تشغيل صوت الأذان للمؤذن: ${muezzin.name} من مسار: ${muezzin.audioAssetPath}');
      }

      if (context.mounted) {
        Navigator.of(context).push(
          MaterialPageRoute(
            fullscreenDialog: true,
            builder: (ctx) => AlarmScreen(
              prayerName: prayerName,
              muezzinName: muezzin.name,
              onStop: () {
                _isAlarmActive = false;
                Navigator.of(ctx).pop();
              },
            ),
          ),
        );
      }
    } catch (_) {
      _isAlarmActive = false;
    }
  }
}
