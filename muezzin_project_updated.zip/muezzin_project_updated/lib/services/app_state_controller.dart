import 'package:flutter/foundation.dart';
import 'storage_service.dart';

class AppStateController extends ChangeNotifier {
  static final AppStateController instance = AppStateController._internal();
  factory AppStateController() => instance;
  AppStateController._internal();

  bool _isDarkMode = true;
  bool get isDarkMode => _isDarkMode;

  bool _is24Hour = true;
  bool get is24Hour => _is24Hour;

  String _selectedMuezzin = 'm1';
  String get selectedMuezzin => _selectedMuezzin;

  String _userLocation = 'مكة المكرمة';
  String get userLocation => _userLocation;

  String _adhanBgMode = 'sequential';
  String get adhanBgMode => _adhanBgMode;

  int _selectedBgIndex = 0;
  int get selectedBgIndex => _selectedBgIndex;

  Map<String, AlertType> _alertSettings = {
    'الفجر': AlertType.fullAdhan,
    'الشروق': AlertType.silent,
    'الظهر': AlertType.fullAdhan,
    'العصر': AlertType.fullAdhan,
    'المغرب': AlertType.fullAdhan,
    'العشاء': AlertType.fullAdhan,
  };
  Map<String, AlertType> get alertSettings => _alertSettings;

  Future<void> loadSettings() async {
    try {
      _isDarkMode = await StorageService.getIsDarkMode();
      _is24Hour = await StorageService.getIs24Hour();
      _selectedMuezzin = await StorageService.getSelectedMuezzin();
      _userLocation = await StorageService.getUserLocation();
      _adhanBgMode = await StorageService.getAdhanBgMode();
      _selectedBgIndex = await StorageService.getSelectedBgIndex();
      _alertSettings = await StorageService.getAlertSettings();
      notifyListeners();
    } catch (_) {}
  }

  Future<void> toggleDarkMode(bool value) async {
    _isDarkMode = value;
    await StorageService.saveIsDarkMode(value);
    notifyListeners();
  }

  Future<void> set24Hour(bool value) async {
    _is24Hour = value;
    await StorageService.saveIs24Hour(value);
    notifyListeners();
  }

  Future<void> setSelectedMuezzin(String muezzinId) async {
    _selectedMuezzin = muezzinId;
    await StorageService.saveSelectedMuezzin(muezzinId);
    notifyListeners();
  }

  Future<void> setUserLocation(String locationName) async {
    _userLocation = locationName;
    await StorageService.saveUserLocation(locationName);
    notifyListeners();
  }

  Future<void> setAdhanBgMode(String mode) async {
    _adhanBgMode = mode;
    await StorageService.saveAdhanBgMode(mode);
    notifyListeners();
  }

  Future<void> setSelectedBgIndex(int index) async {
    _selectedBgIndex = index;
    await StorageService.saveSelectedBgIndex(index);
    notifyListeners();
  }

  Future<void> setAlertSettings(Map<String, AlertType> settings) async {
    _alertSettings = settings;
    await StorageService.saveAlertSettings(settings);
    notifyListeners();
  }
}
