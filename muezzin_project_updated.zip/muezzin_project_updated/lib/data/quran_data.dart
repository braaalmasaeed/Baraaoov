/// بيانات ومعلومات القرآن الكريم الشاملة (السور، الأجزاء، الأحزاب، علامات الوقف، ورابط صور المصحف من مخزن GitHub الرسمي)
class QuranData {
  /// رابط مصدر صور صفحات المصحف الشريف من مخزن GitHub الرسمي (QuranHub/quran-pages-images)
  /// الصفحات من 1 إلى 604 بتنسيق PNG أو JPG (مثال: https://raw.githubusercontent.com/QuranHub/quran-pages-images/main/page_001.png أو مشابه)
  static String getPageImageUrl(int pageNumber) {
    // تنسيق رقم الصفحة بثلاث خانات (مثال: 1 تصبح 001 أو 1)
    final formattedNum = pageNumber.toString().padLeft(3, '0');
    return 'https://raw.githubusercontent.com/QuranHub/quran-pages-images/main/page_$formattedNum.png';
  }

  /// قائمة السور الـ 114 كاملة بترتيب المصحف الشريف مع الصفحة التي تبدأ فيها كل سورة
  static const List<Map<String, dynamic>> surahs = [
    {'number': 1, 'name': 'سورة الفاتحة', 'englishName': 'Al-Faatiha', 'type': 'مكية', 'ayahs': 7, 'page': 1},
    {'number': 2, 'name': 'سورة البقرة', 'englishName': 'Al-Baqara', 'type': 'مدنية', 'ayahs': 286, 'page': 2},
    {'number': 3, 'name': 'سورة آل عمران', 'englishName': 'Aal-Imran', 'type': 'مدنية', 'ayahs': 200, 'page': 50},
    {'number': 4, 'name': 'سورة النساء', 'englishName': 'An-Nisaa', 'type': 'مدنية', 'ayahs': 176, 'page': 77},
    {'number': 5, 'name': 'سورة المائدة', 'englishName': 'Al-Maaida', 'type': 'مدنية', 'ayahs': 120, 'page': 106},
    {'number': 6, 'name': 'سورة الأنعام', 'englishName': 'Al-An\'aam', 'type': 'مكية', 'ayahs': 165, 'page': 128},
    {'number': 7, 'name': 'سورة الأعراف', 'englishName': 'Al-A\'raaf', 'type': 'مكية', 'ayahs': 206, 'page': 151},
    {'number': 8, 'name': 'سورة الأنفال', 'englishName': 'Al-Anfaal', 'type': 'مدنية', 'ayahs': 75, 'page': 177},
    {'number': 9, 'name': 'سورة التوبة', 'englishName': 'At-Tawba', 'type': 'مدنية', 'ayahs': 129, 'page': 187},
    {'number': 10, 'name': 'سورة يونس', 'englishName': 'Yunus', 'type': 'مكية', 'ayahs': 109, 'page': 208},
    {'number': 11, 'name': 'سورة هود', 'englishName': 'Hud', 'type': 'مكية', 'ayahs': 123, 'page': 221},
    {'number': 12, 'name': 'سورة يوسف', 'englishName': 'Yusuf', 'type': 'مكية', 'ayahs': 111, 'page': 235},
    {'number': 13, 'name': 'سورة الرعد', 'englishName': 'Ar-Ra\'d', 'type': 'مدنية', 'ayahs': 43, 'page': 249},
    {'number': 14, 'name': 'سورة إبراهيم', 'englishName': 'Ibrahim', 'type': 'مكية', 'ayahs': 52, 'page': 255},
    {'number': 15, 'name': 'سورة الحجر', 'englishName': 'Al-Hijr', 'type': 'مكية', 'ayahs': 99, 'page': 262},
    {'number': 16, 'name': 'سورة النحل', 'englishName': 'An-Nahl', 'type': 'مكية', 'ayahs': 128, 'page': 267},
    {'number': 17, 'name': 'سورة الإسراء', 'englishName': 'Al-Israa', 'type': 'مكية', 'ayahs': 111, 'page': 282},
    {'number': 18, 'name': 'سورة الكهف', 'englishName': 'Al-Kahf', 'type': 'مكية', 'ayahs': 110, 'page': 293},
    {'number': 19, 'name': 'سورة مريم', 'englishName': 'Maryam', 'type': 'مكية', 'ayahs': 98, 'page': 305},
    {'number': 20, 'name': 'سورة طه', 'englishName': 'Taa-Haa', 'type': 'مكية', 'ayahs': 135, 'page': 312},
    {'number': 21, 'name': 'سورة الأنبياء', 'englishName': 'Al-Anbiyaa', 'type': 'مكية', 'ayahs': 112, 'page': 322},
    {'number': 22, 'name': 'سورة الحج', 'englishName': 'Al-Hajj', 'type': 'مدنية', 'ayahs': 78, 'page': 332},
    {'number': 23, 'name': 'سورة المؤمنون', 'englishName': 'Al-Minoon', 'type': 'مكية', 'ayahs': 118, 'page': 342},
    {'number': 24, 'name': 'سورة النور', 'englishName': 'An-Noor', 'type': 'مدنية', 'ayahs': 64, 'page': 350},
    {'number': 25, 'name': 'سورة الفرقان', 'englishName': 'Al-Furqaan', 'type': 'مكية', 'ayahs': 77, 'page': 359},
    {'number': 26, 'name': 'سورة الشعراء', 'englishName': 'Ash-Shu\'araa', 'type': 'مكية', 'ayahs': 227, 'page': 367},
    {'number': 27, 'name': 'سورة النمل', 'englishName': 'An-Naml', 'type': 'مكية', 'ayahs': 93, 'page': 377},
    {'number': 28, 'name': 'سورة القصص', 'englishName': 'Al-Qasas', 'type': 'مكية', 'ayahs': 88, 'page': 385},
    {'number': 29, 'name': 'سورة العنكبوت', 'englishName': 'Al-Ankaboot', 'type': 'مكية', 'ayahs': 69, 'page': 396},
    {'number': 30, 'name': 'سورة الروم', 'englishName': 'Ar-Room', 'type': 'مكية', 'ayahs': 60, 'page': 404},
    {'number': 31, 'name': 'سورة لقمان', 'englishName': 'Luqman', 'type': 'مكية', 'ayahs': 34, 'page': 411},
    {'number': 32, 'name': 'سورة السجدة', 'englishName': 'As-Sajda', 'type': 'مكية', 'ayahs': 30, 'page': 415},
    {'number': 33, 'name': 'سورة الأحزاب', 'englishName': 'Al-Ahzaab', 'type': 'مدنية', 'ayahs': 73, 'page': 418},
    {'number': 34, 'name': 'سورة سبأ', 'englishName': 'Saba', 'type': 'مكية', 'ayahs': 54, 'page': 428},
    {'number': 35, 'name': 'سورة فاطر', 'englishName': 'Faatir', 'type': 'مكية', 'ayahs': 45, 'page': 434},
    {'number': 36, 'name': 'سورة يس', 'englishName': 'Yaseen', 'type': 'مكية', 'ayahs': 83, 'page': 440},
    {'number': 37, 'name': 'سورة الصافات', 'englishName': 'As-Saaffaat', 'type': 'مكية', 'ayahs': 182, 'page': 446},
    {'number': 38, 'name': 'سورة ص', 'englishName': 'Saad', 'type': 'مكية', 'ayahs': 88, 'page': 453},
    {'number': 39, 'name': 'سورة الزمر', 'englishName': 'Az-Zumar', 'type': 'مكية', 'ayahs': 75, 'page': 458},
    {'number': 40, 'name': 'سورة غافر', 'englishName': 'Ghafir', 'type': 'مكية', 'ayahs': 85, 'page': 467},
    {'number': 41, 'name': 'سورة فصلت', 'englishName': 'Fussilat', 'type': 'مكية', 'ayahs': 54, 'page': 477},
    {'number': 42, 'name': 'سورة الشورى', 'englishName': 'Ash-Shura', 'type': 'مكية', 'ayahs': 53, 'page': 483},
    {'number': 43, 'name': 'سورة الزخرف', 'englishName': 'Az-Zukhruf', 'type': 'مكية', 'ayahs': 89, 'page': 489},
    {'number': 44, 'name': 'سورة الدخان', 'englishName': 'Ad-Dukhaan', 'type': 'مكية', 'ayahs': 59, 'page': 496},
    {'number': 45, 'name': 'سورة الجاثية', 'englishName': 'Al-Jaathiya', 'type': 'مكية', 'ayahs': 37, 'page': 499},
    {'number': 46, 'name': 'سورة الأحقاف', 'englishName': 'Al-Ahqaf', 'type': 'مكية', 'ayahs': 35, 'page': 502},
    {'number': 47, 'name': 'سورة محمد', 'englishName': 'Muhammad', 'type': 'مدنية', 'ayahs': 38, 'page': 507},
    {'number': 48, 'name': 'سورة الفتح', 'englishName': 'Al-Fath', 'type': 'مدنية', 'ayahs': 29, 'page': 511},
    {'number': 49, 'name': 'سورة الحجرات', 'englishName': 'Al-Hujuraat', 'type': 'مدنية', 'ayahs': 18, 'page': 515},
    {'number': 50, 'name': 'سورة ق', 'englishName': 'Qaaf', 'type': 'مكية', 'ayahs': 45, 'page': 518},
    {'number': 51, 'name': 'سورة الذاريات', 'englishName': 'Ad-Dhaariyat', 'type': 'مكية', 'ayahs': 60, 'page': 520},
    {'number': 52, 'name': 'سورة الطور', 'englishName': 'At-Tur', 'type': 'مكية', 'ayahs': 49, 'page': 523},
    {'number': 53, 'name': 'سورة النجم', 'englishName': 'An-Najm', 'type': 'مكية', 'ayahs': 62, 'page': 526},
    {'number': 54, 'name': 'سورة القمر', 'englishName': 'Al-Qamar', 'type': 'مكية', 'ayahs': 55, 'page': 528},
    {'number': 55, 'name': 'سورة الرحمن', 'englishName': 'Ar-Rahmaan', 'type': 'مدنية', 'ayahs': 78, 'page': 531},
    {'number': 56, 'name': 'سورة الواقعة', 'englishName': 'Al-Waaqia', 'type': 'مكية', 'ayahs': 96, 'page': 534},
    {'number': 57, 'name': 'سورة الحديد', 'englishName': 'Al-Hadid', 'type': 'مدنية', 'ayahs': 29, 'page': 537},
    {'number': 58, 'name': 'سورة المجادلة', 'englishName': 'Al-Mujaadila', 'type': 'مدنية', 'ayahs': 22, 'page': 542},
    {'number': 59, 'name': 'سورة الحشر', 'englishName': 'Al-Hashr', 'type': 'مدنية', 'ayahs': 24, 'page': 545},
    {'number': 60, 'name': 'سورة الممتحنة', 'englishName': 'Al-Mumtahana', 'type': 'مدنية', 'ayahs': 13, 'page': 549},
    {'number': 61, 'name': 'سورة الصف', 'englishName': 'As-Saff', 'type': 'مدنية', 'ayahs': 14, 'page': 551},
    {'number': 62, 'name': 'سورة الجمعة', 'englishName': 'Al-Jumu\'a', 'type': 'مدنية', 'ayahs': 11, 'page': 553},
    {'number': 63, 'name': 'سورة المنافقون', 'englishName': 'Al-Munaafiqoon', 'type': 'مدنية', 'ayahs': 11, 'page': 554},
    {'number': 64, 'name': 'سورة التغابن', 'englishName': 'At-Taghaabun', 'type': 'مدنية', 'ayahs': 18, 'page': 556},
    {'number': 65, 'name': 'سورة الطلاق', 'englishName': 'At-Talaaq', 'type': 'مدنية', 'ayahs': 12, 'page': 558},
    {'number': 66, 'name': 'سورة التحريم', 'englishName': 'At-Tahrim', 'type': 'مدنية', 'ayahs': 12, 'page': 560},
    {'number': 67, 'name': 'سورة الملك', 'englishName': 'Al-Mulk', 'type': 'مكية', 'ayahs': 30, 'page': 562},
    {'number': 68, 'name': 'سورة القلم', 'englishName': 'Al-Qalam', 'type': 'مكية', 'ayahs': 52, 'page': 564},
    {'number': 69, 'name': 'سورة الحاقة', 'englishName': 'Al-Haaqqa', 'type': 'مكية', 'ayahs': 52, 'page': 566},
    {'number': 70, 'name': 'سورة المعارج', 'englishName': 'Al-Maarij', 'type': 'مكية', 'ayahs': 44, 'page': 568},
    {'number': 71, 'name': 'سورة نوح', 'englishName': 'Nooh', 'type': 'مكية', 'ayahs': 28, 'page': 570},
    {'number': 72, 'name': 'سورة الجن', 'englishName': 'Al-Jinn', 'type': 'مكية', 'ayahs': 28, 'page': 572},
    {'number': 73, 'name': 'سورة المزمل', 'englishName': 'Al-Muzzammil', 'type': 'مكية', 'ayahs': 20, 'page': 574},
    {'number': 74, 'name': 'سورة المدثر', 'englishName': 'Al-Muddaththir', 'type': 'مكية', 'ayahs': 56, 'page': 575},
    {'number': 75, 'name': 'سورة القيامة', 'englishName': 'Al-Qiyaama', 'type': 'مكية', 'ayahs': 40, 'page': 577},
    {'number': 76, 'name': 'سورة الإنسان', 'englishName': 'Al-Insaan', 'type': 'مدنية', 'ayahs': 31, 'page': 578},
    {'number': 77, 'name': 'سورة المرسلات', 'englishName': 'Al-Mursalaat', 'type': 'مكية', 'ayahs': 50, 'page': 580},
    {'number': 78, 'name': 'سورة النبأ', 'englishName': 'An-Naba', 'type': 'مكية', 'ayahs': 40, 'page': 582},
    {'number': 79, 'name': 'سورة النازعات', 'englishName': 'An-Nazi' 'aat', 'type': 'مكية', 'ayahs': 46, 'page': 583},
    {'number': 80, 'name': 'سورة عبس', 'englishName': 'Abasa', 'type': 'مكية', 'ayahs': 42, 'page': 585},
    {'number': 81, 'name': 'سورة التكوير', 'englishName': 'At-Takwir', 'type': 'مكية', 'ayahs': 29, 'page': 586},
    {'number': 82, 'name': 'سورة الانفطار', 'englishName': 'Al-Infitaar', 'type': 'مكية', 'ayahs': 19, 'page': 587},
    {'number': 83, 'name': 'سورة المطففين', 'englishName': 'Al-Mutaffifin', 'type': 'مكية', 'ayahs': 36, 'page': 587},
    {'number': 84, 'name': 'سورة الانشقاق', 'englishName': 'Al-Inshiqaaq', 'type': 'مكية', 'ayahs': 25, 'page': 589},
    {'number': 85, 'name': 'سورة البروج', 'englishName': 'Al-Burooj', 'type': 'مكية', 'ayahs': 22, 'page': 590},
    {'number': 86, 'name': 'سورة الطارق', 'englishName': 'At-Taariq', 'type': 'مكية', 'ayahs': 17, 'page': 591},
    {'number': 87, 'name': 'سورة الأعلى', 'englishName': 'Al-A\'laa', 'type': 'مكية', 'ayahs': 19, 'page': 591},
    {'number': 88, 'name': 'سورة الغاشية', 'englishName': 'Al-Ghaashiya', 'type': 'مكية', 'ayahs': 26, 'page': 592},
    {'number': 89, 'name': 'سورة الفجر', 'englishName': 'Al-Fajr', 'type': 'مكية', 'ayahs': 30, 'page': 593},
    {'number': 90, 'name': 'سورة البلد', 'englishName': 'Al-Balad', 'type': 'مكية', 'ayahs': 20, 'page': 594},
    {'number': 91, 'name': 'سورة الشمس', 'englishName': 'Ash-Shams', 'type': 'مكية', 'ayahs': 15, 'page': 595},
    {'number': 92, 'name': 'سورة الليل', 'englishName': 'Al-Lail', 'type': 'مكية', 'ayahs': 21, 'page': 595},
    {'number': 93, 'name': 'سورة الضحى', 'englishName': 'Ad-Duha', 'type': 'مكية', 'ayahs': 11, 'page': 596},
    {'number': 94, 'name': 'سورة الشرح', 'englishName': 'Ash-Sharh', 'type': 'مكية', 'ayahs': 8, 'page': 596},
    {'number': 95, 'name': 'سورة التين', 'englishName': 'At-Tin', 'type': 'مكية', 'ayahs': 8, 'page': 597},
    {'number': 96, 'name': 'سورة العلق', 'englishName': 'Al-Alaq', 'type': 'مكية', 'ayahs': 19, 'page': 597},
    {'number': 97, 'name': 'سورة القدر', 'englishName': 'Al-Qadr', 'type': 'مكية', 'ayahs': 5, 'page': 598},
    {'number': 98, 'name': 'سورة البينة', 'englishName': 'Al-Bayyina', 'type': 'مدنية', 'ayahs': 8, 'page': 598},
    {'number': 99, 'name': 'سورة الزلزلة', 'englishName': 'Az-Zalzala', 'type': 'مدنية', 'ayahs': 8, 'page': 599},
    {'number': 100, 'name': 'سورة العاديات', 'englishName': 'Al-Aadiyaat', 'type': 'مكية', 'ayahs': 11, 'page': 599},
    {'number': 101, 'name': 'سورة القارعة', 'englishName': 'Al-Qaari' 'a', 'type': 'مكية', 'ayahs': 11, 'page': 600},
    {'number': 102, 'name': 'سورة التكاثر', 'englishName': 'At-Takaathur', 'type': 'مكية', 'ayahs': 8, 'page': 600},
    {'number': 103, 'name': 'سورة العصر', 'englishName': 'Al-Asr', 'type': 'مكية', 'ayahs': 3, 'page': 601},
    {'number': 104, 'name': 'سورة الهمزة', 'englishName': 'Al-Humaza', 'type': 'مكية', 'ayahs': 9, 'page': 601},
    {'number': 105, 'name': 'سورة الفيل', 'englishName': 'Al-Fil', 'type': 'مكية', 'ayahs': 5, 'page': 601},
    {'number': 106, 'name': 'سورة قريش', 'englishName': 'Quraysh', 'type': 'مكية', 'ayahs': 4, 'page': 602},
    {'number': 107, 'name': 'سورة الماعون', 'englishName': 'Al-Maa' 'oon', 'type': 'مكية', 'ayahs': 7, 'page': 602},
    {'number': 108, 'name': 'سورة الكوثر', 'englishName': 'Al-Kawthar', 'type': 'مكية', 'ayahs': 3, 'page': 602},
    {'number': 109, 'name': 'سورة الكافرون', 'englishName': 'Al-Kaafiroon', 'type': 'مكية', 'ayahs': 6, 'page': 603},
    {'number': 110, 'name': 'سورة النصر', 'englishName': 'An-Nasr', 'type': 'مدنية', 'ayahs': 3, 'page': 603},
    {'number': 111, 'name': 'سورة المسد', 'englishName': 'Al-Masad', 'type': 'مكية', 'ayahs': 5, 'page': 603},
    {'number': 112, 'name': 'سورة الإخلاص', 'englishName': 'Al-Ikhlaas', 'type': 'مكية', 'ayahs': 4, 'page': 604},
    {'number': 113, 'name': 'سورة الفلق', 'englishName': 'Al-Falaq', 'type': 'مكية', 'ayahs': 5, 'page': 604},
    {'number': 114, 'name': 'سورة الناس', 'englishName': 'An-Naas', 'type': 'مكية', 'ayahs': 6, 'page': 604},
  ];

  /// قائمة الأجزاء الـ 30 مع صفحة البداية لكل جزء
  static const List<Map<String, dynamic>> juzs = [
    {'number': 1, 'name': 'الجزء الأول', 'page': 1},
    {'number': 2, 'name': 'الجزء الثاني', 'page': 22},
    {'number': 3, 'name': 'الجزء الثالث', 'page': 42},
    {'number': 4, 'name': 'الجزء الرابع', 'page': 62},
    {'number': 5, 'name': 'الجزء الخامس', 'page': 82},
    {'number': 6, 'name': 'الجزء السادس', 'page': 102},
    {'number': 7, 'name': 'الجزء السابع', 'page': 122},
    {'number': 8, 'name': 'الجزء الثامن', 'page': 142},
    {'number': 9, 'name': 'الجزء التاسع', 'page': 162},
    {'number': 10, 'name': 'الجزء العاشر', 'page': 182},
    {'number': 11, 'name': 'الجزء الحادي عشر', 'page': 202},
    {'number': 12, 'name': 'الجزء الثاني عشر', 'page': 222},
    {'number': 13, 'name': 'الجزء الثالث عشر', 'page': 242},
    {'number': 14, 'name': 'الجزء الرابع عشر', 'page': 262},
    {'number': 15, 'name': 'الجزء الخامس عشر', 'page': 282},
    {'number': 16, 'name': 'الجزء السادس عشر', 'page': 302},
    {'number': 17, 'name': 'الجزء السابع عشر', 'page': 322},
    {'number': 18, 'name': 'الجزء الثامن عشر', 'page': 342},
    {'number': 19, 'name': 'الجزء التاسع عشر', 'page': 362},
    {'number': 20, 'name': 'الجزء العشرون', 'page': 382},
    {'number': 21, 'name': 'الجزء الحادي والعشرون', 'page': 402},
    {'number': 22, 'name': 'الجزء الثاني والعشرون', 'page': 422},
    {'number': 23, 'name': 'الجزء الثالث والعشرون', 'page': 442},
    {'number': 24, 'name': 'الجزء الرابع والعشرون', 'page': 462},
    {'number': 25, 'name': 'الجزء الخامس والعشرون', 'page': 482},
    {'number': 26, 'name': 'الجزء السادس والعشرون', 'page': 502},
    {'number': 27, 'name': 'الجزء السابع والعشرون', 'page': 522},
    {'number': 28, 'name': 'الجزء الثامن والعشرون', 'page': 542},
    {'number': 29, 'name': 'الجزء التاسع والعشرون', 'page': 562},
    {'number': 30, 'name': 'الجزء الثلاثون', 'page': 582},
  ];

  /// قائمة الأحزاب الـ 60 (كل جزء يحتوي على حزبين)
  static List<Map<String, dynamic>> get hizbs {
    List<Map<String, dynamic>> list = [];
    for (int i = 1; i <= 60; i++) {
      // حساب تقريبي لصفحة بداية كل حزب بناء على 604 صفحة مقسمة على 60 حزب (حوالي 10 صفحات لكل حزب)
      int page = ((i - 1) * 10) + 1;
      if (page > 604) page = 604;
      list.add({
        'number': i,
        'name': 'الحزب رقم $i',
        'page': page,
      });
    }
    return list;
  }

  /// قائمة علامات الوقف في المصحف الشريف مع تفاصيل وشرح كل علامة
  static const List<Map<String, String>> stopSigns = [
    {
      'sign': 'مـ',
      'name': 'وقف لازم',
      'description': 'يجب الوقف عنده ولا يجوز الوصل، لأنه قد يغير المعنى مراد الله عز وجل.'
    },
    {
      'sign': 'لا',
      'name': 'وقف ممنوع (لا تبدأ)',
      'description': 'علامة على عدم جواز الوقف، ويجب وصل الكلام ببعضه إلا إذا كان رأس آية.'
    },
    {
      'sign': 'ج',
      'name': 'وقف جائز (استستوى الوصل والوقف)',
      'description': 'يجوز الوقف ويجوز الوصل كلاهما على حد سواء دون ترجيح.'
    },
    {
      'sign': 'صل',
      'name': 'الوصل أولى',
      'description': 'يجوز الوقف والوصل، ولكن الوصل أولى وأحفظ للمعنى القرآني.'
    },
    {
      'sign': 'قلى',
      'name': 'الوقف أولى',
      'description': 'يجوز الوقف والوصل، ولكن الوقف أولى وأفضل لتمام المعنى.'
    },
    {
      'sign': '؞ ؞',
      'name': 'معانقة الوقف (المراقبة)',
      'description': 'توضع المراقبة في موضعين متجاورين، فإن وقفت على أحد الموضعين فلا تجزئ الوقف على الآخر.'
    },
  ];
}
