import 'package:flutter/foundation.dart';

class Muezzin {
  final String id;
  final String name;
  final String location; // الحرم المكي أو الحرم المدني
  final String audioAssetPath;

  const Muezzin({
    required this.id,
    required this.name,
    required this.location,
    required this.audioAssetPath,
  });
}

class MuezzinsData {
  static const List<Muezzin> muezzins = [
    Muezzin(
      id: 'm1',
      name: 'الشيخ علي ملا',
      location: 'الحرم المكي',
      audioAssetPath: 'assets/audio/makkah/ali_mulla.mp3',
    ),
    Muezzin(
      id: 'm2',
      name: 'الشيخ عبد الله خضروش',
      location: 'الحرم المكي',
      audioAssetPath: 'assets/audio/makkah/abdullah_khadshoush.mp3',
    ),
    Muezzin(
      id: 'm3',
      name: 'الشيخ محمد رمل',
      location: 'الحرم المكي',
      audioAssetPath: 'assets/audio/makkah/mohammed_raml.mp3',
    ),
    Muezzin(
      id: 'm4',
      name: 'الشيخ ناجد بن ربيعان',
      location: 'الحرم المكي',
      audioAssetPath: 'assets/audio/makkah/nayef_robiaan.mp3',
    ),
    Muezzin(
      id: 'm5',
      name: 'الشيخ عماد بقرشي',
      location: 'الحرم المكي',
      audioAssetPath: 'assets/audio/makkah/imad_baqarshi.mp3',
    ),
    Muezzin(
      id: 'm6',
      name: 'الشيخ عصام بخاري',
      location: 'الحرم المدني',
      audioAssetPath: 'assets/audio/madinah/esam_bukhari.mp3',
    ),
    Muezzin(
      id: 'm7',
      name: 'الشيخ عمر كمال',
      location: 'الحرم المدني',
      audioAssetPath: 'assets/audio/madinah/omar_kamal.mp3',
    ),
    Muezzin(
      id: 'm8',
      name: 'الشيخ سامي ديولي',
      location: 'الحرم المدني',
      audioAssetPath: 'assets/audio/madinah/sami_diouli.mp3',
    ),
    Muezzin(
      id: 'm9',
      name: 'الشيخ عبدالرحمن حجاج',
      location: 'الحرم المدني',
      audioAssetPath: 'assets/audio/madinah/abdulrahman_hajjaj.mp3',
    ),
    Muezzin(
      id: 'm10',
      name: 'الشيخ أناد الشعيبي',
      location: 'الحرم المدني',
      audioAssetPath: 'assets/audio/madinah/ayad_shuaibi.mp3',
    ),
  ];
}
