import 'dart:async';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'screens/home_screen.dart';
import 'screens/quran_screen.dart';
import 'screens/azkar_screen.dart';
import 'screens/settings_screen.dart';
import 'services/app_state_controller.dart';

void main() async {
  runZonedGuarded(() async {
    WidgetsFlutterBinding.ensureInitialized();
    
    // إعداد معالجة الأخطاء العالمية
    FlutterError.onError = (FlutterErrorDetails details) {
      FlutterError.presentError(details);
      debugPrint('FlutterError caught: ${details.exception}');
    };

    PlatformDispatcher.instance.onError = (Object error, StackTrace stack) {
      debugPrint('PlatformDispatcher error caught: $error');
      return true;
    };

    // تحميل حالة التطبيق الموحدة
    await AppStateController.instance.loadSettings();

    runApp(const MuezzinApp());
  }, (Object error, StackTrace stack) {
    debugPrint('runZonedGuarded error caught: $error');
  });
}

class MuezzinApp extends StatelessWidget {
  const MuezzinApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: AppStateController.instance,
      builder: (context, _) {
        final isDark = AppStateController.instance.isDarkMode;
        return MaterialApp(
          title: 'المؤذن',
          debugShowCheckedModeBanner: false,
          themeMode: isDark ? ThemeMode.dark : ThemeMode.light,
          theme: ThemeData(
            brightness: Brightness.light,
            primarySwatch: Colors.green,
            scaffoldBackgroundColor: const Color(0xFFF5F7F8),
            fontFamily: 'Amiri',
          ),
          darkTheme: ThemeData(
            brightness: Brightness.dark,
            primarySwatch: Colors.green,
            scaffoldBackgroundColor: const Color(0xFF0F2027),
            cardColor: const Color(0xFF1E1E2C),
            fontFamily: 'Amiri',
          ),
          home: const MainNavigationContainer(),
        );
      },
    );
  }
}

class MainNavigationContainer extends StatefulWidget {
  const MainNavigationContainer({Key? key}) : super(key: key);

  @override
  State<MainNavigationContainer> createState() => _MainNavigationContainerState();
}

class _MainNavigationContainerState extends State<MainNavigationContainer> {
  int _currentIndex = 0;

  List<Widget> get _screens => [
    HomeScreen(onThemeChanged: () {
      setState(() {});
    }),
    const QuranScreen(),
    const AzkarScreen(),
    const SettingsScreen(),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: IndexedStack(
        index: _currentIndex,
        children: _screens,
      ),
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _currentIndex,
        type: BottomNavigationBarType.fixed,
        selectedItemColor: Colors.amber,
        unselectedItemColor: Colors.grey,
        onTap: (index) {
          setState(() {
            _currentIndex = index;
          });
        },
        items: const [
          BottomNavigationBarItem(
            icon: Icon(Icons.home),
            label: 'الرئيسية',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.book),
            label: 'القرآن',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.auto_stories),
            label: 'الأذكار',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.settings),
            label: 'الإعدادات',
          ),
        ],
      ),
    );
  }
}
