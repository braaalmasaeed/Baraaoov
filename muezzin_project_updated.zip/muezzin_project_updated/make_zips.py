import os
import zipfile

def create_project_zip(zip_path):
    exclude_dirs = {'.git', '.dart_tool', 'build', '__pycache__'}
    exclude_files = {'.DS_Store', 'muezzin_project.zip', 'muezzin_project_updated.zip'}

    with zipfile.ZipFile(zip_path, 'w', zipfile.ZIP_DEFLATED) as zipf:
        for root, dirs, files in os.walk('.'):
            # Remove excluded dirs in-place
            dirs[:] = [d for d in dirs if d not in exclude_dirs]
            
            for file in files:
                if file in exclude_files:
                    continue
                file_path = os.path.join(root, file)
                archive_name = os.path.relpath(file_path, '.')
                zipf.write(file_path, archive_name)

zip1 = '/storage/emulated/0/Download/muezzin_project_updated.zip'
zip2 = '/storage/emulated/0/Download/muezzin_project.zip'

# Ensure directory exists
os.makedirs('/storage/emulated/0/Download', exist_ok=True)

create_project_zip(zip1)
create_project_zip(zip2)

print(f'Successfully created {zip1} (Size: {os.path.getsize(zip1)} bytes)')
print(f'Successfully created {zip2} (Size: {os.path.getsize(zip2)} bytes)')
