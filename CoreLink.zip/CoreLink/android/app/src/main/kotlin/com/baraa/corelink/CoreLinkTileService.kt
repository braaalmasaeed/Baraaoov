package com.baraa.corelink

import android.content.Intent
import android.os.Build
import android.provider.Settings
import android.service.quicksettings.Tile
import android.service.quicksettings.TileService
import android.widget.Toast

class CoreLinkTileService : TileService() {

    override function onStartListening() {
        super.onStartListening()
        val tile = qsTile
        tile?.state = Tile.STATE_ACTIVE
        tile?.updateTile()
    }

    override fun onClick() {
        super.onClick()
        
        // Check overlay permission first
        val hasOverlay = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            Settings.canDrawOverlays(this)
        } else {
            true
        }

        if (!hasOverlay) {
            Toast.makeText(this, "يرجى منح إذن ظهور الطبقة العائمة أولاً / Grant overlay permission", Toast.LENGTH_LONG).show()
            // Open main app to ask for permissions
            val intent = Intent(this, MainActivity::class.java).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            startActivityAndCollapse(intent)
            return
        }

        // Start Floating service session
        val serviceIntent = Intent(this, CoreLinkFloatingService::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            startForegroundService(serviceIntent)
        } else {
            startService(serviceIntent)
        }
        
        // Collapse notification panel
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            collapsePanels()
        }
    }
}
