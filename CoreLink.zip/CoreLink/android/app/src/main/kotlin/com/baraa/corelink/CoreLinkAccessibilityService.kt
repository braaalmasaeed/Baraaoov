package com.baraa.corelink

accessibility service for zero-latency physical key and mouse event handling,
dispatchGesture touch simulation, long press support, and ignored button filtering.
package com.baraa.corelink

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.AccessibilityServiceInfo
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.view.KeyEvent
import android.view.accessibility.AccessibilityEvent
import android.os.Handler
import android.os.Looper

class CoreLinkAccessibilityService : AccessibilityService() {

    companion object {
        var instance: CoreLinkAccessibilityService? = null
            private set

        // Active button mapping: keycode/identifier -> Button mapping info
        // Format: map of keyCode (Int) -> Map(x, y, isIgnored, isLongPress, transparency, etc.)
        var activeButtonMap: Map<Int, Map<String, Any>> = emptyMap()
            set(value) {
                field = value
                activeInstance?.updateMapping(value)
            }

        private var activeInstance: CoreLinkAccessibilityService? = null
    }

    private val handler = Handler(Looper.getMainLooper())
    private val activeLongPresses = mutableMapOf<Int, Runnable>()

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        activeInstance = this
        
        val info = AccessibilityServiceInfo().apply {
            eventTypes = AccessibilityEvent.TYPES_ALL_MASK
            feedbackType = AccessibilityServiceInfo.FEEDBACK_GENERIC
            flags = AccessibilityServiceInfo.FLAG_REQUEST_FILTER_KEY_EVENTS or
                    AccessibilityServiceInfo.FLAG_RETRIEVE_INTERACTIVE_WINDOWS
            notificationTimeout = 0
        }
        serviceInfo = info
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // Not actively required for interception, but needed by lifecycle
    }

    override fun onInterrupt() {
        instance = null
        activeInstance = null
    }

    fun updateMapping(map: Map<Int, Map<String, Any>>) {
        activeButtonMap = map
    }

    override fun onKeyEvent(event: KeyEvent?): Boolean {
        if (event == null) return super.onKeyEvent(event)

        val keyCode = event.keyCode
        val buttonConfig = activeButtonMap[keyCode] ?: return super.onKeyEvent(event)

        // 1. Check if button is explicitly ignored (`X` marked)
        val isIgnored = buttonConfig["isIgnored"] as? Boolean ?: false
        if (isIgnored) {
            // Completely ignore the button press as requested
            return true
        }

        val x = (buttonConfig["x"] as? Number)?.toFloat() ?: 0f
        val y = (buttonConfig["y"] as? Number)?.toFloat() ?: 0f
        val isLongPress = buttonConfig["isLongPress"] as? Boolean ?: false

        when (event.action) {
            KeyEvent.ACTION_DOWN -> {
                if (event.repeatCount == 0) {
                    if (isLongPress) {
                        // Handle Continuous Long Press
                        if (!activeLongPresses.containsKey(keyCode)) {
                            val runnable = object : Runnable {
                                override fun run() {
                                    dispatchClick(x, y, 1000L) // long duration press
                                    handler.postDelayed(this, 800L)
                                }
                            }
                            activeLongPresses[keyCode] = runnable
                            runnable.run()
                        }
                    } else {
                        // Instant Touch
                        dispatchClick(x, y, 50L)
                    }
                }
                return true
            }
            KeyEvent.ACTION_UP -> {
                if (isLongPress) {
                    // Stop long press loop
                    activeLongPresses[keyCode]?.let {
                        handler.removeCallbacks(it)
                        activeLongPresses.remove(keyCode)
                    }
                }
                return true
            }
        }

        return super.onKeyEvent(event)
    }

    private fun dispatchClick(x: Float, y: Float, duration: Long) {
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.N) {
            val path = Path().apply {
                moveTo(x, y)
            }
            val strokeDescription = GestureDescription.StrokeDescription(path, 0, duration)
            val gestureBuilder = GestureDescription.Builder().addStroke(strokeDescription)
            dispatchGesture(gestureBuilder.build(), object : GestureResultCallback() {
                override fun onCompleted(gestureDescription: GestureDescription?) {
                    super.onCompleted(gestureDescription)
                }
                override fun onCancelled(gestureDescription: GestureDescription?) {
                    super.onCancelled(gestureDescription)
                }
            }, null)
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        activeLongPresses.values.forEach { handler.removeCallbacks(it) }
        activeLongPresses.clear()
        instance = null
        activeInstance = null
    }
}
