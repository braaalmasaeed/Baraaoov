package com.baraa.corelink

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.provider.Settings
import androidx.core.content.ContextCompat
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel
import io.flutter.plugin.common.EventChannel

class MainActivity: FlutterActivity() {
    private val CHANNEL = "com.baraa.corelink/native"
    private val EVENT_CHANNEL = "com.baraa.corelink/events"

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)

        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, CHANNEL).setMethodCallHandler { call, result ->
            try {
                when (call.method) {
                    "checkPermissions" -> {
                        val hasOverlay = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                            Settings.canDrawOverlays(this)
                        } else {
                            true
                        }
                        
                        val hasBt = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                            ContextCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED
                        } else {
                            true
                        }

                        val hasAccessibility = CoreLinkAccessibilityService.instance != null

                        val permissionsMap = mapOf(
                            "overlay" to hasOverlay,
                            "bluetooth" to hasBt,
                            "accessibility" to hasAccessibility
                        )
                        result.success(permissionsMap)
                    }
                    "updateActiveButtons" -> {
                        val mappingsArg = call.argument<Map<String, Map<String, Any>>>("mappings")
                        if (mappingsArg != null) {
                            val convertedMap = mutableMapOf<Int, Map<String, Any>>()
                            for ((keyStr, valueMap) in mappingsArg) {
                                val keyCode = keyStr.toIntOrNull()
                                if (keyCode != null) {
                                    convertedMap[keyCode] = valueMap
                                }
                            }
                            CoreLinkAccessibilityService.activeButtonMap = convertedMap
                        }
                        result.success(true)
                    }
                    "startFloatingService" -> {
                        val intent = android.content.Intent(this, CoreLinkFloatingService::class.java)
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                            startForegroundService(intent)
                        } else {
                            startService(intent)
                        }
                        result.success(true)
                    }
                    "stopFloatingService" -> {
                        val intent = android.content.Intent(this, CoreLinkFloatingService::class.java)
                        stopService(intent)
                        result.success(true)
                    }
                    else -> {
                        result.notImplemented()
                    }
                }
            } catch (e: Exception) {
                result.error("NATIVE_ERROR", e.message, null)
            }
        }

        EventChannel(flutterEngine.dartExecutor.binaryMessenger, EVENT_CHANNEL).setStreamHandler(
            object : EventChannel.StreamHandler {
                override fun onListen(arguments: Object?, events: EventChannel.EventSink?) {
                    // Emit initial connection status safely
                    events?.success(mapOf("status" to "connected", "device" to "Virtual Hub"))
                }

                override fun onCancel(arguments: Object?) {
                    // Cleanup if needed
                }
            }
        )
    }
}
