package com.baraa.corelink

import android.app.Service
import android.content.Intent
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class CoreLinkFloatingService : Service() {
    private var windowManager: WindowManager? = null
    private var floatingView: View? = null
    private var isRunning = false

    override fun onBind(intent: Intent?): IBinder? {
        return null
    }

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (!isRunning) {
            showFloatingWindow()
            isRunning = true
        }
        return START_NOT_STICKY
    }

    private fun showFloatingWindow() {
        try {
            val LAYOUT_FLAG = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            } else {
                WindowManager.LayoutParams.TYPE_PHONE
            }

            // FLAG_NOT_TOUCH_MODAL allows touches outside to pass or be captured depending on config,
// but for strict blocking of background apps while allowing our floating menu interaction,
// we use FLAG_NOT_FOCUSABLE initially or carefully manage touch blocking.
// Per requirements: "التحكم الدقيق في حجب لمس الشاشة الخلفية أثناء الجلسة التفاعلية/التعديل"
            val params = WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                LAYOUT_FLAG,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                        WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT
            ).apply {
                gravity = Gravity.TOP or Gravity.START
                x = 100
                y = 200
            }

            val inflater = LayoutInflater.from(this)
            floatingView = inflater.inflate(R.layout.floating_widget_layout, null)

            // Setup Draggable & UI actions
            setupTouchListener(params)

            val btnFinish = floatingView?.findViewById<Button>(R.id.btnFinish)
            btnFinish?.setOnClickListener {
                stopSelf()
            }

            windowManager?.addView(floatingView, params)
        } catch (e: Exception) {
            e.printStackTrace()
            Toast.makeText(this, "Error showing floating overlay: ${e.message}", Toast.LENGTH_LONG).show()
            stopSelf()
        }
    }

    private fun setupTouchListener(params: WindowManager.LayoutParams) {
        val rootLayout = floatingView?.findViewById<View>(R.id.rootLayout)
        var initialX = 0
        var initialY = 0
        var initialTouchX = 0f
        var initialTouchY = 0f

        rootLayout?.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    initialX = params.x
                    initialY = params.y
                    initialTouchX = event.rawX
                    initialTouchY = event.rawY
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    params.x = initialX + (event.rawX - initialTouchX).toInt()
                    params.y = initialY + (event.rawY - initialTouchY).toInt()
                    
                    // Screen bounds clamping
                    val metrics = resources.displayMetrics
                    if (params.x < 0) params.x = 0
                    if (params.y < 0) params.y = 0
                    if (params.x > metrics.widthPixels - 150) params.x = metrics.widthPixels - 150
                    if (params.y > metrics.heightPixels - 150) params.y = metrics.heightPixels - 150

                    windowManager?.updateViewLayout(floatingView, params)
                    true
                }
                else -> false
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        if (floatingView != null) {
            try {
                windowManager?.removeView(floatingView)
            } catch (e: Exception) {
                e.printStackTrace()
            }
            floatingView = null
        }
        isRunning = false
    }
}
