import 'package:flutter/services.dart';

class MainActivityChannel {
  static const MethodChannel _channel = MethodChannel('com.baraa.corelink/native');

  static Future<Map<String, dynamic>> checkPermissions() async {
    try {
      final Map<Object?, Object?> result = await _channel.invokeMethod('checkPermissions');
      return result.map((key, value) => MapEntry(key.toString(), value));
    } catch (e) {
      return {'overlay': false, 'bluetooth': false, 'accessibility': false};
    }
  }

  static Future<void> updateActiveButtons(Map<String, dynamic> buttonMappings) async {
    try {
      await _channel.invokeMethod('updateActiveButtons', {'mappings': buttonMappings});
    } catch (_) {}
  }

  static Future<void> startFloatingService() async {
    try {
      await _channel.invokeMethod('startFloatingService');
    } catch (_) {}
  }

  static Future<void> stopFloatingService() async {
    try {
      await _channel.invokeMethod('stopFloatingService');
    } catch (_) {}
  }
}
