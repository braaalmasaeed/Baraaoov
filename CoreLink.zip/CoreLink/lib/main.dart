import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'localization.dart';
import 'state_model.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  
  FlutterError.onError = (details) {
    FlutterError.dumpErrorToConsole(details);
  };

  runApp(const CoreLinkApp());
}

class CoreLinkApp extends StatelessWidget {
  const CoreLinkApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (_) => LocalizationProvider()),
        ChangeNotifierProvider(create: (_) => CoreLinkState()),
      ],
      child: Consumer2<LocalizationProvider, CoreLinkState>(
        builder: (context, loc, state, child) {
          return MaterialApp(
            title: 'CoreLink',
            debugShowCheckedModeBanner: false,
            locale: loc.locale,
            builder: (context, widget) {
              return Directionality(
                textDirection: loc.locale.languageCode == 'ar'
                    ? TextDirection.rtl
                    : TextDirection.ltr,
                child: widget!,
              );
            },
            home: const MainScreen(),
          );
        },
      ),
    );
  }
}

class MainScreen extends StatefulWidget {
  const MainScreen({super.key});

  @override
  State<MainScreen> createState() => _MainScreenState();
}

class _MainScreenState extends State<MainScreen> {
  // Navigation stack state for Phase 3 sub-screens: 0 = Main 6 options, 1 = Mouse Settings, 2 = Keyboard Settings, 3 = Deleted Keys
  int _currentSubScreen = 0;
  int? _selectedKeyboardKeyIndex;
  int? _selectedMouseButtonIndex;

  @override
  Widget build(BuildContext context) {
    final loc = Provider.of<LocalizationProvider>(context);
    final state = Provider.of<CoreLinkState>(context);

    return Scaffold(
      appBar: AppBar(
        title: Text(loc.translate('app_title')),
        leading: _currentSubScreen > 0
            ? IconButton(
                icon: const Icon(Icons.arrow_back),
                onPressed: () => setState(() => _currentSubScreen = 0),
                tooltip: loc.translate('back'),
              )
            : null,
        actions: [
          IconButton(
            icon: const Icon(Icons.language),
            onPressed: () => loc.toggleLocale(),
            tooltip: 'Toggle Language',
          ),
          IconButton(
            icon: const Icon(Icons.help_outline),
            onPressed: () => _showHowToUseDialog(context, loc),
            tooltip: loc.translate('how_to_use'),
          ),
          IconButton(
            icon: const Icon(Icons.bookmark_border),
            onPressed: () => _showPresetsDialog(context, loc, state),
            tooltip: loc.translate('presets'),
          ),
        ],
      ),
      body: LayoutBuilder(
        builder: (context, constraints) {
          return SingleChildScrollView(
            padding: const EdgeInsets.all(16.0),
            child: AnimatedSwitcher(
              duration: const Duration(milliseconds: 300),
              child: _buildBodyContent(context, loc, state),
            ),
          );
        },
      ),
    );
  }

  Widget _buildBodyContent(BuildContext context, LocalizationProvider loc, CoreLinkState state) {
    if (_currentSubScreen == 1) {
      return _buildMouseSettingsView(context, loc, state);
    } else if (_currentSubScreen == 2) {
      return _buildKeyboardSettingsView(context, loc, state);
    } else if (_currentSubScreen == 3) {
      return _buildDeletedKeysView(context, loc, state);
    }

    // Main 6 Options / Configurations View with Link States & Grayed out unlinked items
    return Column(
      key: const ValueKey(0),
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        // Quick Permissions Card
        Card(
          elevation: 3,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
          child: Padding(
            padding: const EdgeInsets.all(16.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  loc.translate('permissions'),
                  style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                ),
                const SizedBox(height: 10),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    const Text('SYSTEM_ALERT_WINDOW'),
                    Text(
                      state.overlayPermission ? loc.translate('granted') : loc.translate('not_granted'),
                      style: TextStyle(
                        color: state.overlayPermission ? Colors.green : Colors.red,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 6),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    const Text('BLUETOOTH_CONNECT'),
                    Text(
                      state.bluetoothPermission ? loc.translate('granted') : loc.translate('not_granted'),
                      style: TextStyle(
                        color: state.bluetoothPermission ? Colors.green : Colors.red,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
        const SizedBox(height: 20),

        // Phase 2: The 6 Control Options with Linking & Grayed-out Unlinked state
        Text(
          loc.translate('connection_mode'),
          style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
        ),
        const SizedBox(height: 10),

        // 1. Mouse Cursor Toggle (Grayed out if unlinked)
        Opacity(
          opacity: state.isConnected ? 1.0 : 0.4,
          child: Card(
            child: SwitchListTile(
              secondary: const Icon(Icons.mouse),
              title: Text(loc.translate('mouse_cursor')),
              subtitle: Text(state.isConnected ? '' : loc.translate('unlinked_warning')),
              value: state.mouseEnabled && state.isConnected,
              onChanged: state.isConnected
                  ? (val) => state.toggleMouse(val)
                  : null,
            ),
          ),
        ),

        // 2. Keyboard Toggle (Grayed out if unlinked)
        Opacity(
          opacity: state.isConnected ? 1.0 : 0.4,
          child: Card(
            child: SwitchListTile(
              secondary: const Icon(Icons.keyboard),
              title: Text(loc.translate('keyboard')),
              subtitle: Text(state.isConnected ? '' : loc.translate('unlinked_warning')),
              value: state.keyboardEnabled && state.isConnected,
              onChanged: state.isConnected
                  ? (val) => state.toggleKeyboard(val)
                  : null,
            ),
          ),
        ),

        // 3. Mouse Settings Entry
        Card(
          child: ListTile(
            leading: const Icon(Icons.settings_remote),
            title: Text(loc.translate('mouse_settings')),
            trailing: const Icon(Icons.arrow_forward_ios, size: 16),
            onTap: () => setState(() => _currentSubScreen = 1),
          ),
        ),

        // 4. Keyboard Settings Entry
        Card(
          child: ListTile(
            leading: const Icon(Icons.settings_applications),
            title: Text(loc.translate('keyboard_settings')),
            trailing: const Icon(Icons.arrow_forward_ios, size: 16),
            onTap: () => setState(() => _currentSubScreen = 2),
          ),
        ),

        // 5. Presets Entry
        Card(
          child: ListTile(
            leading: const Icon(Icons.bookmark),
            title: Text(loc.translate('presets')),
            trailing: const Icon(Icons.arrow_forward_ios, size: 16),
            onTap: () => _showPresetsDialog(context, loc, state),
          ),
        ),

        // 6. Finish / Exit Button
        const SizedBox(height: 10),
        ElevatedButton.icon(
          style: ElevatedButton.styleFrom(
            backgroundColor: Colors.red.shade700,
            foregroundColor: Colors.white,
            padding: const EdgeInsets.symmetric(vertical: 14),
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
          ),
          icon: const Icon(Icons.exit_to_app),
          label: Text(loc.translate('finish')),
          onPressed: () {
            state.setConnectionStatus(false);
            ScaffoldMessenger.of(context).showSnackBar(
              SnackBar(content: Text(loc.translate('finish'))),
            );
          },
        ),
      ],
    );
  }

  Widget _buildMouseSettingsView(BuildContext context, LocalizationProvider loc, CoreLinkState state) {
    return Column(
      key: const ValueKey(1),
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text(
              loc.translate('mouse_settings'),
              style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
            ),
            ElevatedButton(
              onPressed: () => setState(() => _currentSubScreen = 0),
              child: Text(loc.translate('save')),
            ),
          ],
        ),
        const SizedBox(height: 15),
        Card(
          child: Padding(
            padding: const EdgeInsets.all(16.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(loc.translate('mouse_speed')),
                Slider(
                  value: state.mouseSpeed,
                  min: 0.5,
                  max: 3.0,
                  divisions: 10,
                  label: state.mouseSpeed.toStringAsFixed(1),
                  onChanged: (val) => state.setMouseSpeed(val),
                ),
                const SizedBox(height: 10),
                ElevatedButton.icon(
                  icon: const Icon(Icons.add),
                  label: Text(loc.translate('add_mouse_button')),
                  onPressed: () => state.addMouseButton('Extra'),
                ),
              ],
            ),
          ),
        ),
        const SizedBox(height: 15),
        Text(loc.translate('right_click_button'), style: const TextStyle(fontWeight: FontWeight.bold)),
        const SizedBox(height: 10),
        SizedBox(
          height: 250,
          child: LayoutBuilder(
            builder: (context, constraints) {
              return Stack(
                children: state.mouseButtons.asMap().entries.map((entry) {
                  int idx = entry.key;
                  var btn = entry.value;
                  bool isCancelled = btn['cancelled'] ?? false;
                  double size = btn['size'] ?? 50.0;
                  double x = btn['x'] ?? 50.0;
                  double y = btn['y'] ?? 50.0;

                  return Positioned(
                    left: x.clamp(0.0, constraints.maxWidth - size),
                    top: y.clamp(0.0, constraints.maxHeight - size),
                    child: GestureDetector(
                      onPanUpdate: (details) {
                        setState(() {
                          btn['x'] = (x + details.delta.dx).clamp(0.0, constraints.maxWidth - size);
                          btn['y'] = (y + details.delta.dy).clamp(0.0, constraints.maxHeight - size);
                          state.updateMouseButton(idx, btn);
                        });
                      },
                      child: Container(
                        width: size,
                        height: size,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          color: isCancelled ? Colors.grey.withOpacity(0.3) : Colors.grey.withOpacity(0.6),
                          border: Border.all(color: Colors.white, width: 2),
                        ),
                        alignment: Alignment.center,
                        child: Stack(
                          alignment: Alignment.center,
                          children: [
                            Text(
                              btn['name'] ?? '',
                              style: const TextStyle(color: Colors.white, fontSize: 12, fontWeight: FontWeight.bold),
                              textAlign: TextAlign.center,
                            ),
                            if (isCancelled)
                              const Icon(Icons.close, color: Colors.red, size: 30),
                          ],
                        ),
                      ),
                    ),
                  );
                }).toList(),
              );
            },
          ),
        ),
      ],
    );
  }

  Widget _buildKeyboardSettingsView(BuildContext context, LocalizationProvider loc, CoreLinkState state) {
    return Column(
      key: const ValueKey(2),
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text(
              loc.translate('keyboard_settings'),
              style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
            ),
            Row(
              children: [
                ElevatedButton(
                  onPressed: () => setState(() => _currentSubScreen = 0),
                  child: Text(loc.translate('save')),
                ),
                const SizedBox(width: 8),
                OutlinedButton(
                  onPressed: () => state.reorderKeyboardKeys(),
                  child: Text(loc.translate('reorder')),
                ),
              ],
            ),
          ],
        ),
        const SizedBox(height: 10),
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceAround,
          children: [
            ElevatedButton.icon(
              icon: const Icon(Icons.add),
              label: Text(loc.translate('add_keyboard_key')),
              onPressed: () => state.addKeyboardKey('Key'),
            ),
            OutlinedButton.icon(
              icon: const Icon(Icons.delete_sweep),
              label: Text(loc.translate('deleted_keys')),
              onPressed: () => setState(() => _currentSubScreen = 3),
            ),
          ],
        ),
        const SizedBox(height: 15),
        if (_selectedKeyboardKeyIndex != null && _selectedKeyboardKeyIndex! < state.keyboardKeys.length)
          Card(
            color: Colors.grey.shade900,
            child: Padding(
              padding: const EdgeInsets.all(12.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('Selected Key: ${state.keyboardKeys[_selectedKeyboardKeyIndex!]['label']}', style: const TextStyle(color: Colors.white)),
                  const SizedBox(height: 8),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(loc.translate('key_size'), style: const TextStyle(color: Colors.white70)),
                      Slider(
                        value: state.keyboardKeys[_selectedKeyboardKeyIndex!]['size'] ?? 50.0,
                        min: 30.0,
                        max: 90.0,
                        onChanged: (val) {
                          setState(() {
                            state.keyboardKeys[_selectedKeyboardKeyIndex!]['size'] = val;
                            state.updateKeyboardKey(_selectedKeyboardKeyIndex!, state.keyboardKeys[_selectedKeyboardKeyIndex!]);
                          });
                        },
                      ),
                    ],
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceAround,
                    children: [
                      FilterChip(
                        label: Text(loc.translate('cancel_key')),
                        selected: state.keyboardKeys[_selectedKeyboardKeyIndex!]['cancelled'] ?? false,
                        onSelected: (val) {
                          setState(() {
                            state.keyboardKeys[_selectedKeyboardKeyIndex!]['cancelled'] = val;
                            state.updateKeyboardKey(_selectedKeyboardKeyIndex!, state.keyboardKeys[_selectedKeyboardKeyIndex!]);
                          });
                        },
                      ),
                      FilterChip(
                        label: Text(loc.translate('long_press')),
                        selected: state.keyboardKeys[_selectedKeyboardKeyIndex!]['longPress'] ?? false,
                        onSelected: (val) {
                          setState(() {
                            state.keyboardKeys[_selectedKeyboardKeyIndex!]['longPress'] = val;
                            state.updateKeyboardKey(_selectedKeyboardKeyIndex!, state.keyboardKeys[_selectedKeyboardKeyIndex!]);
                          });
                        },
                      ),
                      IconButton(
                        icon: const Icon(Icons.delete, color: Colors.red),
                        onPressed: () {
                          state.deleteKeyboardKey(_selectedKeyboardKeyIndex!);
                          setState(() => _selectedKeyboardKeyIndex = null);
                        },
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),
        const SizedBox(height: 10),
        SizedBox(
          height: 300,
          child: LayoutBuilder(
            builder: (context, constraints) {
              return Stack(
                children: state.keyboardKeys.asMap().entries.map((entry) {
                  int idx = entry.key;
                  var keyData = entry.value;
                  bool isCancelled = keyData['cancelled'] ?? false;
                  double size = keyData['size'] ?? 50.0;
                  double x = keyData['x'] ?? 50.0;
                  double y = keyData['y'] ?? 50.0;
                  bool isSelected = _selectedKeyboardKeyIndex == idx;

                  return Positioned(
                    left: x.clamp(0.0, constraints.maxWidth - size),
                    top: y.clamp(0.0, constraints.maxHeight - size),
                    child: GestureDetector(
                      onTap: () => setState(() => _selectedKeyboardKeyIndex = idx),
                      onPanUpdate: (details) {
                        setState(() {
                          keyData['x'] = (x + details.delta.dx).clamp(0.0, constraints.maxWidth - size);
                          keyData['y'] = (y + details.delta.dy).clamp(0.0, constraints.maxHeight - size);
                          state.updateKeyboardKey(idx, keyData);
                        });
                      },
                      child: Container(
                        width: size,
                        height: size,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          color: isCancelled ? Colors.grey.withOpacity(0.2) : Colors.grey.withOpacity(0.6),
                          border: Border.all(color: isSelected ? Colors.blueAccent : Colors.white, width: isSelected ? 3 : 2),
                        ),
                        alignment: Alignment.center,
                        child: Stack(
                          alignment: Alignment.center,
                          children: [
                            Text(
                              keyData['label'] ?? '',
                              style: const TextStyle(color: Colors.white, fontSize: 14, fontWeight: FontWeight.bold),
                              textAlign: TextAlign.center,
                            ),
                            if (isCancelled)
                              const Icon(Icons.close, color: Colors.red, size: 30),
                          ],
                        ),
                      ),
                    ),
                  );
                }).toList(),
              );
            },
          ),
        ),
      ],
    );
  }

  Widget _buildDeletedKeysView(BuildContext context, LocalizationProvider loc, CoreLinkState state) {
    return Column(
      key: const ValueKey(3),
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text(
              loc.translate('deleted_keys'),
              style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
            ),
            IconButton(
              icon: const Icon(Icons.arrow_back),
              onPressed: () => setState(() => _currentSubScreen = 2),
            ),
          ],
        ),
        const SizedBox(height: 10),
        state.deletedKeyboardKeys.isEmpty
            ? Center(child: Text(loc.translate('not_granted')))
            : ListView.builder(
                shrinkWrap: true,
                itemCount: state.deletedKeyboardKeys.length,
                itemBuilder: (context, index) {
                  var item = state.deletedKeyboardKeys[index];
                  return Card(
                    child: ListTile(
                      title: Text('Key: ${item['label']}'),
                      trailing: ElevatedButton(
                        onPressed: () => state.restoreKeyboardKey(index),
                        child: Text(loc.translate('restore')),
                      ),
                    ),
                  );
                },
              ),
      ],
    );
  }

  void _showHowToUseDialog(BuildContext context, LocalizationProvider loc) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text(loc.translate('how_to_use')),
        content: const SingleChildScrollView(
          child: Text(
            '1. Use Quick Settings Tile to launch floating overlay instantly.\n\n'
            '2. Manage Mouse and Keyboard toggles and configurations.\n\n'
            '3. Unlinked items appear grayed out and disabled.\n\n'
            '4. Press Finish to end session and restore normal touch.',
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text(loc.translate('close')),
          ),
        ],
      ),
    );
  }

  void _showPresetsDialog(BuildContext context, LocalizationProvider loc, CoreLinkState state) {
    final TextEditingController presetController = TextEditingController();

    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text(loc.translate('presets')),
        content: SizedBox(
          width: double.maxFinite,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Row(
                children: [
                  Expanded(
                    child: TextField(
                      controller: presetController,
                      decoration: InputDecoration(
                        hintText: loc.translate('preset_name'),
                      ),
                    ),
                  ),
                  IconButton(
                    icon: const Icon(Icons.add_circle, color: Colors.blue),
                    onPressed: () {
                      if (presetController.text.isNotEmpty) {
                        state.saveCurrentAsPreset(presetController.text);
                        presetController.clear();
                        Navigator.pop(context);
                        _showPresetsDialog(context, loc, state);
                      }
                    },
                    tooltip: loc.translate('add_preset'),
                  ),
                ],
              ),
              const SizedBox(height: 10),
              Flexible(
                child: ListView.builder(
                  shrinkWrap: true,
                  itemCount: state.presets.length,
                  itemBuilder: (context, index) {
                    final preset = state.presets[index];
                    return ListTile(
                      title: Text(preset['name'] ?? 'Preset $index'),
                      subtitle: Text('Mode: ${preset['mode']}'),
                      trailing: IconButton(
                        icon: const Icon(Icons.delete, color: Colors.red),
                        onPressed: () {
                          state.deletePreset(index);
                          Navigator.pop(context);
                          _showPresetsDialog(context, loc, state);
                        },
                      ),
                    );
                  },
                ),
              ),
            ],
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text(loc.translate('close')),
          ),
        ],
      ),
    );
  }
}
