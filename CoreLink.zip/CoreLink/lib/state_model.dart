import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'native_channel.dart';

class CoreLinkState extends ChangeNotifier {
  int selectedConnectionMode = 0; // 0: BT, 1: OTG, 2: Wi-Fi, 3: Hybrid, 4: Single
  String keyboardSource = 'Bluetooth';
  String mouseSource = 'OTG';
  String singleDeviceType = 'Keyboard';
  
  List<String> targetApps = ['com.whatsapp', 'com.telegram.messenger'];
  List<Map<String, dynamic>> presets = [];
  
  bool overlayPermission = false;
  bool bluetoothPermission = false;
  bool isConnected = false;
  bool mouseEnabled = true;
  bool keyboardEnabled = true;

  // Phase 3 extensions: Mouse Settings, Keyboard Customization, Deleted Keys, Presets JSON
  double mouseSpeed = 1.0;
  List<Map<String, dynamic>> mouseButtons = [
    {'name': 'Right-Click', 'x': 100.0, 'y': 100.0, 'size': 50.0, 'cancelled': false, 'longPress': false, 'transparency': 1.0}
  ];

  List<Map<String, dynamic>> keyboardKeys = [
    {'label': 'A', 'x': 50.0, 'y': 200.0, 'size': 50.0, 'cancelled': false, 'longPress': false, 'transparency': 1.0},
    {'label': 'B', 'x': 110.0, 'y': 200.0, 'size': 50.0, 'cancelled': false, 'longPress': false, 'transparency': 1.0},
    {'label': 'C', 'x': 170.0, 'y': 200.0, 'size': 50.0, 'cancelled': false, 'longPress': false, 'transparency': 1.0},
    {'label': '1', 'x': 50.0, 'y': 260.0, 'size': 50.0, 'cancelled': false, 'longPress': false, 'transparency': 1.0},
    {'label': '2', 'x': 110.0, 'y': 260.0, 'size': 50.0, 'cancelled': false, 'longPress': false, 'transparency': 1.0},
  ];

  List<Map<String, dynamic>> deletedKeyboardKeys = [];

  void setMouseSpeed(double speed) {
    mouseSpeed = speed;
    saveData();
  }

  void addMouseButton(String name) {
    mouseButtons.add({
      'name': name,
      'x': 150.0,
      'y': 150.0,
      'size': 50.0,
      'cancelled': false,
      'longPress': false,
      'transparency': 1.0,
    });
    saveData();
  }

  void updateMouseButton(int index, Map<String, dynamic> updated) {
    mouseButtons[index] = updated;
    saveData();
  }

  void addKeyboardKey(String label) {
    keyboardKeys.add({
      'label': label,
      'x': 100.0,
      'y': 320.0,
      'size': 50.0,
      'cancelled': false,
      'longPress': false,
      'transparency': 1.0,
    });
    saveData();
  }

  void updateKeyboardKey(int index, Map<String, dynamic> updated) {
    keyboardKeys[index] = updated;
    saveData();
  }

  void deleteKeyboardKey(int index) {
    final removed = keyboardKeys.removeAt(index);
    deletedKeyboardKeys.add(removed);
    saveData();
  }

  void restoreKeyboardKey(int index) {
    final restored = deletedKeyboardKeys.removeAt(index);
    keyboardKeys.add(restored);
    saveData();
  }

  void reorderKeyboardKeys() {
    // Reset positions to default grid layout
    double startX = 50.0;
    double startY = 200.0;
    for (int i = 0; i < keyboardKeys.length; i++) {
      keyboardKeys[i]['x'] = startX + (i % 5) * 60.0;
      keyboardKeys[i]['y'] = startY + (i ~/ 5) * 60.0;
      keyboardKeys[i]['cancelled'] = false;
      keyboardKeys[i]['transparency'] = 1.0;
    }
    saveData();
  }

  CoreLinkState() {
    loadData();
    checkNativePermissions();
  }

  Future<void> checkNativePermissions() async {
    try {
      final res = await MainActivityChannel.checkPermissions();
      overlayPermission = res['overlay'] ?? false;
      bluetoothPermission = res['bluetooth'] ?? false;
      notifyListeners();
    } catch (e) {
      // Fallback
    }
  }

  void toggleMouse(bool val) {
    mouseEnabled = val;
    notifyListeners();
  }

  void toggleKeyboard(bool val) {
    keyboardEnabled = val;
    notifyListeners();
  }

  void setConnectionStatus(bool connected) {
    isConnected = connected;
    notifyListeners();
  }

  Future<void> loadData() async {
    final prefs = await SharedPreferences.getInstance();
    selectedConnectionMode = prefs.getInt('conn_mode') ?? 0;
    keyboardSource = prefs.getString('kb_src') ?? 'Bluetooth';
    mouseSource = prefs.getString('mouse_src') ?? 'OTG';
    singleDeviceType = prefs.getString('single_type') ?? 'Keyboard';
    
    final appsJson = prefs.getString('target_apps');
    if (appsJson != null) {
      targetApps = List<String>.from(jsonDecode(appsJson));
    }
    
    final presetsJson = prefs.getString('presets');
    if (presetsJson != null) {
      presets = List<Map<String, dynamic>>.from(jsonDecode(presetsJson));
    }
    notifyListeners();
  }

  Future<void> saveData() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setInt('conn_mode', selectedConnectionMode);
    await prefs.setString('kb_src', keyboardSource);
    await prefs.setString('mouse_src', mouseSource);
    await prefs.setString('single_type', singleDeviceType);
    await prefs.setString('target_apps', jsonEncode(targetApps));
    await prefs.setString('presets', jsonEncode(presets));
    notifyListeners();
  }

  void setConnectionMode(int mode) {
    selectedConnectionMode = mode;
    saveData();
  }

  void setHybridSources(String kb, String mouse) {
    keyboardSource = kb;
    mouseSource = mouse;
    saveData();
  }

  void setSingleDevice(String type) {
    singleDeviceType = type;
    saveData();
  }

  void addTargetApp(String packageName) {
    if (!targetApps.contains(packageName)) {
      targetApps.add(packageName);
      saveData();
    }
  }

  void removeTargetApp(String packageName) {
    targetApps.remove(packageName);
    saveData();
  }

  void saveCurrentAsPreset(String name) {
    presets.add({
      'name': name,
      'mode': selectedConnectionMode,
      'kb': keyboardSource,
      'mouse': mouseSource,
      'single': singleDeviceType,
      'apps': targetApps,
    });
    saveData();
  }

  void deletePreset(int index) {
    presets.removeAt(index);
    saveData();
  }

  void updatePermissions(bool overlay, bool bt) {
    overlayPermission = overlay;
    bluetoothPermission = bt;
    notifyListeners();
  }
}
