import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

class LocalizationProvider extends ChangeNotifier {
  Locale _locale = const Locale('ar');
  Locale get locale => _locale;

  LocalizationProvider() {
    _loadSavedLocale();
  }

  Future<void> _loadSavedLocale() async {
    final prefs = await SharedPreferences.getInstance();
    final langCode = prefs.getString('core_link_lang') ?? 'ar';
    _locale = Locale(langCode);
    notifyListeners();
  }

  Future<void> toggleLocale() async {
    final newCode = _locale.languageCode == 'ar' ? 'en' : 'ar';
    _locale = Locale(newCode);
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('core_link_lang', newCode);
    notifyListeners();
  }

  String translate(String key) {
    final isAr = _locale.languageCode == 'ar';
    switch (key) {
      case 'app_title':
        return isAr ? 'كورلينك - CoreLink' : 'CoreLink Hub';
      case 'how_to_use':
        return isAr ? 'كيفية الاستخدام' : 'How to Use';
      case 'presets':
        return isAr ? 'الإعدادات المسبقة' : 'Presets';
      case 'permissions':
        return isAr ? 'حالة الأذونات السريعة' : 'Quick Permissions Status';
      case 'connection_mode':
        return isAr ? 'طريقة الربط' : 'Connection Mode';
      case 'target_apps':
        return isAr ? 'التطبيقات المستهدفة' : 'Target Apps';
      case 'mode_bt':
        return isAr ? 'بلوتوث (Bluetooth)' : 'Bluetooth';
      case 'mode_otg':
        return isAr ? 'وصلة USB OTG' : 'USB OTG';
      case 'mode_wifi':
        return isAr ? 'شبكة Wi-Fi' : 'Wi-Fi';
      case 'mode_hybrid':
        return isAr ? 'ربط مستقل/مختلط' : 'Hybrid / Independent';
      case 'mode_single':
        return isAr ? 'جهاز واحد فقط' : 'Single Device Only';
      case 'grant_permission':
        return isAr ? 'منح الإذن' : 'Grant Permission';
      case 'granted':
        return isAr ? 'مفعل' : 'Granted';
      case 'not_granted':
        return isAr ? 'غير مفعل' : 'Not Granted';
      case 'add_app':
        return isAr ? 'إضافة تطبيق مستهدف' : 'Add Target App';
      case 'save_preset':
        return isAr ? 'حفظ كإعداد مسبق' : 'Save Preset';
      case 'close':
        return isAr ? 'إغلاق' : 'Close';
      case 'mouse_cursor':
        return isAr ? 'تفعيل سهم الماوس' : 'Enable Mouse Cursor';
      case 'keyboard':
        return isAr ? 'تفعيل الكيبورد' : 'Enable Keyboard';
      case 'mouse_settings':
        return isAr ? 'إعدادات الماوس' : 'Mouse Settings';
      case 'keyboard_settings':
        return isAr ? 'إعدادات الكيبورد' : 'Keyboard Settings';
      case 'finish':
        return isAr ? 'إنهاء' : 'Finish';
      case 'back':
        return isAr ? 'عودة' : 'Back';
      case 'save':
        return isAr ? 'حفظ' : 'Save';
      case 'unlinked_warning':
        return isAr ? 'غير مربوط (معطل)' : 'Unlinked (Disabled)';
      case 'right_click_button':
        return isAr ? 'زر الماوس الأيمن' : 'Right-Click Button';
      case 'add_mouse_button':
        return isAr ? 'إضافة زر ماوس' : 'Add Mouse Button';
      case 'mouse_speed':
        return isAr ? 'سرعة/حساسية سهم الماوس' : 'Mouse Cursor Speed';
      case 'add_keyboard_key':
        return isAr ? 'إضافة زر كيبورد (+)' : 'Add Key (+)';
      case 'deleted_keys':
        return isAr ? 'المحذوفات' : 'Deleted Keys';
      case 'key_size':
        return isAr ? 'حجم الزر' : 'Key Size';
      case 'cancel_key':
        return isAr ? 'إلغاء (تعطيل بـ X)' : 'Cancel (X)';
      case 'delete_key':
        return isAr ? 'حذف (إلى المحذوفات)' : 'Delete (To Trash)';
      case 'long_press':
        return isAr ? 'الضغط المطوّل' : 'Long Press';
      case 'transparency':
        return isAr ? 'الشفافية' : 'Transparency';
      case 'reorder':
        return isAr ? 'إعادة ترتيب' : 'Reorder';
      case 'restore':
        return isAr ? 'استعادة' : 'Restore';
      case 'preset_name':
        return isAr ? 'اسم الإعداد المسبق' : 'Preset Name';
      case 'add_preset':
        return isAr ? 'إضافة إعداد مسبق (+)' : 'Add Preset (+)';
      default:
        return key;
    }
  }
}
