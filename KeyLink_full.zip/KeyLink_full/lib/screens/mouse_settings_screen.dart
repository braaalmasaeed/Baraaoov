import 'package:flutter/material.dart';
import '../l10n/app_strings.dart';

class MouseSettingsScreen extends StatefulWidget {
  final String language;
  const MouseSettingsScreen({Key? key, required this.language}) : super(key: key);

  @override
  State<MouseSettingsScreen> createState() => _MouseSettingsScreenState();
}

class _MouseSettingsScreenState extends State<MouseSettingsScreen> {
  bool _isEdited = false;
  double _posX = 150.0;
  double _posY = 200.0;
  double _size = 60.0;
  double _pointerSpeed = 1.0;
  bool _showRightClickButton = true;

  @override
  Widget build(BuildContext context) {
    final isAr = widget.language == 'ar';
    return Directionality(
      textDirection: isAr ? TextDirection.rtl : TextDirection.ltr,
      child: Scaffold(
        appBar: AppBar(
          title: Text(AppStrings.get('mouse_settings', widget.language)),
          actions: [
            if (_isEdited)
              TextButton.icon(
                style: TextButton.styleFrom(foregroundColor: Colors.white),
                icon: const Icon(Icons.save),
                label: Text(AppStrings.get('save', widget.language)),
                onPressed: () {
                  setState(() {
                    _isEdited = false;
                    _showRightClickButton = false; // Saves and hides button as requested
                  });
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(content: Text(isAr ? 'تم حفظ إعدادات الماوس وإخفاء زر النقر الأيمن' : 'Mouse settings saved and right-click button hidden')),
                  );
                },
              ),
          ],
        ),
        body: Stack(
          children: [
            // Controls Panel at bottom
            Positioned(
              bottom: 0,
              left: 0,
              right: 0,
              child: Container(
                padding: const EdgeInsets.all(16),
                decoration: const BoxDecoration(
                  color: Colors.white,
                  boxShadow: [BoxShadow(color: Colors.black26, blurRadius: 10)],
                  borderRadius: BorderRadius.vertical(top: Radius.circular(16)),
                ),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      AppStrings.get('pointer_speed', widget.language),
                      style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                    ),
                    Slider(
                      value: _pointerSpeed,
                      min: 0.2,
                      max: 3.0,
                      divisions: 14,
                      label: _pointerSpeed.toStringAsFixed(1),
                      onChanged: (val) {
                        setState(() {
                          _pointerSpeed = val;
                          _isEdited = true;
                        });
                      },
                    ),
                    const Divider(),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.between,
                      children: [
                        Text(
                          AppStrings.get('right_click_button', widget.language),
                          style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                        ),
                        Switch(
                          value: _showRightClickButton,
                          onChanged: (val) {
                            setState(() {
                              _showRightClickButton = val;
                              _isEdited = true;
                            });
                          },
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ),

            // Movable and Resizable Right-Click Floating Button
            if (_showRightClickButton)
              Positioned(
                left: _posX,
                top: _posY,
                child: GestureDetector(
                  onPanUpdate: (details) {
                    setState(() {
                      _posX += details.delta.dx;
                      _posY += details.delta.dy;
                      _isEdited = true;
                    });
                  },
                  child: Container(
                    width: _size,
                    height: _size,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: Colors.amber.shade700.withOpacity(0.85),
                      border: Border.all(color: Colors.white, width: 2),
                      boxShadow: const [BoxShadow(color: Colors.black45, blurRadius: 6)],
                    ),
                    alignment: Alignment.center,
                    child: const Text(
                      'R-CLK',
                      style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 12),
                    ),
                  ),
                ),
              ),
          ],
        ),
      ),
    );
  }
}
