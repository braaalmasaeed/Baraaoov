import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'how_to_use_screen.dart';

class HomeScreen extends StatefulWidget {
  final bool isArabic;
  final VoidCallback onToggleLanguage;

  const HomeScreen({
    Key? key,
    required this.isArabic,
    required this.onToggleLanguage,
  }) : super(key: key);

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  static const MethodChannel _platform = MethodChannel('com.baraa.keylink/overlay');
  
  String _connectionMode = 'Hybrid';
  final List<String> _targetApps = ['com.pubg.imcm', 'com.dts.freefireth'];
  final TextEditingController _appController = TextEditingController();
  
  bool _overlayPermission = false;
  bool _accessibilityService = false;

  @override
  void initState() {
    super.initState();
    _checkPermissions();
  }

  Future<void> _checkPermissions() async {
    bool hasOverlay = false;
    try {
      hasOverlay = await _platform.invokeMethod('checkOverlayPermission') ?? false;
    } catch (_) {}
    setState(() {
      _overlayPermission = hasOverlay;
    });
  }

  Future<void> _requestOverlayPermission() async {
    try {
      await _platform.invokeMethod('requestOverlayPermission');
    } catch (_) {}
  }

  Future<void> _toggleOverlay() async {
    try {
      await _platform.invokeMethod('showOverlay');
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Overlay error: $e')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final isAr = widget.isArabic;
    return Scaffold(
      appBar: AppBar(
        title: Text(isAr ? 'كي لينك - لوحة التحكم' : 'KeyLink Control Panel'),
        actions: [
          IconButton(
            icon: const Icon(Icons.language),
            tooltip: isAr ? 'English' : 'العربية',
            onPressed: widget.onToggleLanguage,
          ),
          IconButton(
            icon: const Icon(Icons.help_outline),
            tooltip: isAr ? 'دليل الاستخدام' : 'How to Use',
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => HowToUseScreen(isArabic: isAr),
                ),
              );
            },
          ),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.all(16.0),
        children: [
          // Connection Mode Selector
          Card(
            elevation: 3,
            child: Padding(
              padding: const EdgeInsets.all(16.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    isAr ? 'وضع الاتصال (Connection Mode)' : 'Connection Mode',
                    style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                  ),
                  const SizedBox(height: 12),
                  DropdownButtonFormField<String>(
                    value: _connectionMode,
                    decoration: const InputDecoration(border: OutlineInputBorder()),
                    items: [
                      DropdownMenuItem(value: 'Bluetooth', child: Text(isAr ? 'بلوتوث (Bluetooth)' : 'Bluetooth')),
                      DropdownMenuItem(value: 'USB OTG', child: Text(isAr ? 'كيبل USB OTG' : 'USB OTG')),
                      DropdownMenuItem(value: 'Wi-Fi', child: Text(isAr ? 'واي فاي (Wi-Fi)' : 'Wi-Fi')),
                      DropdownMenuItem(value: 'Hybrid', child: Text(isAr ? 'هجين (Hybrid مستقل)' : 'Hybrid Independent')),
                    ],
                    onChanged: (val) {
                      if (val != null) setState(() => _connectionMode = val);
                    },
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 16),

          // Target Apps Manager
          Card(
            elevation: 3,
            child: Padding(
              padding: const EdgeInsets.all(16.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    isAr ? 'التطبيقات المستهدفة (Target Apps)' : 'Target Apps Manager',
                    style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                  ),
                  const SizedBox(height: 12),
                  Row(
                    children: [
                      Expanded(
                        child: TextField(
                          controller: _appController,
                          decoration: InputDecoration(
                            hintText: isAr ? 'أدخل اسم الحزمة (مثل com.app)' : 'Enter package name (e.g. com.app)',
                            border: const OutlineInputBorder(),
                          ),
                        ),
                      ),
                      const SizedBox(width: 8),
                      ElevatedButton(
                        onPressed: () {
                          if (_appController.text.trim().isNotEmpty) {
                            setState(() {
                              _targetApps.add(_appController.text.trim());
                              _appController.clear();
                            });
                          }
                        },
                        child: Text(isAr ? 'إضافة' : 'Add'),
                      ),
                    ],
                  ),
                  const SizedBox(height: 12),
                  ..._targetApps.map((app) => Chip(
                        label: Text(app),
                        deleteIcon: const Icon(Icons.close),
                        onDeleted: () {
                          setState(() {
                            _targetApps.remove(app);
                          });
                        },
                      )),
                ],
              ),
            ),
          ),
          const SizedBox(height: 16),

          // Permissions & Quick Settings Guidance Card
          Card(
            elevation: 3,
            child: Padding(
              padding: const EdgeInsets.all(16.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    isAr ? 'الصلاحيات وبلاط الإعدادات السريعة' : 'Permissions & Quick Settings Tile',
                    style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                  ),
                  const SizedBox(height: 12),
                  SwitchListTile(
                    title: Text(isAr ? 'العرض فوق التطبيقات (Display Over Other Apps)' : 'Display Over Other Apps'),
                    subtitle: Text(_overlayPermission ? (isAr ? 'مفعل' : 'Granted') : (isAr ? 'غير مفعل - انقر للتفعيل' : 'Not Granted - Tap to Enable')),
                    value: _overlayPermission,
                    onChanged: (val) => _requestOverlayPermission(),
                  ),
                  SwitchListTile(
                    title: Text(isAr ? 'خدمة الوصول (Accessibility Service)' : 'Accessibility Service'),
                    subtitle: Text(isAr ? 'مطلوبة للمحاكاة والتحكم' : 'Required for touch simulation'),
                    value: _accessibilityService,
                    onChanged: (val) {
                      setState(() => _accessibilityService = val);
                      ScaffoldMessenger.of(context).showSnackBar(
                        SnackBar(content: Text(isAr ? 'يرجى تفعيل خدمة الوصول من إعدادات النظام' : 'Please enable Accessibility in System Settings')),
                      );
                    },
                  ),
                  const Divider(),
                  Padding(
                    padding: const EdgeInsets.symmetric(vertical: 8.0),
                    child: Text(
                      isAr
                          ? '💡 نصيحة سريعة: اسحب شريط الإشعارات العلوي وأضف بلاط (KeyLink Mouse) للإطلاق الفوري للوحة التحكم الشفافة فوق أي لعبة!'
                          : '💡 Quick Tip: Pull down your quick settings panel and add the (KeyLink Mouse) tile to launch the transparent overlay instantly over any game!',
                      style: TextStyle(color: Colors.grey[700], fontSize: 13),
                    ),
                  ),
                  const SizedBox(height: 8),
                  SizedBox(
                    width: double.infinity,
                    child: ElevatedButton.icon(
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.teal,
                        foregroundColor: Colors.white,
                        padding: const EdgeInsets.symmetric(vertical: 12),
                      ),
                      icon: const Icon(Icons.layers),
                      label: Text(
                        isAr ? 'اختبار تفعيل الشفافية العائمة (Test Overlay)' : 'Test Floating Overlay',
                      ),
                      onPressed: _toggleOverlay,
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
