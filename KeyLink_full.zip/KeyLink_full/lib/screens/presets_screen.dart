import 'package:flutter/material.dart';
import '../models/keylink_models.dart';
import '../l10n/app_strings.dart';

class PresetsScreen extends StatefulWidget {
  final String language;
  const PresetsScreen({Key? key, required this.language}) : super(key: key);

  @override
  State<PresetsScreen> createState() => _PresetsScreenState();
}

class _PresetsScreenState extends State<PresetsScreen> {
  final List<PresetProfile> _presets = [
    PresetProfile(
      id: '1',
      name: '1 - PUBG Mobile Standard',
      targetPackage: 'com.pubg.imcm',
      mappings: [
        KeyMapping(id: 'W', label: 'W', x: 100, y: 200),
        KeyMapping(id: 'Fire', label: '🔥', x: 650, y: 220),
      ],
    ),
    PresetProfile(
      id: '2',
      name: '2 - Free Fire Combat',
      targetPackage: 'com.dts.freefireth',
      mappings: [
        KeyMapping(id: 'W', label: 'W', x: 120, y: 220),
        KeyMapping(id: 'Fire', label: '🔥', x: 600, y: 250),
      ],
    ),
    PresetProfile(
      id: '3',
      name: '3 - Custom FPS Pro',
      targetPackage: 'com.fps.game',
      mappings: [
        KeyMapping(id: 'W', label: 'W', x: 100, y: 180),
      ],
    ),
  ];

  String _activePresetId = '1';
  final TextEditingController _nameController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    final isAr = widget.language == 'ar';
    return Directionality(
      textDirection: isAr ? TextDirection.rtl : TextDirection.ltr,
      child: Scaffold(
        appBar: AppBar(
          title: Text(AppStrings.get('presets', widget.language)),
        ),
        body: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            Text(
              AppStrings.get('presets_list', widget.language),
              style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 12),
            ..._presets.map((preset) {
              final isCurrent = preset.id == _activePresetId;
              return Card(
                elevation: isCurrent ? 4 : 1,
                color: isCurrent ? Colors.blue.shade50 : Colors.white,
                child: ListTile(
                  title: Text(
                    preset.name,
                    style: TextStyle(fontWeight: isCurrent ? FontWeight.bold : FontWeight.normal),
                  ),
                  subtitle: Text('Target: ${preset.targetPackage} | Keys: ${preset.mappings.length}'),
                  trailing: ElevatedButton(
                    style: ElevatedButton.styleFrom(
                      backgroundColor: isCurrent ? Colors.blue : Colors.grey.shade200,
                      foregroundColor: isCurrent ? Colors.white : Colors.black87,
                    ),
                    onPressed: () {
                      setState(() {
                        _activePresetId = preset.id;
                      });
                      ScaffoldMessenger.of(context).showSnackBar(
                        SnackBar(content: Text(isAr ? 'تم تطبيق الملف المسبق: ${preset.name}' : 'Applied preset: ${preset.name}')),
                      );
                    },
                    child: Text(isAr ? (isCurrent ? 'مفعل' : 'تطبيق') : (isCurrent ? 'Active' : 'Apply')),
                  ),
                ),
              );
            }).toList(),
            const SizedBox(height: 20),
            ElevatedButton.icon(
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.teal,
                foregroundColor: Colors.white,
                padding: const EdgeInsets.symmetric(vertical: 12),
              ),
              icon: const Icon(Icons.add_circle_outline),
              label: Text(isAr ? 'حفظ التخطيط الحالي كملف مسبق جديد' : 'Save Current Layout as New Preset'),
              onPressed: _showAddNewPresetDialog,
            ),
          ],
        ),
      ),
    );
  }

  void _showAddNewPresetDialog() {
    final isAr = widget.language == 'ar';
    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: Text(isAr ? 'إضافة ملف مسبق جديد' : 'Add New Preset'),
          content: TextField(
            controller: _nameController,
            decoration: InputDecoration(
              hintText: isAr ? 'أدخل اسم الملف المسبق (مثل 4 - Call of Duty)' : 'Enter preset name (e.g. 4 - Game)',
              border: const OutlineInputBorder(),
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: Text(isAr ? 'إلغاء' : 'Cancel'),
            ),
            ElevatedButton(
              onPressed: () {
                if (_nameController.text.trim().isNotEmpty) {
                  setState(() {
                    final newId = '${_presets.length + 1}';
                    _presets.add(PresetProfile(
                      id: newId,
                      name: '$newId - ${_nameController.text.trim()}',
                      targetPackage: 'com.custom.game',
                      mappings: [],
                    ));
                    _activePresetId = newId;
                    _nameController.clear();
                  });
                  Navigator.pop(context);
                }
              },
              child: Text(isAr ? 'حفظ' : 'Save'),
            ),
          ],
        );
      },
    );
  }
}
