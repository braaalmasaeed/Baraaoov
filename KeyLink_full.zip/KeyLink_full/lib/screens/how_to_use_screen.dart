import 'package:flutter/material.dart';
import '../l10n/app_strings.dart';

class HowToUseScreen extends StatelessWidget {
  final String language;
  final ValueChanged<String> onLanguageChanged;

  const HowToUseScreen({
    Key? key,
    required this.language,
    required this.onLanguageChanged,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final isAr = language == 'ar';
    return Directionality(
      textDirection: isAr ? TextDirection.rtl : TextDirection.ltr,
      child: Scaffold(
        appBar: AppBar(
          title: Text(AppStrings.get('how_to_use', language)),
          actions: [
            IconButton(
              icon: const Icon(Icons.language),
              onPressed: () {
                onLanguageChanged(isAr ? 'en' : 'ar');
              },
              tooltip: 'Switch AR / EN',
            ),
          ],
        ),
        body: ListView(
          padding: const EdgeInsets.all(16.0),
          children: [
            Card(
              elevation: 4,
              child: Padding(
                padding: const EdgeInsets.all(16.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      AppStrings.get('developer_options_guide', language),
                      style: const TextStyle(
                        fontSize: 20,
                        fontWeight: FontWeight.bold,
                        color: Colors.blueAccent,
                      ),
                    ),
                    const SizedBox(height: 12),
                    _buildStepItem('1', AppStrings.get('dev_step_1', language)),
                    _buildStepItem('2', AppStrings.get('dev_step_2', language)),
                    _buildStepItem('3', AppStrings.get('dev_step_3', language)),
                    _buildStepItem('4', AppStrings.get('dev_step_4', language)),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 16),
            Card(
              elevation: 4,
              child: Padding(
                padding: const EdgeInsets.all(16.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text(
                      'KeyLink Features & Phase 1 Info',
                      style: TextStyle(
                        fontSize: 20,
                        fontWeight: FontWeight.bold,
                        color: Colors.green,
                      ),
                    ),
                    const SizedBox(height: 12),
                    const Text(
                      '• 100% Free & Open Source\n'
                      '• Zero Ads, Zero Subscriptions, Zero Tracking\n'
                      '• Supports Bluetooth, OTG, Wi-Fi & Hybrid Modes\n'
                      '• Floating Overlay with Mouse Pointer & Keyboard Support\n'
                      '• Key Customization: Cancelled Red-X, Trash Delete, Long Press, Custom Opacity',
                      style: TextStyle(fontSize: 16, height: 1.5),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildStepItem(String number, String text) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8.0),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          CircleAvatar(
            radius: 14,
            backgroundColor: Colors.blueAccent,
            child: Text(
              number,
              style: const TextStyle(color: Colors.white, fontSize: 12),
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Text(
              text,
              style: const TextStyle(fontSize: 16, height: 1.4),
            ),
          ),
        ],
      ),
    );
  }
}
