enum ConnectionMode {
  bluetoothBoth,
  otgBoth,
  wifiBoth,
  hybrid,
}

class KeyLinkSettings {
  ConnectionMode connectionMode;
  String keyboardTransport; // Used in hybrid mode
  String mouseTransport;    // Used in hybrid mode
  bool isMousePointerEnabled;
  bool isKeyboardEnabled;

  KeyLinkSettings({
    this.connectionMode = ConnectionMode.bluetoothBoth,
    this.keyboardTransport = 'bluetooth',
    this.mouseTransport = 'bluetooth',
    this.isMousePointerEnabled = true,
    this.isKeyboardEnabled = true,
  });

  Map<String, dynamic> toJson() => {
    'connectionMode': connectionMode.index,
    'keyboardTransport': keyboardTransport,
    'mouseTransport': mouseTransport,
    'isMousePointerEnabled': isMousePointerEnabled,
    'isKeyboardEnabled': isKeyboardEnabled,
  };

  factory KeyLinkSettings.fromJson(Map<String, dynamic> json) => KeyLinkSettings(
    connectionMode: ConnectionMode.values[json['connectionMode'] ?? 0],
    keyboardTransport: json['keyboardTransport'] ?? 'bluetooth',
    mouseTransport: json['mouseTransport'] ?? 'bluetooth',
    isMousePointerEnabled: json['isMousePointerEnabled'] ?? true,
    isKeyboardEnabled: json['isKeyboardEnabled'] ?? true,
  );
}

class KeyMapping {
  String id;
  String label;
  double x;
  double y;
  double size;
  bool isCancelled; // Red-X state
  bool isDeleted;   // Trash state
  bool isLongPress; // Long press / hold toggle
  bool useCustomOpacity;
  double opacityValue;

  KeyMapping({
    required this.id,
    required this.label,
    required this.x,
    required this.y,
    this.size = 50.0,
    this.isCancelled = false,
    this.isDeleted = false,
    this.isLongPress = false,
    this.useCustomOpacity = false,
    this.opacityValue = 1.0,
  });
}

class PresetProfile {
  String id;
  String name;
  String targetPackage;
  List<KeyMapping> mappings;

  PresetProfile({
    required this.id,
    required this.name,
    required this.targetPackage,
    required this.mappings,
  });
}
