import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'models/keylink_models.dart';
import 'screens/home_screen.dart';
import 'screens/keyboard_settings_screen.dart';
import 'screens/mouse_settings_screen.dart';
import 'screens/presets_screen.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const KeyLinkApp());
}

class KeyLinkApp extends StatefulWidget {
  const KeyLinkApp({Key? key}) : super(key: key);

  @override
  State<KeyLinkApp> createState() => _KeyLinkAppState();
}

class _KeyLinkAppState extends State<KeyLinkApp> {
  bool _isArabic = true;
  int _currentIndex = 0;

  KeyLinkSettings _settings = KeyLinkSettings();
  final List<PresetProfile> _profiles = [
    PresetProfile(
      id: '1',
      name: 'PUBG Mobile',
      targetPackage: 'com.tencent.ig',
      mappings: [
        KeyMapping(id: 'W', label: 'W', x: 100, y: 300),
        KeyMapping(id: 'A', label: 'A', x: 50, y: 380),
        KeyMapping(id: 'S', label: 'S', x: 100, y: 380),
        KeyMapping(id: 'D', label: 'D', x: 150, y: 380),
        KeyMapping(id: 'Space', label: 'Space', x: 800, y: 600),
      ],
    ),
    PresetProfile(
      id: '2',
      name: 'Free Fire',
      targetPackage: 'com.dts.freefireth',
      mappings: [
        KeyMapping(id: 'W', label: 'W', x: 120, y: 320),
        KeyMapping(id: 'Fire', label: 'Left Click', x: 850, y: 450),
      ],
    ),
  ];

  PresetProfile? _activeProfile;

  @override
  void initState() {
    super.initState();
    _activeProfile = _profiles.first;
    _syncNativeAccessibilityMappings();
  }

  Future<void> _syncNativeAccessibilityMappings() async {
    if (_activeProfile == null) return;
    try {
      const MethodChannel platform = MethodChannel('com.baraa.keylink/overlay');
      Map<String, List<double>> mappingsMap = {};
      List<int> cancelledList = [];

      for (var km in _activeProfile!.mappings) {
        if (!km.isDeleted) {
          int keyCode = _mapLabelToKeyCode(km.id);
          if (km.isCancelled) {
            cancelledList.add(keyCode);
          } else {
            mappingsMap[keyCode.toString()] = [km.x, km.y];
          }
        }
      }

      await platform.invokeMethod('updateKeyMappings', {
        'mappings': mappingsMap,
        'cancelled': cancelledList,
      });
    } catch (_) {}
  }

  int _mapLabelToKeyCode(String label) {
    switch (label.toUpperCase()) {
      case 'W': return 51;
      case 'A': return 29;
      case 'S': return 47;
      case 'D': return 32;
      case 'SPACE': return 62;
      default: return 51;
    }
  }

  void _toggleLanguage() {
    setState(() {
      _isArabic = !_isArabic;
    });
  }

  @override
  Widget build(BuildContext context) {
    final screens = [
      HomeScreen(
        isArabic: _isArabic,
        onToggleLanguage: _toggleLanguage,
      ),
      KeyboardSettingsScreen(
        isArabic: _isArabic,
        profile: _activeProfile ?? _profiles.first,
        onProfileChanged: (updatedProfile) {
          setState(() {
            _activeProfile = updatedProfile;
          });
          _syncNativeAccessibilityMappings();
        },
      ),
      MouseSettingsScreen(
        isArabic: _isArabic,
      ),
      PresetsScreen(
        isArabic: _isArabic,
        profiles: _profiles,
        activeProfile: _activeProfile,
        onSelectProfile: (profile) {
          setState(() {
            _activeProfile = profile;
          });
          _syncNativeAccessibilityMappings();
        },
        onAddProfile: (newProfile) {
          setState(() {
            _profiles.add(newProfile);
            _activeProfile = newProfile;
          });
          _syncNativeAccessibilityMappings();
        },
      ),
    ];

    return MaterialApp(
      title: 'KeyLink',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        primarySwatch: Colors.teal,
        useMaterial3: true,
      ),
      locale: Locale(_isArabic ? 'ar' : 'en'),
      builder: (context, child) {
        return Directionality(
          textDirection: _isArabic ? TextDirection.rtl : TextDirection.ltr,
          child: child!,
        );
      },
      home: Scaffold(
        body: screens[_currentIndex],
        bottomNavigationBar: NavigationBar(
          selectedIndex: _currentIndex,
          onDestinationSelected: (idx) {
            setState(() {
              _currentIndex = idx;
            });
          },
          destinations: [
            NavigationDestination(
              icon: const Icon(Icons.home),
              label: _isArabic ? 'الرئيسية' : 'Home',
            ),
            NavigationDestination(
              icon: const Icon(Icons.keyboard),
              label: _isArabic ? 'المفاتيح' : 'Keyboard',
            ),
            NavigationDestination(
              icon: const Icon(Icons.mouse),
              label: _isArabic ? 'الماوس' : 'Mouse',
            ),
            NavigationDestination(
              icon: const Icon(Icons.folder_special),
              label: _isArabic ? 'الملفات والمقاطع' : 'Profiles',
            ),
          ],
        ),
      ),
    );
  }
}
