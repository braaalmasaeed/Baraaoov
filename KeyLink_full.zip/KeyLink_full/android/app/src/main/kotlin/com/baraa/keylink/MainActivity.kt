package com.baraa.keylink

import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.net.Uri
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel

class MainActivity: FlutterActivity() {
    private val CHANNEL = "com.baraa.keylink/overlay"

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, CHANNEL).setMethodCallHandler { call, result ->
            when (call.method) {
                "showOverlay" -> {
                    val intent = Intent(this, OverlayService::class.java).apply {
                        putExtra("action", "SHOW")
                    }
                    startService(intent)
                    result.success(true)
                }
                "hideOverlay" -> {
                    val intent = Intent(this, OverlayService::class.java).apply {
                        putExtra("action", "HIDE")
                    }
                    startService(intent)
                    result.success(true)
                }
                "checkOverlayPermission" -> {
                    result.success(Settings.canDrawOverlays(this))
                }
                "requestOverlayPermission" -> {
                    val intent = Intent(
                        Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:$packageName")
                    )
                    startActivity(intent)
                    result.success(true)
                }
                "checkAccessibilityPermission" -> {
                    val enabled = Settings.Secure.getInt(
                        contentResolver,
                        Settings.Secure.ACCESSIBILITY_ENABLED, 0
                    ) == 1
                    val services = Settings.Secure.getString(
                        contentResolver,
                        Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
                    ) ?: ""
                    val isEnabled = enabled && services.contains(packageName)
                    result.success(isEnabled)
                }
                "requestAccessibilityPermission" -> {
                    val intent = Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)
                    startActivity(intent)
                    result.success(true)
                }
                "updateKeyMappings" -> {
                    val mappingsArg = call.argument<Map<String, List<Double>>>("mappings")
                    val cancelledArg = call.argument<List<Int>>("cancelled")
                    
                    val mappings = mutableMapOf<Int, Pair<Float, Float>>()
                    mappingsArg?.forEach { (keyStr, coords) ->
                        val keyCode = keyStr.toIntOrNull()
                        if (keyCode != null && coords.size >= 2) {
                            mappings[keyCode] = Pair(coords[0].toFloat(), coords[1].toFloat())
                        }
                    }
                    val cancelled = cancelledArg?.toSet() ?: emptySet()
                    KeyLinkAccessibilityService.updateKeyMappings(mappings, cancelled)
                    result.success(true)
                }
                else -> {
                    result.notImplemented()
                }
            }
        }
    }
}
