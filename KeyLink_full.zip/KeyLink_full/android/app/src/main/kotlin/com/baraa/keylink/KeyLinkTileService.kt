package com.baraa.keylink

import android.service.quicksettings.Tile
import android.service.quicksettings.TileService
import android.content.Intent

class KeyLinkTileService : TileService() {
    override "onStartListening"() {
        super.onStartListening()
        val tile = qsTile
        tile?.state = Tile.STATE_ACTIVE
        tile?.updateTile()
    }

    override fun onClick() {
        super.onClick()
        val intent = Intent(this, OverlayService::class.java)
        intent.putExtra("action", "TOGGLE")
        startService(intent)
        
        // Collapse notification shade
        val collapseIntent = Intent(Intent.ACTION_CLOSE_SYSTEM_DIALOGS)
        sendBroadcast(collapseIntent)
    }
}
