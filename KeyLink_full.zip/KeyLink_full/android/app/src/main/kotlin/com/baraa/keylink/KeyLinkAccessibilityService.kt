package com.baraa.keylink

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.view.KeyEvent
import android.view.accessibility.AccessibilityEvent

class KeyLinkAccessibilityService : AccessibilityService() {

    companion {
        var instance: KeyLinkAccessibilityService? = null
            private set

        private val keyMappings = mutableMapOf<Int, Pair<Float, Float>>()
        private val cancelledKeys = mutableSetOf<Int>()

        fun updateKeyMappings(mappings: Map<Int, Pair<Float, Float>>, cancelled: Set<Int>) {
            keyMappings.clear()
            keyMappings.putAll(mappings)
            cancelledKeys.clear()
            cancelledKeys.addAll(cancelled)
        }

        fun dispatchTap(x: Float, y: Float, duration: Long = 50L) {
            val service = instance ?: return
            val path = Path().apply {
                moveTo(x, y)
            }
            val stroke = GestureDescription.StrokeDescription(path, 0, duration)
            val builder = GestureDescription.Builder().addStroke(stroke)
            service.dispatchGesture(builder.build(), null, null)
        }

        fun dispatchHoldStart(x: Float, y: Float) {
            val service = instance ?: return
            val path = Path().apply {
                moveTo(x, y)
            }
            val stroke = GestureDescription.StrokeDescription(path, 0, 10000L)
            val builder = GestureDescription.Builder().addStroke(stroke)
            service.dispatchGesture(builder.build(), null, null)
        }
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // Not required
    }

    override fun onInterrupt() {
        instance = null
    }

    override fun onKeyEvent(event: KeyEvent?): Boolean {
        if (event == null) return super.onKeyEvent(event)
        val keyCode = event.keyCode
        if (cancelledKeys.contains(keyCode)) {
            return true
        }

        val coordinate = keyMappings[keyCode] ?: return super.onKeyEvent(event)
        val x = coordinate.first
        val y = coordinate.second

        when (event.action) {
            KeyEvent.ACTION_DOWN -> {
                if (event.repeatCount == 0) {
                    dispatchHoldStart(x, y)
                }
                return true
            }
            KeyEvent.ACTION_UP -> {
                dispatchTap(x, y, 30L)
                return true
            }
        }
        return super.onKeyEvent(event)
    }

    override fun onDestroy() {
        super.onDestroy()
        instance = null
    }
}
