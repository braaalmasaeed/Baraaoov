package com.baraa.keylink

import android.app.Service
import android.content.Intent
import android.graphics.PixelFormat
import android.os.IBinder
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class OverlayService : Service() {
    private lateinit var windowManager: WindowManager
    private var overlayView: View? = null
    private var isVisible = false

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val action = intent?.getStringExtra("action")
        if (action == "SHOW" || action == "TOGGLE") {
            if (isVisible) hideOverlay() else showOverlay()
        } else if (action == "HIDE") {
            hideOverlay()
        }
        return START_NOT_STICKY
    }

    private fun showOverlay() {
        if (isVisible) return
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager

        val layoutParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        )
        layoutParams.gravity = Gravity.CENTER

        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(0x33000000) // Transparent touch blocker backdrop
            gravity = Gravity.CENTER
        }

        // Draggable floating control menu card
        val menuCard = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(0xEE1E1E1E)
            setPadding(32, 32, 32, 32)
            gravity = Gravity.CENTER
        }

        val title = TextView(this).apply {
            text = "KeyLink Overlay Control"
            setTextColor(0xFFFFFFFF.toInt())
            textSize = 16f
            setPadding(0, 0, 0, 24)
        }
        menuCard.addView(title)

        val btnMouse = Button(this).apply {
            text = "1) Enable Mouse Pointer"
            setOnClickListener { Toast.makeText(context, "Mouse Pointer Enabled", Toast.LENGTH_SHORT).show() }
        }
        menuCard.addView(btnMouse)

        val btnKeyboard = Button(this).apply {
            text = "2) Enable Keyboard"
            setOnClickListener { Toast.makeText(context, "Keyboard Enabled", Toast.LENGTH_SHORT).show() }
        }
        menuCard.addView(btnKeyboard)

        val btnMouseSettings = Button(this).apply {
            text = "3) Mouse Settings"
            setOnClickListener { Toast.makeText(context, "Opening Mouse Settings", Toast.LENGTH_SHORT).show() }
        }
        menuCard.addView(btnMouseSettings)

        val btnKeyboardSettings = Button(this).apply {
            text = "4) Keyboard Settings"
            setOnClickListener { Toast.makeText(context, "Opening Keyboard Settings", Toast.LENGTH_SHORT).show() }
        }
        menuCard.addView(btnKeyboardSettings)

        val btnPresets = Button(this).apply {
            text = "5) Presets"
            setOnClickListener { Toast.makeText(context, "Presets Opened", Toast.LENGTH_SHORT).show() }
        }
        menuCard.addView(btnPresets)

        val btnFinish = Button(this).apply {
            text = "Finish (Hide & Ready)"
            setBackgroundColor(0xFFD32F2F.toInt())
            setTextColor(0xFFFFFFFF.toInt())
            setOnClickListener {
                hideOverlay()
                Toast.makeText(context, "KeyLink Ready in Background", Toast.LENGTH_SHORT).show()
            }
        }
        menuCard.addView(btnFinish)

        container.addView(menuCard)
        overlayView = container

        try {
            windowManager.addView(overlayView, layoutParams)
            isVisible = true
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun hideOverlay() {
        if (!isVisible) return
        overlayView?.let {
            try {
                windowManager.removeView(it)
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
        overlayView = null
        isVisible = false
    }

    override fun onDestroy() {
        super.onDestroy()
        hideOverlay()
    }
}
