import 'package:flutter/material.dart';
import '../models/keylink_models.dart';
import '../l10n/app_strings.dart';

class KeyboardSettingsScreen extends StatefulWidget {
  final String language;
  const KeyboardSettingsScreen({Key? key, required this.language}) : super(key: key);

  @override
  State<KeyboardSettingsScreen> createState() => _KeyboardSettingsScreenState();
}

class _KeyboardSettingsScreenState extends State<KeyboardSettingsScreen> {
  bool _isEdited = false;
  KeyMapping? _selectedKey;
  
  List<KeyMapping> _keys = [
    KeyMapping(id: 'W', label: 'W', x: 100, y: 200),
    KeyMapping(id: 'A', label: 'A', x: 50, y: 280),
    KeyMapping(id: 'S', label: 'S', x: 120, y: 280),
    KeyMapping(id: 'D', label: 'D', x: 190, y: 280),
    KeyMapping(id: 'Space', label: 'SPC', x: 300, y: 350),
    KeyMapping(id: 'Fire', label: '🔥', x: 600, y: 250),
  ];

  List<KeyMapping> get _activeKeys => _keys.where((k) => !k.isDeleted).toList();
  List<KeyMapping> get _deletedKeys => _keys.where((k) => k.isDeleted).toList();

  @override
  Widget build(BuildContext context) {
    final isAr = widget.language == 'ar';
    return Directionality(
      textDirection: isAr ? TextDirection.rtl : TextDirection.ltr,
      child: Scaffold(
        appBar: AppBar(
          title: Text(AppStrings.get('keyboard_settings', widget.language)),
          actions: [
            if (_isEdited) ...[
              TextButton.icon(
                style: TextButton.styleFrom(foregroundColor: Colors.white),
                icon: const Icon(Icons.save),
                label: Text(AppStrings.get('save', widget.language)),
                onPressed: () {
                  setState(() => _isEdited = false);
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(content: Text(isAr ? 'تم حفظ التخطيط بنجاح' : 'Layout saved successfully')),
                  );
                },
              ),
              TextButton.icon(
                style: TextButton.styleFrom(foregroundColor: Colors.redAccent),
                icon: const Icon(Icons.refresh),
                label: Text(AppStrings.get('reset_layout', widget.language)),
                onPressed: () {
                  setState(() {
                    _isEdited = false;
                    _selectedKey = null;
                  });
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(content: Text(AppStrings.get('reset_layout_confirm', widget.language))),
                  );
                },
              ),
            ],
            IconButton(
              icon: const Icon(Icons.delete_sweep),
              tooltip: AppStrings.get('deleted_keys', widget.language),
              onPressed: _showDeletedKeysModal,
            ),
          ],
        ),
        body: Stack(
          children: [
            // Interactive workspace for circular translucent keys
            Positioned.fill(
              child: GestureDetector(
                onTap: () => setState(() => _selectedKey = null),
                child: Container(
                  color: Colors.black12,
                  child: Stack(
                    children: _activeKeys.map((keyMap) {
                      final isSelected = _selectedKey?.id == keyMap.id;
                      return Positioned(
                        left: keyMap.x,
                        top: keyMap.y,
                        child: GestureDetector(
                          onPanUpdate: (details) {
                            setState(() {
                              keyMap.x += details.delta.dx;
                              keyMap.y += details.delta.dy;
                              _isEdited = true;
                            });
                          },
                          onTap: () {
                            setState(() {
                              _selectedKey = keyMap;
                            });
                          },
                          child: Opacity(
                            opacity: keyMap.useCustomOpacity ? keyMap.opacityValue : 0.75,
                            child: Container(
                              width: keyMap.size,
                              height: keyMap.size,
                              decoration: BoxDecoration(
                                shape: BoxShape.circle,
                                color: isSelected ? Colors.blue.withOpacity(0.8) : Colors.grey.withOpacity(0.6),
                                border: Border.all(
                                  color: keyMap.isCancelled ? Colors.red : Colors.white,
                                  width: keyMap.isCancelled ? 3.0 : 1.5,
                                ),
                              ),
                              alignment: Alignment.center,
                              child: Stack(
                                alignment: Alignment.center,
                                children: [
                                  Text(
                                    keyMap.label,
                                    style: TextStyle(
                                      color: Colors.white,
                                      fontWeight: FontWeight.bold,
                                      fontSize: keyMap.size * 0.35,
                                    ),
                                  ),
                                  if (keyMap.isCancelled)
                                    const Icon(Icons.close, color: Colors.red, size: 36),
                                ],
                              ),
                            ),
                          ),
                        ),
                      );
                    }).toList(),
                  ),
                ),
              ),
            ),

            // Key Editor Floating Bottom Sheet when a key is selected
            if (_selectedKey != null)
              Positioned(
                bottom: 0,
                left: 0,
                right: 0,
                child: Container(
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    boxShadow: [BoxShadow(color: Colors.black26, blurRadius: 10)],
                    borderRadius: const BorderRadius.vertical(top: Radius.circular(16)),
                  ),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text(
                            'Key: ${_selectedKey!.label}',
                            style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                          ),
                          IconButton(
                            icon: const Icon(Icons.close),
                            onPressed: () => setState(() => _selectedKey = null),
                          ),
                        ],
                      ),
                      const Divider(),
                      // Size Slider
                      Row(
                        children: [
                          Text(AppStrings.get('resize_key', widget.language)),
                          Expanded(
                            child: Slider(
                              value: _selectedKey!.size,
                              min: 35.0,
                              max: 100.0,
                              onChanged: (val) {
                                setState(() {
                                  _selectedKey!.size = val;
                                  _isEdited = true;
                                });
                              },
                            ),
                          ),
                        ],
                      ),
                      // Toggles row: Cancel Key, Long Press, Custom Opacity
                      Wrap(
                        spacing: 12.0,
                        runSpacing: 4.0,
                        children: [
                          FilterChip(
                            label: Text(AppStrings.get('cancel_key', widget.language)),
                            selected: _selectedKey!.isCancelled,
                            selectedColor: Colors.red.shade200,
                            onSelected: (val) {
                              setState(() {
                                _selectedKey!.isCancelled = val;
                                _isEdited = true;
                              });
                            },
                          ),
                          FilterChip(
                            label: Text(AppStrings.get('long_press_hold', widget.language)),
                            selected: _selectedKey!.isLongPress,
                            selectedColor: Colors.blue.shade200,
                            onSelected: (val) {
                              setState(() {
                                _selectedKey!.isLongPress = val;
                                _isEdited = true;
                              });
                            },
                          ),
                          FilterChip(
                            label: Text(AppStrings.get('custom_opacity', widget.language)),
                            selected: _selectedKey!.useCustomOpacity,
                            selectedColor: Colors.teal.shade200,
                            onSelected: (val) {
                              setState(() {
                                _selectedKey!.useCustomOpacity = val;
                                _isEdited = true;
                              });
                            },
                          ),
                        ],
                      ),
                      if (_selectedKey!.useCustomOpacity) ...[
                        const SizedBox(height: 8),
                        Row(
                          children: [
                            const Text('Opacity:'),
                            Expanded(
                              child: Slider(
                                value: _selectedKey!.opacityValue,
                                min: 0.1,
                                max: 1.0,
                                onChanged: (val) {
                                  setState(() {
                                    _selectedKey!.opacityValue = val;
                                    _isEdited = true;
                                  });
                                },
                              ),
                            ),
                          ],
                        ),
                      ],
                      const SizedBox(height: 8),
                      SizedBox(
                        width: double.infinity,
                        child: OutlinedButton.icon(
                          style: OutlinedButton.styleFrom(foregroundColor: Colors.red),
                          icon: const Icon(Icons.delete),
                          label: Text(AppStrings.get('delete_key', widget.language)),
                          onPressed: () {
                            setState(() {
                              _selectedKey!.isDeleted = true;
                              _selectedKey = null;
                              _isEdited = true;
                            });
                          },
                        ),
                      ),
                    ],
                  ),
                ),
              ),
          ],
        ),
        floatingActionButton: FloatingActionButton(
          child: const Icon(Icons.add),
          tooltip: AppStrings.get('add_key', widget.language),
          onPressed: () {
            setState(() {
              _keys.add(KeyMapping(
                id: 'Key_${_keys.length + 1}',
                label: '${_keys.length + 1}',
                x: 150,
                y: 150,
              ));
              _isEdited = true;
            });
          },
        ),
      ),
    );
  }

  void _showDeletedKeysModal() {
    final isAr = widget.language == 'ar';
    showModalBottomSheet(
      context: context,
      builder: (context) {
        return Container(
          padding: const EdgeInsets.all(16),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                AppStrings.get('deleted_keys', widget.language),
                style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
              ),
              const Divider(),
              if (_deletedKeys.isEmpty)
                Padding(
                  padding: const EdgeInsets.symmetric(vertical: 24.0),
                  child: Center(
                    child: Text(isAr ? 'لا توجد مفاتيح محذوفة' : 'No deleted keys'),
                  ),
                )
              else
                Expanded(
                  child: ListView(
                    shrinkWrap: true,
                    children: _deletedKeys.map((k) => ListTile(
                          title: Text('Key: ${k.label} (${k.id})'),
                          trailing: ElevatedButton(
                            child: Text(AppStrings.get('restore', widget.language)),
                            onPressed: () {
                              setState(() {
                                k.isDeleted = false;
                                _isEdited = true;
                              });
                              Navigator.pop(context);
                            },
                          ),
                        )).toList(),
                  ),
                ),
            ],
          ),
        );
      },
    );
  }
}
