import os
import zipfile

def create_zip():
    zip_filename = "KeyLink_full.zip"
    exclude_dirs = {'.git', '.rooignore', 'build', '.dart_tool', '.gradle', 'KeyLink_full'}
    exclude_extensions = {'.zip'}

    # Target sync paths
    sync_paths = [
        "./KeyLink_full.zip",
        "/storage/emulated/0/Download/KeyLink_full.zip",
        "/storage/emulated/0/Baraa projects/KeyLink_full.zip"
    ]

    # Create temporary zip in current dir first
    print(f"Creating {zip_filename}...")
    with zipfile.ZipFile(zip_filename, 'w', zipfile.ZIP_DEFLATED) as zipf:
        for root, dirs, files in os.walk('.'):
            # Modify dirs in-place to prune excluded directories
            dirs[:] = [d for d in dirs if d not in exclude_dirs and not d.startswith('.')]
            
            for file in files:
                if any(file.endswith(ext) for ext in exclude_extensions):
                    continue
                if file == zip_filename:
                    continue
                
                file_path = os.path.join(root, file)
                archive_name = os.path.relpath(file_path, '.')
                
                # Double check path parts for exclusion
                parts = archive_name.split(os.sep)
                if any(p in exclude_dirs or p.startswith('.') for p in parts):
                    continue
                
                print(f"Adding: {archive_name}")
                zipf.write(file_path, archive_name)

    print(f"Successfully created {zip_filename}")

    # Sync to other paths if parent directory exists
    for sp in sync_paths[1:]:
        try:
            parent_dir = os.path.dirname(sp)
            if os.path.exists(parent_dir) or True: # Try creating directory if possible
                os.makedirs(parent_dir, exist_ok=True)
                import shutil
                shutil.copy(zip_filename, sp)
                print(f"Synced to: {sp}")
        except Exception as e:
            print(f"Could not sync to {sp}: {e}")

if __name__ == '__main__':
    create_zip()
