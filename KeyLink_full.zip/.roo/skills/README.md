# KeyLink Agent Skills & Superpowers (.roo/skills/)

This directory defines modular agent skills for the `KeyLink` (`KeyLink`) project:
1. `state-and-i18n`: Instant bilingual AR/EN and reactive state management (`ValueNotifier`).
2. `error-handling`: Global error handling (`FlutterError.onError`, `runZonedGuarded`).
3. `lint-and-types`: Dart lint and type safety (`const`, strict types).
4. `responsive-ui`: Adaptive UI using `MediaQuery` and `LayoutBuilder`.
5. `permissions-and-overlay`: Native Android accessibility, overlays, and tile services.
6. `visual-and-superpowers`: Clean visual styling, custom painters, and free app guarantees.
