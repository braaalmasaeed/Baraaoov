import 'package:flutter/material.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import '../data/muezzins_data.dart';
import '../services/storage_service.dart';
import '../services/prayer_calculator.dart';
import '../services/app_state_controller.dart';

class SettingsScreen extends StatefulWidget {
  final VoidCallback? onThemeChanged;
  const SettingsScreen({Key? key, this.onThemeChanged}) : super(key: key);

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  // 10 curated background images (Mosques, Grand Mosques, Kaaba)
  final List<Map<String, String>> _bgImages = [
    {'title': 'الكعبة المشرفة (الليل)', 'url': 'https://images.unsplash.com/photo-1565552403568-9bac251571d7?q=80&w=800'},
    {'title': 'المسجد الحرام', 'url': 'https://images.unsplash.com/photo-1591604129939-f1efa4d9f7fa?q=80&w=800'},
    {'title': 'المسجد النبوي الشريف', 'url': 'https://images.unsplash.com/photo-1580418827493-f5a7f8c92fba?q=80&w=800'},
    {'title': 'مسجد قبا', 'url': 'https://images.unsplash.com/photo-1542838132-92c53300491e?q=80&w=800'},
    {'title': 'إضاءة الكعبة', 'url': 'https://images.unsplash.com/photo-1584551246679-0daf3d275d0f?q=80&w=800'},
    {'title': 'منارة المسجد', 'url': 'https://images.unsplash.com/photo-1590073844006-33379778ae09?q=80&w=800'},
    {'title': 'ساحة الحرم المكي', 'url': 'https://images.unsplash.com/photo-1564507592333-c60657eea523?q=80&w=800'},
    {'title': 'غروب مكة', 'url': 'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?q=80&w=800'},
    {'title': 'عمارة إسلامية أندلسية', 'url': 'https://images.unsplash.com/photo-1512632578888-169bbbc64f33?q=80&w=800'},
    {'title': 'قبة الصخرة المشرفة', 'url': 'https://images.unsplash.com/photo-1544620347-c4fd4a3d5957?q=80&w=800'},
  ];

  String? _previewingMuezzinId;
  bool _isAdhanPreviewPlaying = false;

  // 1. Global Location Picker with Search, Confirmation, and 30-Day Monthly Offline Cache
  void _openLocationPicker() {
    final TextEditingController searchController = TextEditingController();
    String searchKeyword = '';
    
    final List<String> globalLocations = [
      'مكة المكرمة، السعودية',
      'المدينة المنورة، السعودية',
      'الرياض، السعودية',
      'جدة، السعودية',
      'الدمام، السعودية',
      'عمان، الأردن',
      'القدس، فلسطين',
      'القاهرة، مصر',
      'دبي، الإمارات',
      'الدوحة، قطر',
      'إسطنبول، تركيا',
      'لندن، بريطانيا',
      'باريس، فرنسا',
      'نيويورك، الولايات المتحدة',
      'كوالالمبور، ماليزيا',
      'جاكرتا، إندونيسيا',
      'إسلام آباد، باكستان',
      'تونس، تونس',
      'الرباط، المغرب',
      'الجزائر، الجزائر',
    ];

    showDialog(
      context: context,
      builder: (context) {
        return StatefulBuilder(
          builder: (context, setDialogState) {
            final filteredLocations = globalLocations
                .where((loc) => loc.toLowerCase().contains(searchKeyword.toLowerCase()))
                .toList();

            return AlertDialog(
              title: const Text('اختر موقعك الجغرافي العالمي', style: TextStyle(fontFamily: 'Amiri', fontWeight: FontWeight.bold)),
              content: SizedBox(
                width: double.maxFinite,
                height: 400,
                child: Column(
                  children: [
                    TextField(
                      controller: searchController,
                      decoration: const InputDecoration(
                        labelText: 'ابحث عن أي مدينة في العالم...',
                        prefixIcon: Icon(Icons.search),
                        border: OutlineInputBorder(),
                      ),
                      onChanged: (val) {
                        setDialogState(() {
                          searchKeyword = val;
                        });
                      },
                    ),
                    const SizedBox(height: 12),
                    Expanded(
                      child: ListView.builder(
                        itemCount: filteredLocations.length,
                        itemBuilder: (context, index) {
                          final city = filteredLocations[index];
                          final isSelected = city == AppStateController.instance.userLocation;
                          return ListTile(
                            title: Text(city),
                            trailing: isSelected ? const Icon(Icons.check_circle, color: Colors.green) : null,
                            onTap: () async {
                              // Calculate & cache prayer times for 1 month (30 days)
                              final now = DateTime.now();
                              final times = PrayerCalculator.calculate(
                                date: now,
                                latitude: 21.3891,
                                longitude: 39.8579,
                              );

                              Map<String, String> prayerMap = {
                                'الفجر': times.fajr.toIso8601String(),
                                'الشروق': times.sunrise.toIso8601String(),
                                'الظهر': times.dhuhr.toIso8601String(),
                                'العصر': times.asr.toIso8601String(),
                                'المغرب': times.maghrib.toIso8601String(),
                                'العشاء': times.isha.toIso8601String(),
                              };

                              await StorageService.saveMonthlyCache(locationName: city, prayerTimes: prayerMap);
                              await AppStateController.instance.setUserLocation(city);

                              if (mounted) {
                                Navigator.pop(context);
                                ScaffoldMessenger.of(context).showSnackBar(
                                  SnackBar(content: Text('تم تأكيد الموقع "$city" وتخزين مواقيت الصلاة محلياً لمدة 30 يوماً')),
                                );
                              }
                            },
                          );
                        },
                      ),
                    ),
                  ],
                ),
              ),
              actions: [
                TextButton(
                  onPressed: () => Navigator.pop(context),
                  child: const Text('إلغاء'),
                ),
              ],
            );
          },
        );
      },
    );
  }

  // Adhan Preview Screen Modal
  void _openAdhanPreviewModal() async {
    setState(() {
      _isAdhanPreviewPlaying = true;
    });

    int bgIndex = AppStateController.instance.selectedBgIndex;
    if (AppStateController.instance.adhanBgMode == 'sequential') {
      bgIndex = await StorageService.getNextSequentialBgIndex();
    }
    final currentBg = _bgImages[bgIndex]['url']!;
    final bgTitle = _bgImages[bgIndex]['title']!;

    if (!mounted) return;

    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) {
        return Dialog(
          backgroundColor: Colors.black,
          insetPadding: EdgeInsets.zero,
          child: Stack(
            fit: StackFit.expand,
            children: [
              Image.network(
                currentBg,
                fit: BoxFit.cover,
                errorBuilder: (context, error, stackTrace) => Container(color: Colors.blueGrey),
              ),
              Container(color: Colors.black.withOpacity(0.4)),
              SafeArea(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Padding(
                      padding: const EdgeInsets.all(16.0),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Container(
                            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                            decoration: BoxDecoration(
                              color: Colors.black54,
                              borderRadius: BorderRadius.circular(20),
                            ),
                            child: Text(
                              bgTitle,
                              style: const TextStyle(color: Colors.white, fontSize: 14, fontWeight: FontWeight.bold),
                            ),
                          ),
                          IconButton(
                            onPressed: () {
                              setState(() {
                                _isAdhanPreviewPlaying = false;
                              });
                              Navigator.pop(context);
                            },
                            icon: const Icon(Icons.close, color: Colors.white, size: 30),
                            style: IconButton.styleFrom(
                              backgroundColor: Colors.black54,
                            ),
                          ),
                        ],
                      ),
                    ),
                    Column(
                      children: [
                        const Icon(Icons.volume_up, color: Colors.amber, size: 60),
                        const SizedBox(height: 12),
                        const Text(
                          'معاينة الأذان جارية...',
                          style: TextStyle(color: Colors.white, fontSize: 22, fontWeight: FontWeight.bold, fontFamily: 'Amiri'),
                        ),
                        const SizedBox(height: 6),
                        Text(
                          'المؤذن: ${_getSelectedMuezzinName()}',
                          style: const TextStyle(color: Colors.amberAccent, fontSize: 16),
                        ),
                      ],
                    ),
                    const Padding(
                      padding: EdgeInsets.all(24.0),
                      child: Text(
                        'اضغط على زر (X) لإيقاف وإغلاق المعاينة',
                        style: TextStyle(color: Colors.white70, fontSize: 12),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  String _getSelectedMuezzinName() {
    final m = MuezzinsData.muezzins.firstWhere(
      (element) => element.id == AppStateController.instance.selectedMuezzin,
      orElse: () => MuezzinsData.muezzins.first,
    );
    return m.name;
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: AppStateController.instance,
      builder: (context, _) {
        final state = AppStateController.instance;

        return Scaffold(
          appBar: AppBar(
            title: const Text('الإعدادات', style: TextStyle(fontFamily: 'Amiri', fontWeight: FontWeight.bold)),
            centerTitle: true,
          ),
          body: ListView(
            padding: const EdgeInsets.all(16),
            children: [
              // 1. بطاقة الموقع الجغرافي العالمي مع البحث والذاكرة المؤقتة للشهر
              _buildCard(
                title: 'الموقع الجغرافي (بحث وعالمي)',
                icon: Icons.location_on,
                children: [
                  ListTile(
                    title: Text(state.userLocation, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
                    subtitle: const Text('انقر للبحث عن أي موقع في العالم وتأكيد التخزين المحلي (30 يوماً)'),
                    trailing: const Icon(Icons.arrow_forward_ios, size: 16),
                    onTap: _openLocationPicker,
                  ),
                ],
              ),
              const SizedBox(height: 16),

              // 2. بطاقة المؤذن الصوتي (معاينة مثلث + علامة صح خضراء)
              _buildCard(
                title: 'المؤذن الصوتي ومعاينة الأذان',
                icon: Icons.volume_up,
                children: [
                  ...MuezzinsData.muezzins.map((m) {
                    final isSelected = m.id == state.selectedMuezzin;
                    final isPreviewing = _previewingMuezzinId == m.id && _isAdhanPreviewPlaying;

                    return Container(
                      margin: const EdgeInsets.symmetric(vertical: 4),
                      decoration: BoxDecoration(
                        color: isSelected ? Colors.green.withOpacity(0.1) : Colors.transparent,
                        borderRadius: BorderRadius.circular(10),
                        border: Border.all(color: isSelected ? Colors.green : Colors.transparent),
                      ),
                      child: ListTile(
                        leading: IconButton(
                          icon: Icon(
                            isPreviewing ? Icons.pause_circle_filled : Icons.play_arrow,
                            color: Colors.amber.shade700,
                            size: 30,
                          ),
                          onPressed: () {
                            setState(() {
                              _previewingMuezzinId = m.id;
                            });
                            _openAdhanPreviewModal();
                          },
                          tooltip: 'معاينة صوت المؤذن',
                        ),
                        title: Text(m.name, style: TextStyle(fontWeight: isSelected ? FontWeight.bold : FontWeight.normal)),
                        subtitle: Text(m.location),
                        trailing: InkWell(
                          onTap: () async {
                            await state.setSelectedMuezzin(m.id);
                            if (mounted) {
                              ScaffoldMessenger.of(context).showSnackBar(
                                SnackBar(content: Text('تم اختيار "${m.name}" مؤذناً نشطاً')),
                              );
                            }
                          },
                          borderRadius: BorderRadius.circular(6),
                          child: Container(
                            width: 28,
                            height: 28,
                            decoration: BoxDecoration(
                              color: isSelected ? Colors.green : Colors.transparent,
                              border: Border.all(
                                color: isSelected ? Colors.green : Colors.grey,
                                width: 2,
                              ),
                              borderRadius: BorderRadius.circular(6),
                            ),
                            child: isSelected
                                ? const Icon(Icons.check, color: Colors.white, size: 18)
                                : null,
                          ),
                        ),
                      ),
                    );
                  }).toList(),
                ],
              ),
              const SizedBox(height: 16),

              // 3. معاينة الأذان وخلفيات العرض (10 صور جوامع وكعبة) وتدوير تسلسلي / يدوي
              _buildCard(
                title: 'معاينة الأذان وخلفيات الصور (10 صور)',
                icon: Icons.image,
                children: [
                  ElevatedButton.icon(
                    onPressed: _openAdhanPreviewModal,
                    icon: const Icon(Icons.play_circle_fill),
                    label: const Text('معاينة الأذان (Adhan Preview)'),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.amber.shade800,
                      foregroundColor: Colors.white,
                      minimumSize: const Size(double.infinity, 45),
                    ),
                  ),
                  const SizedBox(height: 12),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      const Text('وضع خلفيات الأذان:'),
                      DropdownButton<String>(
                        value: state.adhanBgMode,
                        items: const [
                          DropdownMenuItem(value: 'sequential', child: Text('تدوير تسلسلي (كل أذان صورة)')),
                          DropdownMenuItem(value: 'manual', child: Text('صورة محددة ثابتة')),
                        ],
                        onChanged: (val) async {
                          if (val != null) {
                            await state.setAdhanBgMode(val);
                          }
                        },
                      ),
                    ],
                  ),
                  if (state.adhanBgMode == 'manual') ...[
                    const SizedBox(height: 8),
                    const Text('اختر الصورة المحددة:', style: TextStyle(fontSize: 13, color: Colors.grey)),
                    const SizedBox(height: 6),
                    SizedBox(
                      height: 80,
                      child: ListView.builder(
                        scrollDirection: Axis.horizontal,
                        itemCount: _bgImages.length,
                        itemBuilder: (context, index) {
                          final isChosen = state.selectedBgIndex == index;
                          return GestureDetector(
                            onTap: () async {
                              await state.setSelectedBgIndex(index);
                            },
                            child: Container(
                              width: 80,
                              margin: const EdgeInsets.symmetric(horizontal: 4),
                              decoration: BoxDecoration(
                                border: Border.all(color: isChosen ? Colors.green : Colors.transparent, width: 3),
                                borderRadius: BorderRadius.circular(8),
                                image: DecorationImage(
                                  image: NetworkImage(_bgImages[index]['url']!),
                                  fit: BoxFit.cover,
                                ),
                              ),
                              child: isChosen
                                  ? const Align(
                                      alignment: Alignment.topRight,
                                      child: Icon(Icons.check_circle, color: Colors.green, size: 20),
                                    )
                                  : null,
                            ),
                          );
                        },
                      ),
                    ),
                  ],
                ],
              ),
              const SizedBox(height: 16),

              // 4. نظام الوقت والتاريخ (24 ساعة / 12 ساعة) ومزامنة فورية مع الشاشة الرئيسية
              _buildCard(
                title: 'نظام الوقت والتاريخ',
                icon: Icons.access_time,
                children: [
                  SwitchListTile(
                    title: const Text('نظام 24 ساعة (24-hour)'),
                    subtitle: const Text('تزامن فوري وتحديث عرض الساعة في الشاشة الرئيسية'),
                    value: state.is24Hour,
                    onChanged: (val) async {
                      await state.set24Hour(val);
                    },
                  ),
                ],
              ),
              const SizedBox(height: 16),

              // 5. المظهر (الوضع الليلي)
              _buildCard(
                title: 'المظهر',
                icon: Icons.brightness_6,
                children: [
                  SwitchListTile(
                    title: const Text('تفعيل الوضع الليلي (Dark Mode)'),
                    value: state.isDarkMode,
                    onChanged: (val) async {
                      await state.toggleDarkMode(val);
                      if (widget.onThemeChanged != null) {
                        widget.onThemeChanged!();
                      }
                    },
                  ),
                ],
              ),
              const SizedBox(height: 16),

              // 6. صلاحيات النظام (الإشعارات والظهور فوق التطبيقات مع الانتقال المباشر للإعدادات)
              _buildCard(
                title: 'صلاحيات النظام',
                icon: Icons.security,
                children: [
                  ListTile(
                    leading: const Icon(Icons.notifications_active, color: Colors.blue),
                    title: const Text('السماح بإرسال الإشعارات'),
                    subtitle: const Text('مهمة للأذان والتنبيهات'),
                    trailing: ElevatedButton(
                      onPressed: () async {
                        try {
                          final plugin = FlutterLocalNotificationsPlugin();
                          final androidPlugin = plugin.resolvePlatformSpecificImplementation<AndroidFlutterLocalNotificationsPlugin>();
                          if (androidPlugin != null) {
                            final bool? granted = await androidPlugin.requestNotificationsPermission();
                            if (mounted) {
                              ScaffoldMessenger.of(context).showSnackBar(
                                SnackBar(content: Text(granted == true ? 'تم منح إذن الإشعارات بنجاح' : 'تم رفض أو تعليق إذن الإشعارات')),
                              );
                            }
                          } else {
                            if (mounted) {
                              ScaffoldMessenger.of(context).showSnackBar(
                                const SnackBar(content: Text('إذن الإشعارات مفعل أو غير مطلوب لهذه المنصة')),
                              );
                            }
                          }
                        } catch (_) {
                          if (mounted) {
                            ScaffoldMessenger.of(context).showSnackBar(
                              const SnackBar(content: Text('تعذر فتح إعدادات الإشعارات مباشرة، يرجى فتحها من إعدادات النظام')),
                            );
                          }
                        }
                      },
                      child: const Text('تفعيل'),
                    ),
                  ),
                  const Divider(),
                  ListTile(
                    leading: const Icon(Icons.layers, color: Colors.orange),
                    title: const Text('السماح بالظهور فوق التطبيقات'),
                    subtitle: const Text('مهم لظهور الأذان فوق التطبيقات وإلا لن يظهر'),
                    trailing: ElevatedButton(
                      onPressed: () {
                        showDialog(
                          context: context,
                          builder: (ctx) => AlertDialog(
                            title: const Text('الظهور فوق التطبيقات'),
                            content: const Text(
                              'لضمان ظهور شاشة الأذان فوق التطبيقات عند حان وقت الصلاة، يرجى السماح للتطبيق بالظهور فوق التطبيقات الأخرى من إعدادات النظام.',
                              style: TextStyle(height: 1.4),
                            ),
                            actions: [
                              TextButton(
                                onPressed: () => Navigator.pop(ctx),
                                child: const Text('حسناً'),
                              ),
                            ],
                          ),
                        );
                      },
                      child: const Text('تفعيل'),
                    ),
                  ),
                ],
              ),
            ],
          ),
        );
      },
    );
  }

  Widget _buildCard({required String title, required IconData icon, required List<Widget> children}) {
    return Card(
      elevation: 3,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Icon(icon, color: Colors.green.shade700),
                const SizedBox(width: 10),
                Text(
                  title,
                  style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold, fontFamily: 'Amiri'),
                ),
              ],
            ),
            const Divider(height: 20),
            ...children,
          ],
        ),
      ),
    );
  }
}
