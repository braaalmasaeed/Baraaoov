import 'package:flutter/material.dart';
import '../data/azkar_data.dart';

class AzkarDetailScreen extends StatefulWidget {
  final DhikrCategory initialCategory;

  const AzkarDetailScreen({Key? key, required this.initialCategory}) : super(key: key);

  @override
  State<AzkarDetailScreen> createState() => _AzkarDetailScreenState();
}

class _AzkarDetailScreenState extends State<AzkarDetailScreen> {
  late DhikrCategory _currentCategory;
  late List<int> _currentCounts;
  double _fontSize = 18.0;

  @override
  void initState() {
    super.initState();
    _currentCategory = widget.initialCategory;
    _initCounts();
  }

  void _initCounts() {
    _currentCounts = List.filled(_currentCategory.items.length, 0);
  }

  void _switchCategory(DhikrCategory newCategory) {
    setState(() {
      _currentCategory = newCategory;
      _initCounts();
    });
  }

  void _incrementCount(int index) {
    setState(() {
      if (_currentCounts[index] < _currentCategory.items[index].targetCount) {
        _currentCounts[index]++;
      }
    });
  }

  void _resetCount(int index) {
    setState(() {
      _currentCounts[index] = 0;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          _currentCategory.title,
          style: const TextStyle(fontFamily: 'Amiri', fontWeight: FontWeight.bold),
        ),
        centerTitle: true,
        actions: [
          PopupMenuButton<String>(
            icon: const Icon(Icons.text_format),
            onSelected: (value) {
              setState(() {
                if (value == 'increase' && _fontSize < 28.0) {
                  _fontSize += 2.0;
                } else if (value == 'decrease' && _fontSize > 12.0) {
                  _fontSize -= 2.0;
                }
              });
            },
            itemBuilder: (context) => [
              const PopupMenuItem(
                value: 'increase',
                child: Row(
                  children: [
                    Icon(Icons.zoom_in, color: Colors.black54),
                    SizedBox(width: 8),
                    Text('تكبير الخط'),
                  ],
                ),
              ),
              const PopupMenuItem(
                value: 'decrease',
                child: Row(
                  children: [
                    Icon(Icons.zoom_out, color: Colors.black54),
                    SizedBox(width: 8),
                    Text('تصغير الخط'),
                  ],
                ),
              ),
            ],
          ),
        ],
      ),
      body: Column(
        children: [
          // شريط التبديل السريع بين الأذكار الخمسة (Quick-Switch Bar)
          Container(
            height: 60,
            color: Colors.green.shade50,
            child: ListView.builder(
              scrollDirection: Axis.horizontal,
              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 8),
              itemCount: AzkarData.categories.length,
              itemBuilder: (context, index) {
                final cat = AzkarData.categories[index];
                final isSelected = cat.key == _currentCategory.key;
                return Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 4),
                  child: ChoiceChip(
                    label: Text(
                      cat.title,
                      style: TextStyle(
                        fontFamily: 'Amiri',
                        fontWeight: FontWeight.bold,
                        color: isSelected ? Colors.white : Colors.green.shade800,
                      ),
                    ),
                    selected: isSelected,
                    selectedColor: Colors.green.shade700,
                    backgroundColor: Colors.white,
                    onSelected: (selected) {
                      if (selected) {
                        _switchCategory(cat);
                      }
                    },
                  ),
                );
              },
            ),
          ),
          // قائمة الأذكار مع التمرير السلس (Vertical Swipe/Scroll)
          Expanded(
            child: ListView.builder(
              padding: const EdgeInsets.all(16),
              itemCount: _currentCategory.items.length,
              itemBuilder: (context, index) {
                final item = _currentCategory.items[index];
                final count = _currentCounts[index];
                final isCompleted = count >= item.targetCount;

                return Card(
                  elevation: 3,
                  margin: const EdgeInsets.only(bottom: 16),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(15),
                    side: BorderSide(
                      color: isCompleted ? Colors.green.shade300 : Colors.transparent,
                      width: 1.5,
                    ),
                  ),
                  child: Padding(
                    padding: const EdgeInsets.all(16),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      children: [
                        // رقم الذكر والعنوان الفرعي
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            CircleAvatar(
                              radius: 14,
                              backgroundColor: Colors.green.shade100,
                              child: Text(
                                '${index + 1}',
                                style: TextStyle(
                                  color: Colors.green.shade800,
                                  fontWeight: FontWeight.bold,
                                  fontSize: 12,
                                ),
                              ),
                            ),
                            Text(
                              'العدد المطلوب: ${item.targetCount}',
                              style: TextStyle(
                                color: Colors.grey.shade700,
                                fontFamily: 'Amiri',
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(height: 12),
                        // نص الذكر التفاعلي (النقر يزيد العداد)
                        GestureDetector(
                          onTap: () => _incrementCount(index),
                          child: Container(
                            padding: const EdgeInsets.all(12),
                            decoration: BoxDecoration(
                              color: isCompleted ? Colors.green.shade50 : Colors.grey.shade50,
                              borderRadius: BorderRadius.circular(10),
                            ),
                            child: Text(
                              item.text,
                              style: TextStyle(
                                fontSize: _fontSize,
                                fontFamily: 'Amiri',
                                height: 1.6,
                                color: Colors.black87,
                              ),
                              textAlign: TextAlign.right,
                            ),
                          ),
                        ),
                        const SizedBox(height: 12),
                        // المصدر والفضل
                        Text(
                          'المصدر: ${item.source}',
                          style: TextStyle(
                            fontSize: 13,
                            color: Colors.green.shade800,
                            fontFamily: 'Amiri',
                            fontWeight: FontWeight.bold,
                          ),
                          textAlign: TextAlign.right,
                        ),
                        const SizedBox(height: 4),
                        Text(
                          'الفضل: ${item.virtue}',
                          style: TextStyle(
                            fontSize: 13,
                            color: Colors.brown.shade700,
                            fontFamily: 'Amiri',
                          ),
                          textAlign: TextAlign.right,
                        ),
                        const SizedBox(height: 16),
                        const Divider(),
                        // العداد التفاعلي وزر التصفير
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            // خانة للتصفير
                            IconButton(
                              onPressed: () => _resetCount(index),
                              icon: const Icon(Icons.refresh, color: Colors.redAccent),
                              tooltip: 'تصفير العداد',
                            ),
                            // زر العداد التفاعلي
                            ElevatedButton.icon(
                              onPressed: () => _incrementCount(index),
                              style: ElevatedButton.styleFrom(
                                backgroundColor: isCompleted ? Colors.green : Colors.green.shade700,
                                foregroundColor: Colors.white,
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(20),
                                ),
                                padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 8),
                              ),
                              icon: Icon(isCompleted ? Icons.check_circle : Icons.touch_app),
                              label: Text(
                                '$count / ${item.targetCount}',
                                style: const TextStyle(
                                  fontSize: 16,
                                  fontWeight: FontWeight.bold,
                                  fontFamily: 'Amiri',
                                ),
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}
