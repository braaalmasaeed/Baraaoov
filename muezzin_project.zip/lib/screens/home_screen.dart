import 'dart:async';
import 'package:flutter/material.dart';
import '../data/muezzins_data.dart';
import '../services/prayer_calculator.dart';
import '../services/storage_service.dart';
import '../services/background_prayer_service.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  // احداثيات افتراضية (مكة المكرمة) للعمل بدون إنترنت
  final double _latitude = 21.3891;
  final double _longitude = 39.8579;
  
  PrayerTimesResult? _prayerTimes;
  Map<String, AlertType> _alertSettings = {};
  String _locationName = 'مكة المكرمة';
  String _selectedMuezzinName = 'الشيخ علي ملا';
  
  Timer? _timer;
  Duration _timeRemaining = Duration.zero;
  String _nextPrayerName = '';
  
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    _loadData();
    // بدء خدمة الخلفية للمراقبة والتشغيل
    BackgroundPrayerService.startService(context);
    // تحديث العد التنازلي كل ثانية
    _timer = Timer.periodic(const Duration(seconds: 1), (_) => _updateCountdown());
  }

  @override
  void dispose() {
    _timer?.cancel();
    BackgroundPrayerService.stopService();
    super.dispose();
  }

  Future<void> _loadData() async {
    try {
      final loc = await StorageService.getUserLocation();
      final alerts = await StorageService.getAlertSettings();
      final muezzinId = await StorageService.getSelectedMuezzin();
      
      final muezzin = MuezzinsData.muezzins.firstWhere(
        (m) => m.id == muezzinId,
        orElse: () => MuezzinsData.muezzins.first,
      );

      final now = DateTime.now();
      final times = PrayerCalculator.calculate(
        date: now,
        latitude: _latitude,
        longitude: _longitude,
      );

      setState(() {
        _locationName = loc;
        _alertSettings = alerts;
        _selectedMuezzinName = muezzin.name;
        _prayerTimes = times;
        _isLoading = false;
      });

      _updateCountdown();
    } catch (_) {
      setState(() {
        _isLoading = false;
      });
    }
  }

  void _updateCountdown() {
    if (_prayerTimes == null) return;

    final now = DateTime.now();
    final prayers = {
      'الفجر': _prayerTimes!.fajr,
      'الشروق': _prayerTimes!.sunrise,
      'الظهر': _prayerTimes!.dhuhr,
      'العصر': _prayerTimes!.asr,
      'المغرب': _prayerTimes!.maghrib,
      'العشاء': _prayerTimes!.isha,
    };

    String nextName = 'الفجر';
    DateTime nextTime = _prayerTimes!.fajr;

    // البحث عن الصلاة القادمة
    bool found = false;
    for (var entry in prayers.entries) {
      if (entry.value.isAfter(now)) {
        nextName = entry.key;
        nextTime = entry.value;
        found = true;
        break;
      }
    }

    // إذا انتهت كل صلوات اليوم، فالصلاة القادمة هي فجر اليوم التالي
    if (!found) {
      nextName = 'الفجر';
      final tomorrow = now.add(const Duration(days: 1));
      final tomorrowTimes = PrayerCalculator.calculate(
        date: tomorrow,
        latitude: _latitude,
        longitude: _longitude,
      );
      nextTime = tomorrowTimes.fajr;
    }

    final diff = nextTime.difference(now);

    setState(() {
      _nextPrayerName = nextName;
      _timeRemaining = diff;
    });
  }

  // تحديد ألوان الخلفية ديناميكياً حسب الوقت (فجر، نهار، غروب، ليل)
  List<Color> _getDynamicBackgroundColors() {
    final hour = DateTime.now().hour;
    if (hour >= 4 && hour < 7) {
      // فجر وشروق
      return [const Color(stringToColor('2b5876')), const Color(stringToColor('4e4376'))];
    } else if (hour >= 7 && hour < 17) {
      // نهار
      return [const Color(0xFF2980B9), const Color(0xFF6DD5FA)];
    } else if (hour >= 17 && hour < 19) {
      // غروب
      return [const Color(0xFF8E44AD), const Color(0xFFE67E22)];
    } else {
      // ليل
      return [const Color(0xFF0F2027), const Color(0xFF203A43), const Color(0xFF2C5364)];
    }
  }

  void _showSettingsDialog() {
    showModalBottomSheet(
      context: context,
      backgroundColor: const Color(0xFF1E1E2C),
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (context) {
        return StatefulBuilder(
          builder: (context, setModalState) {
            return Container(
              padding: const EdgeInsets.all(20),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    'خيارات التنبيه (بدون إنترنت)',
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  const SizedBox(height: 15),
                  Expanded(
                    child: ListView(
                      children: _alertSettings.keys.map((prayer) {
                        final currentType = _alertSettings[prayer] ?? AlertType.fullAdhan;
                        return ListTile(
                          title: Text(prayer, style: const TextStyle(color: Colors.white)),
                          trailing: DropdownButton<AlertType>(
                            value: currentType,
                            dropdownColor: const Color(0xFF2C2C3E),
                            style: const TextStyle(color: Colors.white),
                            items: const [
                              DropdownMenuItem(value: AlertType.fullAdhan, child: Text('أذان كامل')),
                              DropdownMenuItem(value: AlertType.takbeerOnly, child: Text('تكبير فقط')),
                              DropdownMenuItem(value: AlertType.vibrate, child: Text('اهتزاز')),
                              DropdownMenuItem(value: AlertType.silent, child: Text('صامت')),
                            ],
                            onChanged: (val) async {
                              if (val != null) {
                                setState(() {
                                  _alertSettings[prayer] = val;
                                });
                                setModalState(() {});
                                await StorageService.saveAlertSettings(_alertSettings);
                              }
                            },
                          ),
                        );
                      }).toList(),
                    ),
                  ),
                ],
              ),
            );
          },
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    if (_isLoading || _prayerTimes == null) {
      return const Scaffold(
        backgroundColor: Color(0xFF0F2027),
        body: Center(child: CircularProgressIndicator(color: Colors.amber)),
      );
    }

    final bgColors = _getDynamicBackgroundColors();
    final hours = _timeRemaining.inHours;
    final minutes = _timeRemaining.inMinutes.remainder(60);
    final seconds = _timeRemaining.inSeconds.remainder(60);

    return Scaffold(
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: bgColors,
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
          ),
        ),
        child: SafeArea(
          child: Column(
            children: [
              // شريط العلوى
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Row(
                      children: [
                        const Icon(Icons.location_on, color: Colors.amber),
                        const SizedBox(width: 5),
                        Text(
                          _locationName,
                          style: const TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.bold),
                        ),
                      ],
                    ),
                    IconButton(
                      icon: const Icon(Icons.settings, color: Colors.white),
                      onPressed: _showSettingsDialog,
                    ),
                  ],
                ),
              ),

              // بطاقة العد التنازلي للصلاة القادمة
              Container(
                margin: const EdgeInsets.all(20),
                padding: const EdgeInsets.all(20),
                decoration: BoxDecoration(
                  color: Colors.white.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(color: Colors.white.withOpacity(0.2)),
                ),
                child: Column(
                  children: [
                    Text(
                      'المتبقي حتى صلاة $_nextPrayerName',
                      style: TextStyle(color: Colors.white.withOpacity(0.8), fontSize: 16),
                    ),
                    const SizedBox(height: 10),
                    Text(
                      '${hours.toString().padLeft(2, '0')}:${minutes.toString().padLeft(2, '0')}:${seconds.toString().padLeft(2, '0')}',
                      style: const TextStyle(
                        color: Colors.amber,
                        fontSize: 40,
                        fontWeight: FontWeight.bold,
                        letterSpacing: 2,
                      ),
                    ),
                    const SizedBox(height: 10),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        const Icon(Icons.volume_up, color: Colors.white70, size: 16),
                        const SizedBox(width: 5),
                        Text(
                          'المؤذن: $_selectedMuezzinName',
                          style: const TextStyle(color: Colors.white70, fontSize: 14),
                        ),
                      ],
                    ),
                  ],
                ),
              ),

              // قائمة مواقيت الصلاة اليومية
              Expanded(
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 20),
                  decoration: const BoxDecoration(
                    color: Color(0x990F2027),
                    borderRadius: BorderRadius.vertical(top: Radius.circular(30)),
                  ),
                  child: ListView(
                    children: [
                      const SizedBox(height: 15),
                      _buildPrayerRow('الفجر', _prayerTimes!.fajr, _nextPrayerName == 'الفجر'),
                      _buildPrayerRow('الشروق', _prayerTimes!.sunrise, _nextPrayerName == 'الشروق'),
                      _buildPrayerRow('الظهر', _prayerTimes!.dhuhr, _nextPrayerName == 'الظهر'),
                      _buildPrayerRow('العصر', _prayerTimes!.asr, _nextPrayerName == 'العصر'),
                      _buildPrayerRow('المغرب', _prayerTimes!.maghrib, _nextPrayerName == 'المغرب'),
                      _buildPrayerRow('العشاء', _prayerTimes!.isha, _nextPrayerName == 'العشاء'),
                      const SizedBox(height: 20),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildPrayerRow(String name, DateTime time, bool isNext) {
    final timeFormatted = '${time.hour.toString().padLeft(2, '0')}:${time.minute.toString().padLeft(2, '0')}';
    final alertType = _alertSettings[name] ?? AlertType.fullAdhan;

    IconData alertIcon;
    switch (alertType) {
      case AlertType.fullAdhan:
        alertIcon = Icons.volume_up;
        break;
      case AlertType.takbeerOnly:
        alertIcon = Icons.notifications_active;
        break;
      case AlertType.vibrate:
        alertIcon = Icons.vibration;
        break;
      case AlertType.silent:
        alertIcon = Icons.notifications_off;
        break;
    }

    return Container(
      margin: const EdgeInsets.symmetric(vertical: 6),
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
      decoration: BoxDecoration(
        color: isNext ? Colors.amber.withOpacity(0.2) : Colors.white.withOpacity(0.05),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: isNext ? Colors.amber : Colors.transparent,
          width: 1.5,
        ),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Row(
            children: [
              Icon(alertIcon, color: isNext ? Colors.amber : Colors.white70, size: 20),
              const SizedBox(width: 12),
              Text(
                name,
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 16,
                  fontWeight: isNext ? FontWeight.bold : FontWeight.normal,
                ),
              ),
            ],
          ),
          Text(
            timeFormatted,
            style: TextStyle(
              color: isNext ? Colors.amber : Colors.white,
              fontSize: 16,
              fontWeight: isNext ? FontWeight.bold : FontWeight.normal,
            ),
          ),
        ],
      ),
    );
  }
}

int stringToColor(String hex) {
  return 0xFF2B5876;
}
