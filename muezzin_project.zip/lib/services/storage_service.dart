import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';

/// خيارات التنبيه المتاحة لكل صلاة
enum AlertType {
  fullAdhan, // أذان كامل
  takbeerOnly, // تكبير فقط
  silent, // صامت
  vibrate, // اهتزاز
}

/// خدمة إدارة التفضيلات والتخزين المحلي (Offline First)
class StorageService {
  static const String _keyPrayerAlerts = 'prayer_alerts_map';
  static const String _keySelectedMuezzin = 'selected_muezzin_id';
  static const String _keyUserLocation = 'user_location_name';

  /// حفظ خيارات التنبيه لكل صلاة
  static Future<void> saveAlertSettings(Map<String, AlertType> settings) async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final Map<String, String> data = settings.map((key, value) => MapEntry(key, value.name));
      await prefs.setString(_keyPrayerAlerts, jsonEncode(data));
    } catch (_) {
      // معالجة الأخطاء لضمان استقرار التطبيق
    }
  }

  /// استرجاع خيارات التنبيه لكل صلاة
  static Future<Map<String, AlertType>> getAlertSettings() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final String? jsonString = prefs.getString(_keyPrayerAlerts);
      if (jsonString == null) {
        // القيم الافتراضية: أذان كامل لكل الصلوات
        return {
          'الفجر': AlertType.fullAdhan,
          'الشروق': AlertType.silent,
          'الظهر': AlertType.fullAdhan,
          'العصر': AlertType.fullAdhan,
          'المغرب': AlertType.fullAdhan,
          'العشاء': AlertType.fullAdhan,
        };
      }
      final Map<String, dynamic> decoded = jsonDecode(jsonString);
      return decoded.map((key, value) {
        AlertType type = AlertType.fullAdhan;
        for (var t in AlertType.values) {
          if (t.name == value) {
            type = t;
            break;
          }
        }
        return MapEntry(key, type);
      });
    } catch (_) {
      return {
        'الفجر': AlertType.fullAdhan,
        'الشروق': AlertType.silent,
        'الظهر': AlertType.fullAdhan,
        'العصر': AlertType.fullAdhan,
        'المغرب': AlertType.fullAdhan,
        'العشاء': AlertType.fullAdhan,
      };
    }
  }

  /// حفظ المؤذن المفضل
  static Future<void> saveSelectedMuezzin(String muezzinId) async {
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setString(_keySelectedMuezzin, muezzinId);
    } catch (_) {}
  }

  /// جلب المؤذن المفضل (الافتراضي: الشيخ علي ملا - m1)
  static Future<String> getSelectedMuezzin() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      return prefs.getString(_keySelectedMuezzin) ?? 'm1';
    } catch (_) {
      return 'm1';
    }
  }

  /// حفظ اسم الموقع الجغرافي
  static Future<void> saveUserLocation(String locationName) async {
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setString(_keyUserLocation, locationName);
    } catch (_) {}
  }

  /// جلب اسم الموقع الجغرافي (الافتراضي: مكة المكرمة)
  static Future<String> getUserLocation() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      return prefs.getString(_keyUserLocation) ?? 'مكة المكرمة';
    } catch (_) {
      return 'مكة المكرمة';
    }
  }
}
