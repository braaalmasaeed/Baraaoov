import 'package:flutter/material.dart';
import 'home_screen.dart';
import 'quran_screen.dart';
import 'azkar_screen.dart';
import 'settings_screen.dart';
import '../services/storage_service.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const MuezzinApp());
}

class MuezzinApp extends StatefulWidget {
  const MuezzinApp({Key? key}) : super(key: key);

  @override
  State<MuezzinApp> createState() => _MuezzinAppState();
}

class _MuezzinAppState extends State<MuezzinApp> {
  bool _isDarkMode = true;

  @override
  void initState() {
    super.initState();
    _loadTheme();
  }

  Future<void> _loadTheme() async {
    final isDark = await StorageService.getIsDarkMode();
    setState(() {
      _isDarkMode = isDark;
    });
  }

  void _toggleTheme() async {
    final isDark = await StorageService.getIsDarkMode();
    setState(() {
      _isDarkMode = isDark;
    });
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'المؤذن',
      debugShowCheckedModeBanner: false,
      themeMode: _isDarkMode ? ThemeMode.dark : ThemeMode.light,
      theme: ThemeData(
        brightness: Brightness.light,
        primarySwatch: Colors.green,
        scaffoldBackgroundColor: const Color(0xFFF5F7F8),
        fontFamily: 'Amiri',
      ),
      darkTheme: ThemeData(
        brightness: Brightness.dark,
        primarySwatch: Colors.green,
        scaffoldBackgroundColor: const Color(0xFF0F2027),
        cardColor: const Color(0xFF1E1E2C),
        fontFamily: 'Amiri',
      ),
      home: MainNavigationContainer(onThemeChanged: _toggleTheme),
    );
  }
}

class MainNavigationContainer extends StatefulWidget {
  final VoidCallback onThemeChanged;
  const MainNavigationContainer({Key? key, required this.onThemeChanged}) : super(key: key);

  @override
  State<MainNavigationContainer> createState() => _MainNavigationContainerState();
}

class _MainNavigationContainerState extends State<MainNavigationContainer> {
  int _currentIndex = 0;

  late final List<Widget> _screens;

  @override
  void initState() {
    super.initState();
    _screens = [
      const HomeScreen(),
      const QuranScreen(),
      const AzkarScreen(),
      SettingsScreen(onThemeChanged: widget.onThemeChanged),
    ];
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: IndexedStack(
        index: _currentIndex,
        children: _screens,
      ),
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _currentIndex,
        type: BottomNavigationBarType.fixed,
        selectedItemColor: Colors.amber,
        unselectedItemColor: Colors.grey,
        onTap: (index) {
          setState(() {
            _currentIndex = index;
          });
        },
        items: const [
          BottomNavigationBarItem(
            icon: Icon(Icons.home),
            label: 'الرئيسية',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.book),
            label: 'القرآن',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.auto_stories),
            label: 'الأذكار',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.settings),
            label: 'الإعدادات',
          ),
        ],
      ),
    );
  }
}
