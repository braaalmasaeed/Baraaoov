import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';

enum AlertType {
  fullAdhan,
  takbeerOnly,
  silent,
  vibrate,
}

class StorageService {
  static const String _keyPrayerAlerts = 'prayer_alerts_map';
  static const String _keySelectedMuezzin = 'selected_muezzin_id';
  static const String _keyUserLocation = 'user_location_name';
  static const String _keyIs24Hour = 'is_24_hour_format';
  static const String _keyIsDarkMode = 'is_dark_mode_enabled';

  static Future<void> saveAlertSettings(Map<String, AlertType> settings) async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final Map<String, String> data = settings.map((key, value) => MapEntry(key, value.name));
      await prefs.setString(_keyPrayerAlerts, jsonEncode(data));
    } catch (_) {}
  }

  static Future<Map<String, AlertType>> getAlertSettings() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final String? jsonString = prefs.getString(_keyPrayerAlerts);
      if (jsonString == null) {
        return {
          'الفجر': AlertType.fullAdhan,
          'الشروق': AlertType.silent,
          'الظهر': AlertType.fullAdhan,
          'العصر': AlertType.fullAdhan,
          'المغرب': AlertType.fullAdhan,
          'العشاء': AlertType.fullAdhan,
        };
      }
      final Map<String, dynamic> decoded = jsonDecode(jsonString);
      return decoded.map((key, value) {
        AlertType type = AlertType.fullAdhan;
        for (var t in AlertType.values) {
          if (t.name == value) {
            type = t;
            break;
          }
        }
        return MapEntry(key, type);
      });
    } catch (_) {
      return {
        'الفجر': AlertType.fullAdhan,
        'الشروق': AlertType.silent,
        'الظهر': AlertType.fullAdhan,
        'العصر': AlertType.fullAdhan,
        'المغرب': AlertType.fullAdhan,
        'العشاء': AlertType.fullAdhan,
      };
    }
  }

  static Future<void> saveSelectedMuezzin(String muezzinId) async {
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setString(_keySelectedMuezzin, muezzinId);
    } catch (_) {}
  }

  static Future<String> getSelectedMuezzin() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      return prefs.getString(_keySelectedMuezzin) ?? 'm1';
    } catch (_) {
      return 'm1';
    }
  }

  static Future<void> saveUserLocation(String locationName) async {
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setString(_keyUserLocation, locationName);
    } catch (_) {}
  }

  static Future<String> getUserLocation() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      return prefs.getString(_keyUserLocation) ?? 'مكة المكرمة';
    } catch (_) {
      return 'مكة المكرمة';
    }
  }

  static Future<void> saveIs24Hour(bool is24) async {
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setBool(_keyIs24Hour, is24);
    } catch (_) {}
  }

  static Future<bool> getIs24Hour() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      return prefs.getBool(_keyIs24Hour) ?? true;
    } catch (_) {
      return true;
    }
  }

  static Future<void> saveIsDarkMode(bool isDark) async {
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setBool(_keyIsDarkMode, isDark);
    } catch (_) {}
  }

  static Future<bool> getIsDarkMode() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      return prefs.getBool(_keyIsDarkMode) ?? true;
    } catch (_) {
      return true;
    }
  }
}
