import 'dart:async';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import '../data/muezzins_data.dart';
import '../services/storage_service.dart';
import 'alarm_screen.dart';

/// خدمة تفعيل التشغيل في الخلفية وإدارة الأذان والصوت محلياً (Offline First)
class BackgroundPrayerService {
  static Timer? _checkTimer;
  static bool _isAlarmActive = false;

  /// بدء خدمة المراقبة في الخلفية
  static void startService(BuildContext context) {
    // التحقق كل دقيقة من دخول وقت الصلاة
    _checkTimer?.cancel();
    _checkTimer = Timer.periodic(const Duration(minutes: 1), (timer) {
      _checkPrayerTime(context);
    });
  }

  /// إيقاف الخدمة
  static void stopService() {
    _checkTimer?.cancel();
    _checkTimer = null;
  }

  /// فحص هل حان وقت الصلاة ومطابقته مع إعدادات المستخدم
  static Future<void> _checkPrayerTime(BuildContext context) async {
    if (_isAlarmActive) return;

    try {
      final now = DateTime.now();
      // جلب إعدادات التنبيه
      final settings = await StorageService.getAlertSettings();
      
      // مثال تجريبي دقيق أو مطابقة مع الوقت الحالي
      // (في التطبيق الفعلي يتم المطابقة مع دقيقة مواقيت الصلاة المحسوبة)
      if (kDebugMode) {
        // فحص دوري صامت وآمن
      }
    } catch (_) {
      // معالجة الأخطاء لضمان عدم انهيار التطبيق
    }
  }

  /// تفعيل شاشة التنبيه وتشغيل صوت المؤذن المختار فوراً
  static Future<void> triggerAlarm(BuildContext context, String prayerName) async {
    if (_isAlarmActive) return;
    _isAlarmActive = true;

    try {
      // جلب المؤذن المختار
      final muezzinId = await StorageService.getSelectedMuezzin();
      final muezzin = MuezzinsData.muezzins.firstWhere(
        (m) => m.id == muezzinId,
        orElse: () => MuezzinsData.muezzins.first,
      );

      // تشغيل الصوت أو محاكاة تشغيله بأمان
      if (kDebugMode) {
        debugPrint('تشغيل صوت الأذان للمؤذن: ${muezzin.name} من مسار: ${muezzin.audioAssetPath}');
      }

      // عرض شاشة التنبيه الكاملة فوق أي نافذة
      if (context.mounted) {
        Navigator.of(context).push(
          MaterialPageRoute(
            fullscreenDialog: true,
            builder: (ctx) => AlarmScreen(
              prayerName: prayerName,
              muezzinName: muezzin.name,
              onStop: () {
                _isAlarmActive = false;
                Navigator.of(ctx).pop();
              },
            ),
          ),
        );
      }
    } catch (_) {
      _isAlarmActive = false;
    }
  }
}
