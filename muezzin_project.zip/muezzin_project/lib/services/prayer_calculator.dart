import 'dart:math' as math;

/// Calculation conventions for prayer times
enum CalculationMethod {
  ummAlQura, // أم القرى - مكة المكرمة
  muslimWorldLeague, // رابطة العالم الإسلامي
  egyptian, // الهيئة العامة المصرية للمساحة
  karachi, // جامعة العلوم الإسلامية بكراتشي
  northAmerica, // ISNA
}

/// Juristic method for Asr prayer
enum AsrJuristic {
  shafii, // الشافعي والمالكي والحنبلي (ظل المثل)
  hanafi, // الحنفي (ظل المثلين)
}

/// Represents calculated prayer times for a single day
class PrayerTimesResult {
  final DateTime fajr;
  final DateTime sunrise;
  final DateTime dhuhr;
  final DateTime asr;
  final DateTime maghrib;
  final DateTime isha;

  const PrayerTimesResult({
    required this.fajr,
    required this.sunrise,
    required this.dhuhr,
    required this.asr,
    required this.maghrib,
    required this.isha,
  });

  Map<String, DateTime> toMap() => {
    'الفجر': fajr,
    'الشروق': sunrise,
    'الظهر': dhuhr,
    'العصر': asr,
    'المغرب': maghrib,
    'العشاء': isha,
  };
}

/// Pure Dart offline calculation of Islamic prayer times.
/// Lightweight, zero external dependencies.
class PrayerCalculator {
  static const double _degToRad = math.pi / 180.0;
  static const double _radToDeg = 180.0 / math.pi;

  static double _fixAngle(double a) => a - 360.0 * (a / 360.0).floor();
  static double _fixHour(double a) => a - 24.0 * (a / 24.0).floor();

  /// Calculates prayer times for a given date, coordinates, and timezone offset
  static PrayerTimesResult calculate({
    required DateTime date,
    required double latitude,
    required double longitude,
    double? timeZoneOffset,
    CalculationMethod method = CalculationMethod.ummAlQura,
    AsrJuristic asrJuristic = AsrJuristic.shafii,
  }) {
    final double tz = timeZoneOffset ?? (date.timeZoneOffset.inMinutes / 60.0);

    // Julian Date calculation
    final int year = date.year;
    final int month = date.month;
    final int day = date.day;

    int y = year;
    int m = month;
    if (m <= 2) {
      y -= 1;
      m += 12;
    }
    final int a = (y / 100).floor();
    final int b = 2 - a + (a / 4).floor();
    final double jd = (365.25 * (y + 4716)).floor() +
        (30.6001 * (m + 1)).floor() +
        day +
        b -
        1524.5;

    final double d = jd - 2451545.0;

    // Sun coordinates
    final double g = _fixAngle(357.529 + 0.98560028 * d);
    final double q = _fixAngle(280.459 + 0.98564736 * d);
    final double l = _fixAngle(
        q + 1.915 * math.sin(g * _degToRad) + 0.020 * math.sin(2 * g * _degToRad));

    final double e = 23.439 - 0.00000036 * d;
    final double ra = _radToDeg *
        math.atan2(
            math.cos(e * _degToRad) * math.sin(l * _degToRad),
            math.cos(l * _degToRad)) /
        15.0;
    final double rightAscension = _fixHour(ra);
    final double declination =
        math.asin(math.sin(e * _degToRad) * math.sin(l * _degToRad)) * _radToDeg;

    final double eqT = q / 15.0 - rightAscension;

    // Midday (Dhuhr)
    final double noon = _fixHour(12.0 + tz - (longitude / 15.0) - eqT);

    // Sun altitude parameters based on method
    double fajrAngle = 18.5; // Umm Al-Qura default
    double ishaAngle = 19.0;
    bool isIshaInterval = false;
    double ishaIntervalMinutes = 90;

    switch (method) {
      case CalculationMethod.ummAlQura:
        fajrAngle = 18.5;
        isIshaInterval = true; // Isha is 90 min after Maghrib (120 in Ramadan)
        ishaIntervalMinutes = 90;
        break;
      case CalculationMethod.muslimWorldLeague:
        fajrAngle = 18.0;
        ishaAngle = 17.0;
        break;
      case CalculationMethod.egyptian:
        fajrAngle = 19.5;
        ishaAngle = 17.5;
        break;
      case CalculationMethod.karachi:
        fajrAngle = 18.0;
        ishaAngle = 18.0;
        break;
      case CalculationMethod.northAmerica:
        fajrAngle = 15.0;
        ishaAngle = 15.0;
        break;
    }

    // Sunrise & Sunset angle (considering refraction and solar disk: -0.833°)
    final double sunriseAngle = 0.833;

    double sunAngleTime(double angle, {bool isAfterNoon = false}) {
      try {
        final double latRad = latitude * _degToRad;
        final double decRad = declination * _degToRad;
        final double angRad = angle * _degToRad;

        final double cosH = (-math.sin(angRad) - math.sin(latRad) * math.sin(decRad)) /
            (math.cos(latRad) * math.cos(decRad));

        if (cosH > 1.0 || cosH < -1.0) {
          return noon; // Extreme latitudes fallback
        }

        final double h = math.acos(cosH) * _radToDeg / 15.0;
        return isAfterNoon ? (noon + h) : (noon - h);
      } catch (_) {
        return noon;
      }
    }

    // Asr time
    final int asrFactor = asrJuristic == AsrJuristic.hanafi ? 2 : 1;
    final double asrAltitude = -_radToDeg *
        math.atan(1.0 /
            (asrFactor +
                math.tan((latitude - declination).abs() * _degToRad)));
    final double asrHour = sunAngleTime(-asrAltitude, isAfterNoon: true);

    // Calculated base hours
    final double fajrHour = sunAngleTime(fajrAngle, isAfterNoon: false);
    final double sunriseHour = sunAngleTime(sunriseAngle, isAfterNoon: false);
    final double dhuhrHour = noon;
    final double sunsetHour = sunAngleTime(sunriseAngle, isAfterNoon: true);
    final double maghribHour = sunsetHour;
    
    double ishaHour;
    if (isIshaInterval) {
      ishaHour = maghribHour + (ishaIntervalMinutes / 60.0);
    } else {
      ishaHour = sunAngleTime(ishaAngle, isAfterNoon: true);
    }

    DateTime toDateTime(double decimalHour) {
      final double hourWrapped = _fixHour(decimalHour);
      int hours = hourWrapped.floor();
      final double totalMinutes = (hourWrapped - hours) * 60.0;
      int minutes = totalMinutes.floor();
      int seconds = ((totalMinutes - minutes) * 60.0).round();
      if (seconds >= 60) {
        minutes += 1;
        seconds = 0;
      }
      if (minutes >= 60) {
        hours = (hours + 1) % 24;
        minutes = 0;
      }
      return DateTime(year, month, day, hours, minutes, seconds);
    }

    return PrayerTimesResult(
      fajr: toDateTime(fajrHour),
      sunrise: toDateTime(sunriseHour),
      dhuhr: toDateTime(dhuhrHour),
      asr: toDateTime(asrHour),
      maghrib: toDateTime(maghribHour),
      isha: toDateTime(ishaHour),
    );
  }
}
