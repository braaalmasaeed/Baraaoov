import 'package:flutter/material.dart';
import '../data/muezzins_data.dart';
import '../services/storage_service.dart';

class SettingsScreen extends StatefulWidget {
  final VoidCallback onThemeChanged;
  const SettingsScreen({Key? key, required this.onThemeChanged}) : super(key: key);

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  String _selectedLocation = 'مكة المكرمة';
  String _selectedMuezzinId = 'm1';
  bool _is24Hour = true;
  bool _isDarkMode = true;
  Map<String, AlertType> _alertSettings = {};

  final List<String> _cities = [
    'مكة المكرمة',
    'المدينة المنورة',
    'الرياض',
    'جدة',
    'الدمام',
    'عمان',
    'القدس',
    'القاهرة',
    'دبي',
    'الدوحة',
  ];

  @override
  void initState() {
    super.initState();
    _loadSettings();
  }

  Future<void> _loadSettings() async {
    final loc = await StorageService.getUserLocation();
    final muezzin = await StorageService.getSelectedMuezzin();
    final is24 = await StorageService.getIs24Hour();
    final isDark = await StorageService.getIsDarkMode();
    final alerts = await StorageService.getAlertSettings();

    setState(() {
      _selectedLocation = loc;
      _selectedMuezzinId = muezzin;
      _is24Hour = is24;
      _isDarkMode = isDark;
      _alertSettings = alerts;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('الإعدادات', style: TextStyle(fontFamily: 'Amiri', fontWeight: FontWeight.bold)),
        centerTitle: true,
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          // 1. بطاقة الموقع الجغرافي
          _buildCard(
            title: 'الموقع الجغرافي',
            icon: Icons.location_on,
            children: [
              DropdownButtonFormField<String>(
                value: _selectedLocation,
                dropdownColor: Theme.of(context).cardColor,
                decoration: const InputDecoration(border: OutlineInputBorder()),
                items: _cities.map((city) {
                  return DropdownMenuItem(value: city, child: Text(city));
                }).toList(),
                onChanged: (val) async {
                  if (val != null) {
                    setState(() => _selectedLocation = val);
                    await StorageService.saveUserLocation(val);
                  }
                },
              ),
            ],
          ),
          const SizedBox(height: 16),

          // 2. بطاقة المؤذن الصوتي
          _buildCard(
            title: 'اختر المؤذن',
            icon: Icons.volume_up,
            children: [
              DropdownButtonFormField<String>(
                value: _selectedMuezzinId,
                dropdownColor: Theme.of(context).cardColor,
                decoration: const InputDecoration(border: OutlineInputBorder()),
                items: MuezzinsData.muezzins.map((m) {
                  return DropdownMenuItem(
                    value: m.id,
                    child: Text('${m.name} (${m.location})'),
                  );
                }).toList(),
                onChanged: (val) async {
                  if (val != null) {
                    setState(() => _selectedMuezzinId = val);
                    await StorageService.saveSelectedMuezzin(val);
                  }
                },
              ),
            ],
          ),
          const SizedBox(height: 16),

          // 3. بطاقة إعدادات الوقت والتاريخ
          _buildCard(
            title: 'نظام الوقت والتاريخ',
            icon: Icons.access_time,
            children: [
              SwitchListTile(
                title: const Text('نظام 24 ساعة (عوضاً عن 12 ساعة ص/م)'),
                value: _is24Hour,
                onChanged: (val) async {
                  setState(() => _is24Hour = val);
                  await StorageService.saveIs24Hour(val);
                },
              ),
            ],
          ),
          const SizedBox(height: 16),

          // 4. بطاقة المظهر (الوضع الليلي)
          _buildCard(
            title: 'المظهر',
            icon: Icons.brightness_6,
            children: [
              SwitchListTile(
                title: const Text('تفعيل الوضع الليلي (Dark Mode)'),
                value: _isDarkMode,
                onChanged: (val) async {
                  setState(() => _isDarkMode = val);
                  await StorageService.saveIsDarkMode(val);
                  widget.onThemeChanged();
                },
              ),
            ],
          ),
          const SizedBox(height: 16),

          // 5. بطاقة تنبيهات الصلوات
          _buildCard(
            title: 'حالة تنبيهات الصلوات',
            icon: Icons.notifications_active,
            children: _alertSettings.keys.map((prayer) {
              final type = _alertSettings[prayer] ?? AlertType.fullAdhan;
              return Padding(
                padding: const EdgeInsets.symmetric(vertical: 6),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(prayer, style: const TextStyle(fontSize: 16)),
                    DropdownButton<AlertType>(
                      value: type,
                      items: const [
                        DropdownMenuItem(value: AlertType.fullAdhan, child: Text('أذان كامل')),
                        DropdownMenuItem(value: AlertType.takbeerOnly, child: Text('تكبير فقط')),
                        DropdownMenuItem(value: AlertType.vibrate, child: Text('اهتزاز')),
                        DropdownMenuItem(value: AlertType.silent, child: Text('صامت')),
                      ],
                      onChanged: (val) async {
                        if (val != null) {
                          setState(() => _alertSettings[prayer] = val);
                          await StorageService.saveAlertSettings(_alertSettings);
                        }
                      },
                    ),
                  ],
                ),
              );
            }).toList(),
          ),
          const SizedBox(height: 16),

          // 6. صلاحيات النظام (الإشعارات والظهور فوق التطبيقات)
          _buildCard(
            title: 'صلاحيات النظام',
            icon: Icons.security,
            children: [
              ElevatedButton.icon(
                onPressed: () {
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(content: Text('تم تفعيل صلاحيات الإشعارات والظهور فوق التطبيقات بنجاح')),
                  );
                },
                icon: const Icon(Icons.check_circle),
                label: const Text('منح صلاحية الإشعارات والظهور فوق التطبيقات'),
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.green.shade700,
                  foregroundColor: Colors.white,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildCard({required String title, required IconData icon, required List<Widget> children}) {
    return Card(
      elevation: 3,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Icon(icon, color: Colors.green.shade700),
                const SizedBox(width: 10),
                Text(
                  title,
                  style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold, fontFamily: 'Amiri'),
                ),
              ],
            ),
            const Divider(height: 20),
            ...children,
          ],
        ),
      ),
    );
  }
}
