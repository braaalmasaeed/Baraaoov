import 'package:flutter/material.dart';

class AzkarScreen extends StatefulWidget {
  const AzkarScreen({Key? key}) : super(key: key);

  @override
  State<AzkarScreen> createState() => _AzkarScreenState();
}

class _AzkarScreenState extends State<AzkarScreen> {
  double _fontSize = 16.0;

  final List<Map<String, dynamic>> _azkarCategories = const [
    {
      'title': 'أذكار الصباح',
      'icon': Icons.wb_sunny,
      'color': Colors.amber,
      'items': [
        'أصبحنا وأصبح الملك لله، والحمد لله، لا إله إلا الله وحده لا شريك له.',
        'اللهم ما أصبح بي من نعمة أو بأحد من خلقك فمنك وحدك لا شريك لك، فلك الحمد ولك الشكر.',
        'رضيت بالله رباً، وبالإسلام ديناً، وبمحمد صلى الله عليه وسلم نبياً.',
      ],
    },
    {
      'title': 'أذكار المساء',
      'icon': Icons.nightlight_round,
      'color': Colors.indigo,
      'items': [
        'أمسينا وأمسى الملك لله، والحمد لله، لا إله إلا الله وحده لا شريك له.',
        'اللهم بك أمسينا وبك أصبحنا، وبك نحيا وبك نموت وإليك المصير.',
        'أعوذ بكلمات الله التامات من شر ما خلق.',
      ],
    },
    {
      'title': 'أذكار النوم',
      'icon': Icons.bed,
      'color': Colors.purple,
      'items': [
        'باسمك ربي وضعت جنبي وبك أرفعه، إن أمسكت نفسي فارحمنا وإن أرسلتها فاحفظها بما تحفظ به عبادك الصالحين.',
        'اللهم قني عذابك يوم تبعث عبادك (ثلاث مرات).',
      ],
    },
    {
      'title': 'أذكار الصلاة',
      'icon': Icons.mosque,
      'color': Colors.green,
      'items': [
        'استغفر الله (ثلاثاً)، اللهم أنت السلام ومنك السلام، تباركت يا ذا الجلال والإكرام.',
        'لا إله إلا الله وحده لا شريك له، له الملك وله الحمد وهو على كل شيء قدير.',
      ],
    },
    {
      'title': 'أذكار الاستيقاظ',
      'icon': Icons.alarm,
      'color': Colors.teal,
      'items': [
        'الحي القيوم الذي أحيانا بعد ما أماتنا وإليه النشور.',
        'الحمد لله الذي عافاني في جسدي ورد علي روحي وأذن لي بذكره.',
      ],
    },
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('حصن المسلم - الأذكار', style: TextStyle(fontFamily: 'Amiri', fontWeight: FontWeight.bold)),
        centerTitle: true,
        actions: [
          // خيارات تكبير وتصغير الخط في أعلى يمين الشاشة
          PopupMenuButton<String>(
            icon: const Icon(Icons.text_format),
            onSelected: (value) {
              setState(() {
                if (value == 'increase' && _fontSize < 28.0) {
                  _fontSize += 2.0;
                } else if (value == 'decrease' && _fontSize > 12.0) {
                  _fontSize -= 2.0;
                }
              });
            },
            itemBuilder: (context) => [
              const PopupMenuItem(
                value: 'increase',
                child: Row(
                  children: [
                    Icon(Icons.zoom_in, color: Colors.black54),
                    SizedBox(width: 8),
                    Text('تكبير الخط'),
                  ],
                ),
              ),
              const PopupMenuItem(
                value: 'decrease',
                child: Row(
                  children: [
                    Icon(Icons.zoom_out, color: Colors.black54),
                    SizedBox(width: 8),
                    Text('تصغير الخط'),
                  ],
                ),
              ),
            ],
          ),
        ],
      ),
      body: ListView.builder(
        padding: const EdgeInsets.all(16),
        itemCount: _azkarCategories.length,
        itemBuilder: (context, index) {
          final cat = _azkarCategories[index];
          return Card(
            elevation: 3,
            margin: const EdgeInsets.symmetric(vertical: 8),
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
            child: ExpansionTile(
              leading: CircleAvatar(
                backgroundColor: cat['color'],
                child: Icon(cat['icon'], color: Colors.white),
              ),
              title: Text(
                cat['title'],
                style: TextStyle(fontSize: _fontSize + 2, fontWeight: FontWeight.bold, fontFamily: 'Amiri'),
              ),
              children: (cat['items'] as List<String>).map((item) {
                return Container(
                  padding: const EdgeInsets.all(12),
                  margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
                  decoration: BoxDecoration(
                    color: Colors.green.shade50.withOpacity(0.05),
                    borderRadius: BorderRadius.circular(10),
                    border: Border.all(color: Colors.green.shade100.withOpacity(0.2)),
                  ),
                  child: Text(
                    item,
                    style: TextStyle(fontSize: _fontSize, fontFamily: 'Amiri', height: 1.5),
                    textAlign: TextAlign.right,
                  ),
                );
              }).toList(),
            ),
          );
        },
      ),
    );
  }
}
