import 'package:flutter/material.dart';

class QuranScreen extends StatefulWidget {
  const QuranScreen({Key? key}) : super(key: key);

  @override
  State<QuranScreen> createState() => _QuranScreenState();
}

class _QuranScreenState extends State<QuranScreen> {
  double _fontSize = 18.0;

  final List<Map<String, dynamic>> _surahs = const [
    {'number': 1, 'name': 'سورة الفاتحة', 'type': 'مكية', 'ayahs': 7},
    {'number': 2, 'name': 'سورة البقرة', 'type': 'مدنية', 'ayahs': 286},
    {'number': 3, 'name': 'سورة آل عمران', 'type': 'مدنية', 'ayahs': 200},
    {'number': 18, 'name': 'سورة الكهف', 'type': 'مكية', 'ayahs': 110},
    {'number': 36, 'name': 'سورة يس', 'type': 'مكية', 'ayahs': 83},
    {'number': 56, 'name': 'سورة الواقعة', 'type': 'مكية', 'ayahs': 96},
    {'number': 67, 'name': 'سورة الملك', 'type': 'مكية', 'ayahs': 30},
    {'number': 112, 'name': 'سورة الإخلاص', 'type': 'مكية', 'ayahs': 4},
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('القرآن الكريم', style: TextStyle(fontFamily: 'Amiri', fontWeight: FontWeight.bold)),
        centerTitle: true,
        actions: [
          // خيارات تكبير وتصغير الخط في أعلى يمين الشاشة
          PopupMenuButton<String>(
            icon: const Icon(Icons.text_format),
            onSelected: (value) {
              setState(() {
                if (value == 'increase' && _fontSize < 30.0) {
                  _fontSize += 2.0;
                } else if (value == 'decrease' && _fontSize > 12.0) {
                  _fontSize -= 2.0;
                }
              });
            },
            itemBuilder: (context) => [
              const PopupMenuItem(
                value: 'increase',
                child: Row(
                  children: [
                    Icon(Icons.zoom_in, color: Colors.black54),
                    SizedBox(width: 8),
                    Text('تكبير الخط'),
                  ],
                ),
              ),
              const PopupMenuItem(
                value: 'decrease',
                child: Row(
                  children: [
                    Icon(Icons.zoom_out, color: Colors.black54),
                    SizedBox(width: 8),
                    Text('تصغير الخط'),
                  ],
                ),
              ),
            ],
          ),
        ],
      ),
      body: ListView.builder(
        padding: const EdgeInsets.all(12),
        itemCount: _surahs.length,
        itemBuilder: (context, index) {
          final surah = _surahs[index];
          return Card(
            elevation: 2,
            margin: const EdgeInsets.symmetric(vertical: 6),
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
            child: ListTile(
              leading: CircleAvatar(
                backgroundColor: Colors.green.shade700,
                child: Text(
                  '${surah['number']}',
                  style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: _fontSize * 0.8),
                ),
              ),
              title: Text(
                surah['name'],
                style: TextStyle(fontSize: _fontSize + 2, fontWeight: FontWeight.bold, fontFamily: 'Amiri'),
              ),
              subtitle: Text(
                'النوع: ${surah['type']} • عدد الآيات: ${surah['ayahs']}',
                style: TextStyle(fontSize: _fontSize - 2),
              ),
              trailing: const Icon(Icons.arrow_forward_ios, size: 16),
              onTap: () {
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(content: Text('فتح ${surah['name']} - قراءة واستماع')),
                );
              },
            ),
          );
        },
      ),
    );
  }
}
