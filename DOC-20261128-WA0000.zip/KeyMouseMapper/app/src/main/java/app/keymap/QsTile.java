package app.keymap;
import android.content.Intent;import android.graphics.drawable.Icon;import android.service.quicksettings.*;
public class QsTile extends TileService{
  @Override public void onStartListening(){android.service.quicksettings.Tile t=getQsTile();if(t==null)return;
    t.setIcon(Icon.createWithResource(this,android.R.drawable.ic_menu_mylocation));t.setLabel(Store.t(this,"ماوس","Mouse"));
    t.setState(InputService.I!=null&&InputService.I.editing?android.service.quicksettings.Tile.STATE_ACTIVE:android.service.quicksettings.Tile.STATE_INACTIVE);t.updateTile();}
  @Override public void onClick(){
    if(InputService.I==null){startActivityAndCollapse(new Intent(this,MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));}
    else{InputService.I.toggle();onStartListening();}}
}
