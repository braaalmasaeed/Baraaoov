package app.keymap;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.graphics.*;
import android.graphics.drawable.GradientDrawable;
import android.util.DisplayMetrics;
import android.view.*;
import android.view.accessibility.AccessibilityEvent;
import android.widget.*;
import org.json.*;
import java.util.*;
import java.util.function.Consumer;
import java.util.function.IntConsumer;

public class InputService extends AccessibilityService {
  static InputService I;
  WindowManager wm; FrameLayout hud; LinearLayout panel; WindowManager.LayoutParams hlp, plp;
  View cursor; final List<View> circs = new ArrayList<>();
  String fg = "", state = "main", snap = "";
  boolean editing, dirty, panelOn; int sel = -1, selDel = -1, W, H; float cx, cy;
  JSONObject cfg = new JSONObject();

  // ---------- helpers ----------
  String t(String a, String e) { return Store.t(this, a, e); }
  int dp(int v) { return (int) (v * getResources().getDisplayMetrics().density); }
  JSONArray keys() { JSONArray a = cfg.optJSONArray("keys"); if (a == null) { a = new JSONArray(); Store.put(cfg, "keys", a); } return a; }
  boolean ms() { return cfg.optBoolean("ms"); }
  boolean kb() { return cfg.optBoolean("kb"); }

  // ---------- gestures (all active touches go in ONE gesture; Android allows only one at a time) ----------
  static class Hd { float x, y; boolean rel, fin; GestureDescription.StrokeDescription s; }
  final LinkedHashMap<Integer, Hd> act = new LinkedHashMap<>(); boolean busy; int tapId = -1000;
  void hold(int id, float x, float y, boolean down) {
    Hd h = act.get(id);
    if (down) { if (h == null) { h = new Hd(); h.x = x; h.y = y; act.put(id, h); } } else if (h != null) h.rel = true;
    pump();
  }
  void tap(float x, float y) { Hd h = new Hd(); h.x = x; h.y = y; h.rel = true; act.put(tapId--, h); pump(); }
  void pump() {
    if (busy || act.isEmpty()) return;
    GestureDescription.Builder b = new GestureDescription.Builder();
    for (Hd h : act.values()) {
      Path p = new Path(); p.moveTo(h.x, h.y); boolean will = !h.rel; h.fin = !will;
      h.s = h.s == null ? new GestureDescription.StrokeDescription(p, 0, 80, will) : h.s.continueStroke(p, 0, 80, will);
      b.addStroke(h.s);
    }
    busy = true;
    dispatchGesture(b.build(), new GestureResultCallback() {
      @Override public void onCompleted(GestureDescription d) { busy = false; act.values().removeIf(h -> h.fin); pump(); }
      @Override public void onCancelled(GestureDescription d) { busy = false; act.clear(); }
    }, null);
  }

  // ---------- lifecycle / events ----------
  @Override protected void onServiceConnected() {
    I = this; wm = (WindowManager) getSystemService(WINDOW_SERVICE);
    DisplayMetrics m = new DisplayMetrics(); wm.getDefaultDisplay().getRealMetrics(m); W = m.widthPixels; H = m.heightPixels; cx = W / 2f; cy = H / 2f;
    hud = new FrameLayout(this); hud.setFocusable(true); hud.setFocusableInTouchMode(true);
    cursor = new View(this); GradientDrawable g = new GradientDrawable(); g.setShape(GradientDrawable.OVAL); g.setColor(0xffffffff); g.setStroke(dp(2), 0xffff3b30);
    cursor.setBackground(g); cursor.setLayoutParams(new FrameLayout.LayoutParams(dp(18), dp(18))); cursor.setVisibility(View.GONE); hud.addView(cursor);
    hud.setOnCapturedPointerListener((v, ev) -> {
      int a = ev.getActionMasked();
      if (a == MotionEvent.ACTION_MOVE || a == MotionEvent.ACTION_HOVER_MOVE) {
        float s = cfg.optInt("sens", 50) / 25f;
        cx = Math.max(0, Math.min(W, cx + ev.getX() * s)); cy = Math.max(0, Math.min(H, cy + ev.getY() * s)); cursor.setX(cx); cursor.setY(cy);
      } else if (a == MotionEvent.ACTION_BUTTON_PRESS) {
        if (ev.getActionButton() == MotionEvent.BUTTON_PRIMARY) tap(cx, cy);
        else if (ev.getActionButton() == MotionEvent.BUTTON_SECONDARY) performGlobalAction(GLOBAL_ACTION_BACK);
      }
      return true;
    });
    hlp = new WindowManager.LayoutParams(-1, -1, WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY, 0, PixelFormat.TRANSLUCENT);
    hlp.flags = WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE | WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE;
    wm.addView(hud, hlp);
    panel = new LinearLayout(this); panel.setOrientation(LinearLayout.VERTICAL); panel.setPadding(dp(8), dp(8), dp(8), dp(8));
    GradientDrawable pg = new GradientDrawable(); pg.setColor(0xe6202428); pg.setCornerRadius(dp(12)); panel.setBackground(pg);
    plp = new WindowManager.LayoutParams(dp(200), -2, WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY, WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN, PixelFormat.TRANSLUCENT);
    plp.gravity = Gravity.TOP | Gravity.START; plp.x = dp(12); plp.y = dp(120);
  }
  @Override public void onAccessibilityEvent(AccessibilityEvent e) {
    if (e.getEventType() != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED || e.getPackageName() == null) return;
    String p = e.getPackageName().toString();
    if (p.equals(getPackageName()) || p.equals("com.android.systemui") || p.equals("android") || p.contains("inputmethod")) return;
    if (!p.equals(fg)) { if (editing) end(); fg = p; cfg = Store.cfg(this, fg); showKeys(); }
  }
  @Override public void onInterrupt() {}
  @Override public void onDestroy() { I = null; super.onDestroy(); }

  // ---------- physical keyboard ----------
  @Override protected boolean onKeyEvent(KeyEvent e) {
    int code = e.getKeyCode(); boolean down = e.getAction() == KeyEvent.ACTION_DOWN;
    if (editing) {
      if (state.equals("kb") && down && e.getRepeatCount() == 0 && code != KeyEvent.KEYCODE_BACK && code != KeyEvent.KEYCODE_HOME && code != KeyEvent.KEYCODE_POWER && code != KeyEvent.KEYCODE_APP_SWITCH) { addKey(code); return true; }
      return false;
    }
    if (!kb() || !Store.allowKb(this) || !Store.apps(this).contains(fg)) return false;
    JSONArray ks = keys();
    for (int i = 0; i < ks.length(); i++) {
      JSONObject k = ks.optJSONObject(i);
      if (k == null || k.optBoolean("del") || k.optInt("c") != code) continue;
      if (k.optBoolean("can")) return true; // cancelled key: consumed, does nothing
      float s = k.optInt("s", dp(56)); hold(code, k.optInt("x") + s / 2, k.optInt("y") + s / 2, down); return true;
    }
    return false;
  }
  void addKey(int code) {
    JSONArray ks = keys();
    for (int i = 0; i < ks.length(); i++) if (ks.optJSONObject(i).optInt("c") == code) return;
    JSONObject k = new JSONObject();
    Store.put(k, "c", code); Store.put(k, "l", KeyEvent.keyCodeToString(code).replace("KEYCODE_", ""));
    Store.put(k, "x", W / 2 - dp(28) + ks.length() * dp(8)); Store.put(k, "y", H / 2); Store.put(k, "s", dp(56)); Store.put(k, "a", -1);
    ks.put(k); dirty = true; sel = ks.length() - 1; showKeys(); render();
  }

  // ---------- session ----------
  void toggle() {
    if (editing) { end(); return; }
    if (!Store.apps(this).contains(fg)) { Toast.makeText(this, t("أضف هذا التطبيق من التطبيق الرئيسي أولاً", "Add this app in the main app first"), Toast.LENGTH_LONG).show(); return; }
    editing = true; state = "main"; sel = -1; cfg = Store.cfg(this, fg); snap = cfg.toString(); dirty = false;
    if (!panelOn) { wm.addView(panel, plp); panelOn = true; }
    flags(); showKeys(); render();
  }
  void end() {
    Store.saveCfg(this, fg, cfg); editing = false; state = "main";
    if (panelOn) { wm.removeView(panel); panelOn = false; }
    flags(); showKeys();
  }
  void go(String s) { state = s; sel = -1; selDel = -1; flags(); showKeys(); render(); }
  void flags() {
    boolean block = editing && state.equals("kb"), cap = editing && ms() && Store.allowMs(this) && !block;
    int f = WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS;
    if (!block) f |= WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE;
    if (!cap) f |= WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE;
    hlp.flags = f; wm.updateViewLayout(hud, hlp);
    cursor.setVisibility(cap ? View.VISIBLE : View.GONE); cursor.setX(cx); cursor.setY(cy);
    if (cap) hud.post(() -> { hud.requestFocus(); hud.requestPointerCapture(); }); else hud.releasePointerCapture();
  }

  // ---------- key circles ----------
  void showKeys() {
    for (View v : circs) hud.removeView(v); circs.clear();
    JSONArray ks = keys(); boolean ed = editing && state.equals("kb");
    for (int i = 0; i < ks.length(); i++) {
      JSONObject k = ks.optJSONObject(i);
      if (k == null || k.optBoolean("del")) continue;
      if (!ed && (editing || k.optInt("a", -1) < 0)) continue;
      View v = circle(k, i); circs.add(v); hud.addView(v);
    }
  }
  View circle(JSONObject k, int i) {
    TextView v = new TextView(this); int s = k.optInt("s", dp(56)); boolean can = k.optBoolean("can");
    v.setText(can ? k.optString("l") + " ✕" : k.optString("l")); v.setTextColor(can ? 0xffff3b30 : 0xffffffff); v.setTextSize(12); v.setGravity(Gravity.CENTER);
    GradientDrawable g = new GradientDrawable(); g.setShape(GradientDrawable.OVAL); g.setColor(0xff606060); if (editing && i == sel) g.setStroke(dp(3), 0xff4b8dff);
    v.setBackground(g); v.setAlpha(editing ? 0.6f : k.optInt("a", 50) / 100f);
    v.setLayoutParams(new FrameLayout.LayoutParams(s, s)); v.setX(k.optInt("x")); v.setY(k.optInt("y"));
    if (editing) v.setOnTouchListener(new View.OnTouchListener() {
      float dx, dy, sx, sy; boolean mv;
      @Override public boolean onTouch(View view, MotionEvent e) {
        int a = e.getActionMasked();
        if (a == MotionEvent.ACTION_DOWN) { dx = view.getX() - e.getRawX(); dy = view.getY() - e.getRawY(); sx = e.getRawX(); sy = e.getRawY(); mv = false; }
        else if (a == MotionEvent.ACTION_MOVE) { if (Math.abs(e.getRawX() - sx) > dp(6) || Math.abs(e.getRawY() - sy) > dp(6)) mv = true; if (mv) { view.setX(e.getRawX() + dx); view.setY(e.getRawY() + dy); } }
        else if (a == MotionEvent.ACTION_UP) { if (mv) { Store.put(k, "x", (int) view.getX()); Store.put(k, "y", (int) view.getY()); dirty = true; } else sel = i; showKeys(); render(); }
        return true;
      }
    });
    return v;
  }

  // ---------- panel UI ----------
  Button b(String s, boolean en, Runnable r) {
    Button x = new Button(this); x.setText(s); x.setTextSize(12); x.setMinHeight(0); x.setMinimumHeight(dp(38)); x.setEnabled(en); x.setAlpha(en ? 1f : 0.4f);
    x.setOnClickListener(v -> r.run()); return x;
  }
  TextView tx(String s) { TextView v = new TextView(this); v.setText(s); v.setTextColor(0xffffffff); v.setTextSize(12); return v; }
  CheckBox cb(String s, boolean on, boolean en, Consumer<Boolean> f) {
    CheckBox c = new CheckBox(this); c.setText(s); c.setTextColor(0xffffffff); c.setTextSize(13); c.setChecked(on); c.setEnabled(en); c.setAlpha(en ? 1f : 0.4f);
    c.setOnCheckedChangeListener((v, o) -> f.accept(o)); return c;
  }
  View sbRow(String label, int min, int max, int val, IntConsumer cb) {
    LinearLayout r = new LinearLayout(this); r.setOrientation(LinearLayout.VERTICAL); r.addView(tx(label));
    SeekBar s = new SeekBar(this); s.setMin(min); s.setMax(max); s.setProgress(Math.max(min, Math.min(max, val)));
    s.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
      public void onProgressChanged(SeekBar x, int p, boolean u) { if (u) cb.accept(p); }
      public void onStartTrackingTouch(SeekBar x) {} public void onStopTrackingTouch(SeekBar x) {}
    });
    r.addView(s); return r;
  }
  void save() { Store.saveCfg(this, fg, cfg); snap = cfg.toString(); dirty = false; }
  void back() { go(state.equals("del") ? "kb" : "main"); }

  void render() {
    if (!panelOn) return;
    panel.setLayoutDirection(Store.ar(this) ? View.LAYOUT_DIRECTION_RTL : View.LAYOUT_DIRECTION_LTR);
    panel.removeAllViews();
    TextView h = tx("⠿  " + t("اسحب للتحريك", "Drag to move")); h.setPadding(0, 0, 0, dp(6));
    h.setOnTouchListener(new View.OnTouchListener() {
      float dx, dy;
      @Override public boolean onTouch(View v, MotionEvent e) {
        if (e.getAction() == MotionEvent.ACTION_DOWN) { dx = plp.x - e.getRawX(); dy = plp.y - e.getRawY(); }
        else if (e.getAction() == MotionEvent.ACTION_MOVE) { plp.x = (int) (e.getRawX() + dx); plp.y = (int) (e.getRawY() + dy); wm.updateViewLayout(panel, plp); }
        return true;
      }
    });
    panel.addView(h);
    if (!state.equals("main")) panel.addView(b(t("رجوع", "Back"), true, this::back));
    boolean[] d = Store.devs(); boolean kOk = d[0] && Store.allowKb(this), mOk = d[1] && Store.allowMs(this);

    if (state.equals("main")) {
      panel.addView(cb(t("تفعيل سهم الماوس", "Mouse arrow"), ms(), mOk, o -> { Store.put(cfg, "ms", o); flags(); }));
      panel.addView(cb(t("تفعيل الكيبورد", "Keyboard on"), kb(), kOk, o -> Store.put(cfg, "kb", o)));
      panel.addView(b(t("إعدادات الماوس", "Mouse settings"), mOk, () -> go("mouse")));
      panel.addView(b(t("إعدادات الكيبورد", "Keyboard settings"), kOk, () -> go("kb")));
      panel.addView(b(t("الإعداد المسبق", "Presets"), true, () -> go("presets")));
      panel.addView(b(t("إنهاء", "Finish"), true, this::end));
    } else if (state.equals("mouse")) {
      panel.addView(sbRow(t("حساسية السهم", "Pointer speed"), 1, 100, cfg.optInt("sens", 50), v -> Store.put(cfg, "sens", v)));
      panel.addView(tx(t("النقر الأيسر = لمس، النقر الأيمن = رجوع", "Left click = tap, right click = Back")));
      panel.addView(b(t("حفظ", "Save"), true, () -> { save(); back(); }));
    } else if (state.equals("kb")) {
      panel.addView(tx(t("اضغط أي زر في الكيبورد لإضافته", "Press a keyboard key to add it")));
      panel.addView(b(t("المحذوفات", "Deleted"), true, () -> go("del")));
      JSONObject k = sel >= 0 ? keys().optJSONObject(sel) : null;
      if (k != null && !k.optBoolean("del")) {
        panel.addView(sbRow(t("الحجم", "Size"), dp(30), dp(140), k.optInt("s"), v -> { Store.put(k, "s", v); dirty = true; showKeys(); }));
        panel.addView(cb(t("إلغاء الزر (X)", "Disable key (X)"), k.optBoolean("can"), true, o -> { Store.put(k, "can", o); dirty = true; showKeys(); }));
        panel.addView(b(t("حذف", "Delete"), true, () -> { Store.put(k, "del", true); dirty = true; sel = -1; showKeys(); render(); }));
        boolean has = k.optInt("a", -1) >= 0;
        panel.addView(cb(t("تحديد الشفافية", "Set opacity"), has, true, o -> { Store.put(k, "a", o ? 50 : -1); dirty = true; render(); }));
        if (has) panel.addView(sbRow(t("الشفافية", "Opacity"), 5, 100, k.optInt("a"), v -> { Store.put(k, "a", v); dirty = true; }));
      }
      if (dirty) {
        panel.addView(b(t("حفظ", "Save"), true, () -> { save(); render(); }));
        panel.addView(b(t("إعادة ترتيب", "Reset"), true, () -> { cfg = Store.J(snap); dirty = false; sel = -1; showKeys(); render(); }));
      }
    } else if (state.equals("del")) {
      JSONArray ks = keys(); boolean any = false;
      for (int i = 0; i < ks.length(); i++) {
        JSONObject k = ks.optJSONObject(i); if (k == null || !k.optBoolean("del")) continue; any = true; final int idx = i;
        Button x = b((i == selDel ? "● " : "") + k.optString("l"), true, () -> { selDel = idx; render(); }); panel.addView(x);
      }
      if (!any) panel.addView(tx(t("لا توجد أزرار محذوفة", "No deleted keys")));
      if (selDel >= 0) panel.addView(b(t("استعادة", "Restore"), true, () -> { Store.put(keys().optJSONObject(selDel), "del", false); dirty = true; selDel = -1; go("kb"); }));
    } else if (state.equals("presets")) {
      JSONObject ps = Store.presets(this);
      for (Iterator<String> it = ps.keys(); it.hasNext(); ) {
        final String name = it.next();
        panel.addView(b(name, true, () -> {
          JSONObject p = ps.optJSONObject(name); if (p == null) return;
          Store.put(cfg, "keys", Store.J(p.toString()).optJSONArray("keys")); Store.put(cfg, "sens", p.optInt("sens", 50)); save(); go("main");
        }));
      }
      panel.addView(b("+ " + t("إضافة إعداد جديد", "Add preset"), true, () -> {
        JSONObject p = Store.presets(this); JSONObject c = new JSONObject();
        Store.put(c, "keys", Store.J(cfg.toString()).optJSONArray("keys")); Store.put(c, "sens", cfg.optInt("sens", 50));
        Store.put(p, t("إعداد ", "Preset ") + (p.length() + 1), c); Store.savePresets(this, p); render();
      }));
    }
  }
}
