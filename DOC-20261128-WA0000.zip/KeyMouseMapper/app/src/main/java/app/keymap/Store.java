package app.keymap;
import android.content.*;import android.view.InputDevice;import org.json.*;import java.util.*;
class Store{
  static SharedPreferences p(Context c){return c.getSharedPreferences("s",0);}
  static boolean ar(Context c){return p(c).getString("lang","ar").equals("ar");}
  static String t(Context c,String a,String e){return ar(c)?a:e;}
  static Set<String> apps(Context c){return new HashSet<>(p(c).getStringSet("apps",new HashSet<String>()));}
  static JSONObject J(String s){try{return new JSONObject(s);}catch(Exception e){return new JSONObject();}}
  static void put(JSONObject o,String k,Object v){try{o.put(k,v);}catch(Exception e){}}
  static JSONObject cfg(Context c,String pkg){JSONObject o=J(p(c).getString("cfg_"+pkg,"{}"));if(o.optJSONArray("keys")==null)put(o,"keys",new JSONArray());if(!o.has("sens"))put(o,"sens",50);return o;}
  static void saveCfg(Context c,String pkg,JSONObject o){p(c).edit().putString("cfg_"+pkg,o.toString()).apply();}
  static JSONObject presets(Context c){return J(p(c).getString("presets","{}"));}
  static void savePresets(Context c,JSONObject o){p(c).edit().putString("presets",o.toString()).apply();}
  static boolean[] devs(){boolean kb=false,ms=false;for(int id:InputDevice.getDeviceIds()){InputDevice d=InputDevice.getDevice(id);if(d==null||d.isVirtual())continue;int s=d.getSources();
    if((s&InputDevice.SOURCE_KEYBOARD)==InputDevice.SOURCE_KEYBOARD&&d.getKeyboardType()==InputDevice.KEYBOARD_TYPE_ALPHABETIC)kb=true;
    if((s&InputDevice.SOURCE_MOUSE)==InputDevice.SOURCE_MOUSE)ms=true;}return new boolean[]{kb,ms};}
  static boolean allowKb(Context c){return p(c).getInt("mode",0)!=4||p(c).getString("only","kb").equals("kb");}
  static boolean allowMs(Context c){return p(c).getInt("mode",0)!=4||p(c).getString("only","kb").equals("ms");}
}
