package app.keymap;
import android.app.*;import android.content.*;import android.content.pm.*;import android.content.res.Configuration;import android.os.Bundle;import android.provider.Settings;
import android.view.*;import android.widget.*;import org.json.*;import java.util.*;
public class MainActivity extends Activity{
  LinearLayout box;
  @Override protected void attachBaseContext(Context c){Configuration cf=new Configuration(c.getResources().getConfiguration());
    cf.setLocale(new Locale(Store.p(c).getString("lang","ar")));super.attachBaseContext(c.createConfigurationContext(cf));}
  @Override protected void onResume(){super.onResume();build();}
  String t(String a,String e){return Store.t(this,a,e);}
  int dp(int v){return (int)(v*getResources().getDisplayMetrics().density);}
  TextView tv(String s,int sp){TextView x=new TextView(this);x.setText(s);x.setTextSize(sp);x.setPadding(0,dp(6),0,dp(6));return x;}
  Button bt(String s,Runnable r){Button b=new Button(this);b.setText(s);b.setOnClickListener(v->r.run());return b;}
  boolean a11y(){String s=Settings.Secure.getString(getContentResolver(),Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES);return s!=null&&s.contains(getPackageName()+"/");}
  void build(){
    ScrollView sv=new ScrollView(this);box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);box.setPadding(dp(16),dp(16),dp(16),dp(16));sv.addView(box);setContentView(sv);
    box.addView(tv("Key Mouse Mapper",22));
    LinearLayout row=new LinearLayout(this);
    row.addView(bt(Store.ar(this)?"English":"عربي",()->{Store.p(this).edit().putString("lang",Store.ar(this)?"en":"ar").apply();recreate();}));
    row.addView(bt(t("كيفية الاستخدام","How to use"),this::howTo));box.addView(row);
    boolean[] d=Store.devs();
    box.addView(tv(t("حالة الأذونات والأجهزة","Permissions and devices"),18));
    box.addView(tv((a11y()?"✔ ":"✖ ")+t("خدمة إمكانية الوصول","Accessibility service"),15));
    if(!a11y())box.addView(bt(t("تفعيلها من الإعدادات","Enable in Settings"),()->startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))));
    box.addView(tv((d[0]?"✔ ":"✖ ")+t("كيبورد متصل","Keyboard connected"),15));
    box.addView(tv((d[1]?"✔ ":"✖ ")+t("ماوس متصل","Mouse connected"),15));
    box.addView(tv(t("طريقة الربط","Connection mode"),18));
    String[] modes={t("كيبورد وماوس عبر Bluetooth","Keyboard+mouse via Bluetooth"),t("كيبورد وماوس عبر USB OTG","Keyboard+mouse via USB OTG"),t("كيبورد وماوس عبر Wi-Fi (غير مدعوم حالياً)","Keyboard+mouse via Wi-Fi (not supported yet)"),t("ربط مستقل لكل جهاز","Separate per device"),t("جهاز واحد فقط","Single device only")};
    RadioGroup rg=new RadioGroup(this);int cur=Store.p(this).getInt("mode",0);
    for(int i=0;i<5;i++){RadioButton rb=new RadioButton(this);rb.setId(100+i);rb.setText(modes[i]);rg.addView(rb);}
    rg.check(100+cur);
    rg.setOnCheckedChangeListener((g,id)->{Store.p(this).edit().putInt("mode",id-100).apply();build();});box.addView(rg);
    if(cur==3){String[] src={"Bluetooth","USB OTG","Wi-Fi"};
      for(String key:new String[]{"kbsrc","mssrc"}){box.addView(tv(key.equals("kbsrc")?t("طريقة الكيبورد","Keyboard source"):t("طريقة الماوس","Mouse source"),14));
        Spinner sp=new Spinner(this);sp.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,src));sp.setSelection(Store.p(this).getInt(key,0));
        sp.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener(){public void onItemSelected(AdapterView<?> a,View v,int p,long i){Store.p(MainActivity.this).edit().putInt(key,p).apply();}public void onNothingSelected(AdapterView<?> a){}});box.addView(sp);}}
    if(cur==4){RadioGroup r2=new RadioGroup(this);String only=Store.p(this).getString("only","kb");
      RadioButton a=new RadioButton(this);a.setId(1);a.setText(t("الكيبورد فقط","Keyboard only"));RadioButton b=new RadioButton(this);b.setId(2);b.setText(t("الماوس فقط","Mouse only"));
      r2.addView(a);r2.addView(b);r2.check(only.equals("kb")?1:2);r2.setOnCheckedChangeListener((g,id)->Store.p(this).edit().putString("only",id==1?"kb":"ms").apply());box.addView(r2);}
    box.addView(bt(t("إضافة التطبيقات","Add apps")+" ("+Store.apps(this).size()+")",this::pickApps));
    box.addView(bt(t("الإعدادات المسبقة","Presets"),this::presets));
  }
  void howTo(){new AlertDialog.Builder(this).setTitle(t("كيفية الاستخدام","How to use")).setMessage(t(
    "1) فعّل خدمة إمكانية الوصول من الزر أعلاه.\n2) اربط الكيبورد/الماوس بالبلوتوث أو OTG.\n3) أضف التطبيقات من «إضافة التطبيقات».\n4) من لوحة الإعدادات السريعة أضف مربع «ماوس» (اسحب للتعديل).\n5) افتح التطبيق المضاف ثم اضغط مربع «ماوس» لإظهار طبقة التحكم.\n6) من «إعدادات الكيبورد» اضغط زراً على الكيبورد لإضافته، حرّكه ثم احفظ.\n7) اضغط «إنهاء» فتعمل الأزرار المفعّلة.",
    "1) Enable the Accessibility service with the button above.\n2) Connect keyboard/mouse via Bluetooth or OTG.\n3) Add apps via 'Add apps'.\n4) Add the 'Mouse' tile to Quick Settings (edit the panel).\n5) Open an added app, then tap the tile to show the control layer.\n6) In 'Keyboard settings' press a physical key to add it, drag it, then save.\n7) Tap 'Finish' and the enabled keys start working.")).setPositiveButton("OK",null).show();}
  void pickApps(){PackageManager pm=getPackageManager();List<ResolveInfo> l=pm.queryIntentActivities(new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER),0);
    final List<String[]> a=new ArrayList<>();for(ResolveInfo r:l)a.add(new String[]{String.valueOf(r.loadLabel(pm)),r.activityInfo.packageName});
    Collections.sort(a,(x,y)->x[0].compareToIgnoreCase(y[0]));Set<String> sel=Store.apps(this);
    String[] names=new String[a.size()];boolean[] ck=new boolean[a.size()];for(int i=0;i<a.size();i++){names[i]=a.get(i)[0];ck[i]=sel.contains(a.get(i)[1]);}
    new AlertDialog.Builder(this).setTitle(t("اختر التطبيقات","Choose apps")).setMultiChoiceItems(names,ck,(d,w,c)->ck[w]=c)
      .setPositiveButton(t("حفظ","Save"),(d,w)->{Set<String> s=new HashSet<>();for(int i=0;i<ck.length;i++)if(ck[i])s.add(a.get(i)[1]);Store.p(this).edit().putStringSet("apps",s).apply();build();}).setNegativeButton(t("إلغاء","Cancel"),null).show();}
  void presets(){JSONObject ps=Store.presets(this);final List<String> n=new ArrayList<>();for(Iterator<String> it=ps.keys();it.hasNext();)n.add(it.next());
    if(n.isEmpty()){Toast.makeText(this,t("لا توجد إعدادات محفوظة. احفظ من طبقة التحكم.","No presets. Save one from the control layer."),Toast.LENGTH_LONG).show();return;}
    new AlertDialog.Builder(this).setTitle(t("الإعدادات المسبقة","Presets")).setItems(n.toArray(new String[0]),(d,w)->{String name=n.get(w);
      new AlertDialog.Builder(this).setTitle(name).setItems(new String[]{t("تعديل الاسم","Rename"),t("حذف","Delete")},(d2,w2)->{
        if(w2==1){ps.remove(name);Store.savePresets(this,ps);}
        else{EditText e=new EditText(this);e.setText(name);new AlertDialog.Builder(this).setView(e).setPositiveButton("OK",(d3,w3)->{String nn=e.getText().toString().trim();if(nn.isEmpty())return;Object v=ps.opt(name);ps.remove(name);Store.put(ps,nn,v);Store.savePresets(this,ps);}).show();}}).show();}).show();}
}
